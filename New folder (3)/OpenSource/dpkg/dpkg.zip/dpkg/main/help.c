/*
 * dpkg - main program for package management
 * help.c - various helper routines
 *
 * Copyright (C) 1995 Ian Jackson <iwj10@cus.cam.ac.uk>
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with dpkg; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */ 

#include <config.h>

#include <errno.h>
#include <unistd.h>
#include <dirent.h>
#include <assert.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <limits.h>

#include <dpkg.h>
#include <dpkg-db.h>

#include "filesdb.h"
#include "main.h"

extern int INSTDIR;

const char *const statusstrings[]= {
  N_("not installed"), N_("unpacked but not configured"),
  N_("broken due to postinst failure"),
  N_("installed"),
  N_("broken due to failed removal"),
  N_("not installed but configs remain")
};

const char *hpeesofdir = 0;

struct filenamenode *namenodetouse(struct filenamenode *namenode, struct pkginfo *pkg) {
  struct filenamenode *r;
  
  if (!namenode->divert) return namenode;
  
  debug(dbg_eachfile,"namenodetouse namenode=`%s' pkg=%s",
        namenode->name,pkg->name);
  
  r=
    (namenode->divert->useinstead && namenode->divert->pkg != pkg)
      ? namenode->divert->useinstead : namenode;
  
  debug(dbg_eachfile,
        "namenodetouse ... useinstead=%s camefrom=%s pkg=%s return %s",
        namenode->divert->useinstead ? namenode->divert->useinstead->name : "<none>",
        namenode->divert->camefrom ? namenode->divert->camefrom->name : "<none>",
        namenode->divert->pkg ? namenode->divert->pkg->name : "<none>",
        r->name);
  return r;
}

void checkpath (void) {}

#ifdef _WIN32
void cygwin_conv_to_posix_path(const char *, char *);
#include <windows.h>
#endif

void checkhpeesofdir(void) {

  static const char *const checklist[]= {
    "tools/bin/dpkg-deb",
#ifndef linux
 "tools/bin/gzip", "tools/bin/tar",
#endif
    0
  };

  const char *path, *hpeesofdir_arch;
  char *newenv;
  struct stat stab;
  const char *const *clp;
  char buf[PATH_MAX+2];
  int warned= 0;

  hpeesofdir= getenv("HPEESOF_DIR");

#ifdef _WIN32
  if (!hpeesofdir) {
    /* if env variable is not set, try the registry */
    HKEY hKey;
    char envar[PATH_MAX+1], *pos;
    int envarSize = PATH_MAX+1;
    char regEntry[PATH_MAX+1];
#ifdef PROD_IS_stw     
    sprintf(regEntry, "SOFTWARE\\Agilent\\STW\\%1.2f\\eeenv", VER/100.0);
#else
#ifdef PROD_IS_ic  
    sprintf(regEntry, "SOFTWARE\\Agilent\\ICCAP\\%1.2f\\eeenv", VER/100.0);
#else
#ifdef PROD_IS_em  
    sprintf(regEntry, "SOFTWARE\\Agilent\\EMDS\\%1.2f\\eeenv", VER/100.0);
#else
    sprintf(regEntry, "SOFTWARE\\Agilent\\ADS\\%1.2f\\eeenv", VER/100.0);
#endif
#endif
#endif
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, regEntry, 0, KEY_READ, &hKey)
	== ERROR_SUCCESS && 
	RegQueryValueEx(hKey, "HPEESOF_DIR", 0, 0, envar, &envarSize)
	== ERROR_SUCCESS) {
      pos = strpbrk(envar, "\r\n");
      if (pos) *pos = 0;
      else envar[envarSize] = 0;
      RegCloseKey(hKey);
      if ( strlen(envar) != 0 )
        hpeesofdir = envar;
    }
  }
#endif

  if (!hpeesofdir) ohshit("HPEESOF_DIR is not set.");
  hpeesofdir_arch = hpeesofdir;
  newenv = m_malloc(strlen(hpeesofdir) + 18);
  strcpy(newenv, "HPEESOF_DIR_ARCH=");
  strcat(newenv, hpeesofdir_arch);
  putenv(newenv);
  hpeesofdir_arch = newenv + 17;
 
#ifdef _WIN32
  cygwin_conv_to_posix_path(hpeesofdir, buf);
  hpeesofdir = m_malloc(strlen(buf) + 1);
  strcpy(hpeesofdir,buf);
  
  newenv=m_malloc(strlen(hpeesofdir) + 13);
  strcpy(newenv, "HPEESOF_DIR=");
  strcat(newenv, hpeesofdir);
  putenv(newenv);

  putenv("ENV=");		/* for MKS users */
  if ((path=getenv("DPKG_DEBUG_OUTPUT"))) 
    fprintf(stderr,"HPEESOF_DIR:  %s\n",hpeesofdir);
#endif
  
  if (stat(hpeesofdir,&stab) || !S_ISDIR(stab.st_mode))
    ohshit("HPEESOF_DIR is not a directory at %s.",hpeesofdir);

  if ( ! *instdir) 
   setroot(0, hpeesofdir);


  for (clp=checklist; *clp; clp++) {
    if (strlen(hpeesofdir)+strlen(*clp)>PATH_MAX) continue;
    strcpy(buf,hpeesofdir);
    strcat(buf,"/");
    strcat(buf,*clp);
#ifdef _WIN32
    if (stat(buf,&stab)) {
#else
    if (stat(buf,&stab) || !(stab.st_mode & 0111)) {
#endif
      fprintf(stderr,_("`%s' not found in HPEESOF_DIR.\n"),*clp);
      warned++;
    }
  }

  if (warned)
    forcibleerr(fc_badpath,_("%d expected program(s) not found in HPEESOF_DIR.\n"), warned);

  strcpy(buf,"PATH=");
#ifdef _WIN32
  strcat(buf,hpeesofdir);
  strcat(buf,"/tools/bin");
  strcat(buf,":");
#endif
  strcat(buf,hpeesofdir);
  strcat(buf,"/tools/bin");

  if ((path=getenv("PATH"))) {
    newenv=m_malloc(strlen(buf) + strlen(path) + 2);
    strcpy(newenv,buf);
    strcat(newenv,":");
    strcat(newenv,path);
  }
  else {
    fprintf(stderr,DPKG ": warning: PATH is not set.\n");
    newenv=m_malloc(strlen(buf) + 1);
    strcpy(newenv,buf);
  }
  putenv(newenv);

  *buf=0;
#if defined(__hpux)
  newenv=getenv("SHLIB_PATH");
  sprintf(buf,"SHLIB_PATH=%s/lib/hpux11%s%s", hpeesofdir,
	  newenv ? ":" : "",
	  newenv ? newenv : "");
#elif defined(linux)
  newenv=getenv("LD_LIBRARY_PATH");
  sprintf(buf,"LD_LIBRARY_PATH=%s/lib/linux_x86%s%s", hpeesofdir,
	  newenv ? ":" : "",
	  newenv ? newenv : "");
#elif defined(sparc)
  newenv=getenv("LD_LIBRARY_PATH");
  sprintf(buf,"LD_LIBRARY_PATH=%s/lib/sun_sparc%s%s", hpeesofdir,
	  newenv ? ":" : "",
	  newenv ? newenv : "");
#elif defined(_AIX)
  newenv=getenv("LIBPATH");
  sprintf(buf,"LIBPATH=/lib:%s/lib/aix4%s%s", hpeesofdir,
	  newenv ? ":" : "",
	  newenv ? newenv : "");
#endif
  if (*buf) {
    newenv=m_malloc(strlen(buf) + 1);
    strcpy(newenv,buf);
    putenv(newenv);
  }

  /* if not root, act as if --force-not-root was given, and don't do
     operations that root can't do */
  if (getuid() || geteuid()) {
    dorootops = 0;
    fc_nonroot = 1;
  }

}

int shexecv(const char *path, char *const argv[]) {
  static char *newargv[PKGSCRIPTMAXARGS+1];
  char *const *nextarg;
  char *shell = "/bin/sh";
  int i;

#ifdef _WIN32
  char buf[PATH_MAX];
  strcpy(buf, hpeesofdir);
  strcat(buf, "/tools/bin/sh");
  shell = buf;
#endif
  
  i=0;
  newargv[i++]= shell;
  newargv[i++]= (char *)path;	/* cast away const because exec wants it */
  for (nextarg=argv; *nextarg; nextarg++)
    newargv[i++]= *nextarg;
  newargv[i] = 0;

  return execv(shell, newargv);
}

void ensure_package_clientdata(struct pkginfo *pkg) {
  if (pkg->clientdata) return;
  pkg->clientdata= nfmalloc(sizeof(struct pkginfoperfile));
  pkg->clientdata->istobe= itb_normal;
  pkg->clientdata->fileslistvalid= 0;
  pkg->clientdata->files= 0;
}

void cu_closepipe(int argc, void **argv) {
  int *p1= (int*)argv[0];
  close(p1[0]); close(p1[1]);
}

void cu_closefile(int argc, void **argv) {
  FILE *f= (FILE*)(argv[0]);
  fclose(f);
}

void cu_closedir(int argc, void **argv) {
  DIR *d= (DIR*)(argv[0]);
  closedir(d);
}

void cu_closefd(int argc, void **argv) {
  int *ip= (int*)(argv[0]);
  close(*ip);
}

int ignore_depends(struct pkginfo *pkg) {
  struct packageinlist *id;
  for (id= ignoredependss; id; id= id->next)
    if (id->pkg == pkg) return 1;
  return 0;
}

int force_depends(struct deppossi *possi) {
  return fc_depends ||
         ignore_depends(possi->ed) ||
         ignore_depends(possi->up->up);
}

int force_conflicts(struct deppossi *possi) {
  return fc_conflicts;
}

const char *pkgadminfile(struct pkginfo *pkg, const char *whichfile) {
  static struct varbuf vb;
  varbufreset(&vb);
  varbufaddstr(&vb,admindir);
  varbufaddstr(&vb,"/" INFODIR);
  varbufaddstr(&vb,pkg->name);
  varbufaddc(&vb,'.');
  varbufaddstr(&vb,whichfile);
  varbufaddc(&vb,0);
  return vb.buf;
}

static void preexecscript(const char *path, char *const *argv) {
  if (*instdir) {
    /* fixme: won't work right when instdir != admindir */
    if (chdir(instdir)) ohshite("failed to chdir to `%.250s'",instdir);
  }
  if (f_debug & dbg_scripts) {
    fprintf(stderr,"D0%05o: fork/exec %s (",dbg_scripts,path);
    while (*argv) fprintf(stderr," %s",*argv++);
    fputs(" )\n",stderr);
  }
}  

static char *const *vbuildarglist(const char *scriptname, va_list ap) {
  static char *bufs[PKGSCRIPTMAXARGS+1];
  char *nextarg;
  int i;

  i=0;
  bufs[i++]= (char*)scriptname; /* yes, cast away const because exec wants it that way */
  for (;;) {
    assert(i < PKGSCRIPTMAXARGS);
    nextarg= va_arg(ap,char*);
    if (!nextarg) break;
    bufs[i++]= nextarg;
  }
  bufs[i]= 0;
  return bufs;
}    

static char *const *buildarglist(const char *scriptname, ...) {
  char *const *arglist;
  va_list ap;
  va_start(ap,scriptname);
  arglist= vbuildarglist(scriptname,ap);
  va_end(ap);
  return arglist;
}

#define NSCRIPTCATCHSIGNALS sizeof(script_catchsignallist)/sizeof(int)-1
static int script_catchsignallist[]= { SIGQUIT, SIGINT, 0 };
static struct sigaction script_uncatchsignal[NSCRIPTCATCHSIGNALS];

static void cu_restorescriptsignals(int argc, void **argv) {
  int i;
  for (i=0; i<NSCRIPTCATCHSIGNALS; i++) {
    if (sigaction(script_catchsignallist[i],&script_uncatchsignal[i],0)) {
      fprintf(stderr,_("error un-catching signal %s: %s\n"),
              strsignal(script_catchsignallist[i]),strerror(errno));
      onerr_abort++;
    }
  }
}

static void script_catchsignals(void) {
  int i;
  struct sigaction catchsig;
  
  onerr_abort++;
  memset(&catchsig,0,sizeof(catchsig));
  catchsig.sa_handler= SIG_IGN;
  sigemptyset(&catchsig.sa_mask);
  catchsig.sa_flags= 0;
  for (i=0; i<NSCRIPTCATCHSIGNALS; i++)
    if (sigaction(script_catchsignallist[i],&catchsig,&script_uncatchsignal[i]))
      ohshite(_("unable to ignore signal %s before running script"),
              strsignal(script_catchsignallist[i]));
  push_cleanup(cu_restorescriptsignals,~0, 0,0, 0);
  onerr_abort--;
}

static void setexecute(const char *path, struct stat *stab) {
  if ((stab->st_mode & 0555) == 0555) return;
  if (!chmod(path,0755)) return;
  ohshite(_("unable to set execute permissions on `%.250s'"),path);
}

int maintainer_script_installed(struct pkginfo *pkg, const char *scriptname,
                                const char *description, ...) {
  /* all ...'s are const char*'s */
  const char *scriptpath;
  char *const *arglist;
  struct stat stab;
  va_list ap;
  int c1;
  char buf[100];

  scriptpath= pkgadminfile(pkg,scriptname);
  va_start(ap,description);
  arglist= vbuildarglist(scriptname,ap);
  va_end(ap);
  sprintf(buf,"%s script",description);

  if (stat(scriptpath,&stab)) {
    if (errno == ENOENT) {
      debug(dbg_scripts,"maintainer_script_installed nonexistent %s",scriptname);
      return 0;
    }
    ohshite(_("unable to stat installed %s script `%.250s'"),description,scriptpath);
  }
  setexecute(scriptpath,&stab);
  c1= m_fork();
  if (!c1) {
    preexecscript(scriptpath,arglist);
    shexecv(scriptpath,arglist);
    ohshite(_("unable to execute %s"),buf);
  }
  script_catchsignals(); /* This does a push_cleanup() */
  waitsubproc(c1,buf,0);
  pop_cleanup(ehflag_normaltidy);

  ensure_diversions();
  return 1;
}
  
int maintainer_script_new(const char *scriptname, const char *description,
                          const char *cidir, char *cidirrest, ...) {
  char *const *arglist;
  struct stat stab;
  va_list ap;
  char buf[100];
  int c1;
  
  va_start(ap,cidirrest);
  arglist= vbuildarglist(scriptname,ap);
  va_end(ap);
  sprintf(buf,"%s script",description);

  strcpy(cidirrest,scriptname);
  if (stat(cidir,&stab)) {
    if (errno == ENOENT) {
      debug(dbg_scripts,"maintainer_script_new nonexistent %s `%s'",scriptname,cidir);
      return 0;
    }
    ohshite(_("unable to stat new %s script `%.250s'"),description,cidir);
  }
  setexecute(cidir,&stab);
  c1= m_fork();
  if (!c1) {
    preexecscript(cidir,arglist);
    shexecv(cidir,arglist);
    ohshite(_("unable to execute new %s"),buf);
  }
  script_catchsignals(); /* This does a push_cleanup() */
  waitsubproc(c1,buf,0);
  pop_cleanup(ehflag_normaltidy);

  ensure_diversions();
  return 1;
}

int maintainer_script_alternative(struct pkginfo *pkg,
                                  const char *scriptname, const char *description,
                                  const char *cidir, char *cidirrest,
                                  const char *ifok, const char *iffallback) {
  const char *oldscriptpath;
  char *const *arglist;
  struct stat stab;
  int c1, n, status;
  char buf[100];
  pid_t r;

  oldscriptpath= pkgadminfile(pkg,scriptname);
  arglist= buildarglist(scriptname,
                        ifok,versiondescribe(&pkg->available.version,
                                             vdew_nonambig),
                        (char*)0);
  sprintf(buf,"old %s script",description);
  if (stat(oldscriptpath,&stab)) {
    if (errno == ENOENT) {
      debug(dbg_scripts,"maintainer_script_alternative nonexistent %s `%s'",
            scriptname,oldscriptpath);
      return 0;
    }
    fprintf(stderr,
            _(DPKG ": warning - unable to stat %s `%.250s': %s\n"),
            buf,oldscriptpath,strerror(errno));
  } else {
    setexecute(oldscriptpath,&stab);
    c1= m_fork();
    if (!c1) {
      preexecscript(oldscriptpath,arglist);
      shexecv(oldscriptpath,arglist);
      ohshite(_("unable to execute %s"),buf);
    }
    script_catchsignals(); /* This does a push_cleanup() */
    while ((r= waitpid(c1,&status,0)) == -1 && errno == EINTR);
    if (r != c1) ohshite(_("wait for %s failed"),buf);
    pop_cleanup(ehflag_normaltidy);
    if (WIFEXITED(status)) {
      n= WEXITSTATUS(status); if (!n) return 1;
      fprintf(stderr, _(DPKG ": warning - %s returned error exit status %d\n"),buf,n);
    } else if (WIFSIGNALED(status)) {
      n= WTERMSIG(status);
      fprintf(stderr, _(DPKG ": warning - %s killed by signal (%s)%s\n"),
              buf, strsignal(n), WCOREDUMP(status) ? ", core dumped" : "");
    } else {
      ohshit(_("%s failed with unknown wait status code %d"),buf,status);
    }
    ensure_diversions();
  }
  fprintf(stderr, _(DPKG " - trying script from the new package instead ...\n"));

  arglist= buildarglist(scriptname,
                        iffallback,versiondescribe(&pkg->installed.version,
                                                   vdew_nonambig),
                        (char*)0);
  strcpy(cidirrest,scriptname);
  sprintf(buf,_("new %s script"),description);

  if (stat(cidir,&stab))
    if (errno == ENOENT)
      ohshit(_("there is no script in the new version of the package - giving up"));
    else
      ohshite(_("unable to stat %s `%.250s'"),buf,cidir);

  setexecute(cidir,&stab);

  c1= m_fork();
  if (!c1) {
    preexecscript(cidir,arglist);
    shexecv(cidir,arglist);
    ohshite(_("unable to execute %s"),buf);
  }
  script_catchsignals(); /* This does a push_cleanup() */
  waitsubproc(c1,buf,0);
  pop_cleanup(ehflag_normaltidy);
  fprintf(stderr, _(DPKG ": ... it looks like that went OK.\n"));

  ensure_diversions();
  return 1;
}

void clear_istobes(void) {
  struct pkgiterator *it;
  struct pkginfo *pkg;

  it= iterpkgstart();
  while ((pkg= iterpkgnext(it)) != 0) {
    ensure_package_clientdata(pkg);
    pkg->clientdata->istobe= itb_normal;
    pkg->clientdata->replacingfilesandsaid= 0;
  }
}

void debug(int which, const char *fmt, ...) {
  va_list ap;
  if (!(f_debug & which)) return;
  fprintf(stderr,"D0%05o: ",which);
  va_start(ap,fmt);
  vfprintf(stderr,fmt,ap);
  va_end(ap);
  putc('\n',stderr);
}

int isdirectoryinuse(struct filenamenode *file, struct pkginfo *pkg) {
  /* Returns 1 if the file is used by packages other than pkg, 0 otherwise. */
  struct filepackages *packageslump;
  int i;
    
  debug(dbg_veryverbose, "isdirectoryinuse `%s' (except %s)", file->name,
        pkg ? pkg->name : "<none>");
  for (packageslump= file->packages; packageslump; packageslump= packageslump->more) {
    debug(dbg_veryverbose, "isdirectoryinuse packageslump %s ...",
          packageslump->pkgs[0] ? packageslump->pkgs[0]->name : "<none>");
    for (i=0; i < PERFILEPACKAGESLUMP && packageslump->pkgs[i]; i++) {
      debug(dbg_veryverbose, "isdirectoryinuse considering [%d] %s ...", i,
            packageslump->pkgs[i]->name);
      if (packageslump->pkgs[i] == pkg) continue;
      return 1;
    }
  }
  debug(dbg_veryverbose, "isdirectoryinuse no");
  return 0;
}

void oldconffsetflags(struct conffile *searchconff) {
  struct filenamenode *namenode;
  
  while (searchconff) {
    namenode= findnamenode(searchconff->name);
    namenode->flags |= fnnf_old_conff;
    debug(dbg_conffdetail, "oldconffsetflags `%s' namenode %p flags %o",
          searchconff->name, namenode, namenode->flags);
    searchconff= searchconff->next;
  }
}

void ensure_pathname_nonexisting(const char *pathname) {
  int c1;
  const char *u;
#ifdef _WIN32
 struct stat stab;
#endif

  u= skip_slash_dotslash(pathname);
  assert(*u);

  debug(dbg_eachfile,"ensure_pathname_nonexisting `%s'",pathname);
#ifdef _WIN32

 if (lstat(pathname,&stab)) 
    if (errno != ENOTDIR) return;
    else
      return;
 if (!unlink(pathname)) return; /* OK, it was */ 
 
  c1= m_fork();
  if (!c1) {
    execlp(RM,"rm","-rf","--",pathname,(char*)0);
    ohshite(_("failed to exec rm for cleanup"));
  }
  debug(dbg_eachfile,"ensure_pathname_nonexisting running rm -rf");
  waitsubproc(c1,"rm cleanup",0);
  return;
 
#else
  if (!rmdir(pathname)) return; /* Deleted it OK, it was a directory. */
#endif
  if (errno == ENOENT || errno == ELOOP) return;
  if (errno == ENOTDIR) {
    /* Either it's a file, or one of the path components is.  If one
     * of the path components is this will fail again ...
     */
    if (!unlink(pathname)) return; /* OK, it was */
    if (errno == ENOTDIR) return;
  }
    
  if (errno != ENOTEMPTY && errno != EEXIST) /* Huh ? */
    ohshite(_("failed to rmdir/unlink `%.255s'"),pathname);
  c1= m_fork();
  if (!c1) {
    execlp(RM,"rm","-rf","--",pathname,(char*)0);
    ohshite(_("failed to exec rm for cleanup"));
  }
  debug(dbg_eachfile,"ensure_pathname_nonexisting running rm -rf");
  waitsubproc(c1,"rm cleanup",0);
}
