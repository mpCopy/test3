// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class DQS_Clock_Skew.
/// This class is for skews calculation between DQS and Clock singals.

class DQS_Clock_Skew:public Measurement{
public:
        DQS_Clock_Skew();
        virtual ~DQS_Clock_Skew();

        virtual void initialize();
        virtual void event(Trigger* trigger);
        virtual void evaluate(double time);
        virtual void finalize();
        virtual void checkCompliance();
#include "__TDCM__Measurement__DQS_Clock_Skew"

        //vectors to save measurement results
        DoubleVector dqsSkewFallMax;
        DoubleVector dqsSkewFallMin;
        DoubleVector dqsSkewRiseMax;
        DoubleVector dqsSkewRiseMin;
};
