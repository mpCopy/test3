// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "ElectricalDQS.h"
#include <math.h>

ElectricalDQS::ElectricalDQS(){}

ElectricalDQS::~ElectricalDQS(){}

/// Define functions of class ElectricalDQS
/// These functions are for electrical measurement on DQS signal.

void ElectricalDQS::initialize(){
    //package->status("DDR3 ElectricalDQS Initialize");
    setEnableEvaluation(false);
    evalState = false;

    // initial clearup of vectors
    dqsVix.clear();

    // set up triggers with specific threshold voltages
    dqsFallZeroTrigger = addFallingEdgeTrigger(&signal.DQS, 0.0);
    dqsRiseZeroTrigger = addRisingEdgeTrigger(&signal.DQS, 0.0);
}

void ElectricalDQS::event(Trigger* trigger){
    if(trigger == dqsFallZeroTrigger){
        dqsVix.append((trigger->getPositiveSignalValue()-package->parameter.vDD/2)*1e3);
    }
    if(trigger == dqsRiseZeroTrigger){
        dqsVix.append((trigger->getPositiveSignalValue()-package->parameter.vDD/2)*1e3);
    }  
}

void ElectricalDQS::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void ElectricalDQS::finalize(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQS.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("DQSVIX", "Index", generateName(buffer,"DQSVIX",nodeName), dqsVix);
}


void ElectricalDQS::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQS.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    package->check(this,"DQSVIX", dqsVix, generateName(buffer,"DQSVIX",nodeName));
}
