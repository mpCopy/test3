#include "TDCM_Interface.h"
#include "Descriptor.h"

TDCM_EXPORT int TDCM_LoadPackage(const char* packageName,
		const char* instanceName,
		TDCM_Interface* interface,
		int signalSize){
	return TDCM::Package::loadPackage(instanceName,
		interface,signalSize,
		new DDR3_PD);
}

