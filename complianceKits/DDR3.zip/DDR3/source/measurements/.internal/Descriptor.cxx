#include "Descriptor.h"
#include "DataTimingDQ.h"
#include "DataTimingDQS.h"
#include "CmdAddTimingCmdAdd.h"
#include "CmdAddTimingClk.h"
#include "ElectricalDQ.h"
#include "ElectricalDQS.h"
#include "ElectricalCmdAdd.h"
#include "ElectricalClock.h"
#include "DQ_DQS_Skew.h"
#include "CmdAdd_Clock_Skew.h"
#include "DQS_Clock_Skew.h"
using namespace TDCM;
DDR3_DataTimingDQ_MD::DDR3_DataTimingDQ_MD():
	MeasurementDescriptor("DataTimingDQ"){
	this->defineSignal("DQ");
	this->defineSignal("DQ_Reference");
}

DDR3_DataTimingDQ_MD::~DDR3_DataTimingDQ_MD(){}

Measurement* DDR3_DataTimingDQ_MD::createInstance(){
	return (new DataTimingDQ());
}


DDR3_DataTimingDQS_MD::DDR3_DataTimingDQS_MD():
	MeasurementDescriptor("DataTimingDQS"){
	this->defineSignal("DQS");
	this->defineSignal("DQS_Reference");
}

DDR3_DataTimingDQS_MD::~DDR3_DataTimingDQS_MD(){}

Measurement* DDR3_DataTimingDQS_MD::createInstance(){
	return (new DataTimingDQS());
}


DDR3_CmdAddTimingCmdAdd_MD::DDR3_CmdAddTimingCmdAdd_MD():
	MeasurementDescriptor("CmdAddTimingCmdAdd"){
	this->defineSignal("CmdAdd");
	this->defineSignal("CmdAdd_Reference");
}

DDR3_CmdAddTimingCmdAdd_MD::~DDR3_CmdAddTimingCmdAdd_MD(){}

Measurement* DDR3_CmdAddTimingCmdAdd_MD::createInstance(){
	return (new CmdAddTimingCmdAdd());
}


DDR3_CmdAddTimingClk_MD::DDR3_CmdAddTimingClk_MD():
	MeasurementDescriptor("CmdAddTimingClk"){
	this->defineSignal("Clock");
	this->defineSignal("Clock_Reference");
}

DDR3_CmdAddTimingClk_MD::~DDR3_CmdAddTimingClk_MD(){}

Measurement* DDR3_CmdAddTimingClk_MD::createInstance(){
	return (new CmdAddTimingClk());
}


DDR3_ElectricalDQ_MD::DDR3_ElectricalDQ_MD():
	MeasurementDescriptor("ElectricalDQ"){
	this->defineSignal("DQ");
}

DDR3_ElectricalDQ_MD::~DDR3_ElectricalDQ_MD(){}

Measurement* DDR3_ElectricalDQ_MD::createInstance(){
	return (new ElectricalDQ());
}


DDR3_ElectricalDQS_MD::DDR3_ElectricalDQS_MD():
	MeasurementDescriptor("ElectricalDQS"){
	this->defineSignal("DQS");
}

DDR3_ElectricalDQS_MD::~DDR3_ElectricalDQS_MD(){}

Measurement* DDR3_ElectricalDQS_MD::createInstance(){
	return (new ElectricalDQS());
}


DDR3_ElectricalCmdAdd_MD::DDR3_ElectricalCmdAdd_MD():
	MeasurementDescriptor("ElectricalCmdAdd"){
	this->defineSignal("CmdAdd");
}

DDR3_ElectricalCmdAdd_MD::~DDR3_ElectricalCmdAdd_MD(){}

Measurement* DDR3_ElectricalCmdAdd_MD::createInstance(){
	return (new ElectricalCmdAdd());
}


DDR3_ElectricalClock_MD::DDR3_ElectricalClock_MD():
	MeasurementDescriptor("ElectricalClock"){
	this->defineSignal("Clock");
}

DDR3_ElectricalClock_MD::~DDR3_ElectricalClock_MD(){}

Measurement* DDR3_ElectricalClock_MD::createInstance(){
	return (new ElectricalClock());
}


DDR3_DQ_DQS_Skew_MD::DDR3_DQ_DQS_Skew_MD():
	MeasurementDescriptor("DQ_DQS_Skew"){
	this->defineSignal("DQ");
	this->defineSignal("DQ_Reference");
	this->defineSignal("DQS");
	this->defineSignal("DQS_Reference");
}

DDR3_DQ_DQS_Skew_MD::~DDR3_DQ_DQS_Skew_MD(){}

Measurement* DDR3_DQ_DQS_Skew_MD::createInstance(){
	return (new DQ_DQS_Skew());
}


DDR3_CmdAdd_Clock_Skew_MD::DDR3_CmdAdd_Clock_Skew_MD():
	MeasurementDescriptor("CmdAdd_Clock_Skew"){
	this->defineSignal("CmdAdd");
	this->defineSignal("CmdAdd_Reference");
	this->defineSignal("Clock");
	this->defineSignal("Clock_Reference");
}

DDR3_CmdAdd_Clock_Skew_MD::~DDR3_CmdAdd_Clock_Skew_MD(){}

Measurement* DDR3_CmdAdd_Clock_Skew_MD::createInstance(){
	return (new CmdAdd_Clock_Skew());
}


DDR3_DQS_Clock_Skew_MD::DDR3_DQS_Clock_Skew_MD():
	MeasurementDescriptor("DQS_Clock_Skew"){
	this->defineSignal("DQS");
	this->defineSignal("DQS_Reference");
	this->defineSignal("Clock");
	this->defineSignal("Clock_Reference");
}

DDR3_DQS_Clock_Skew_MD::~DDR3_DQS_Clock_Skew_MD(){}

Measurement* DDR3_DQS_Clock_Skew_MD::createInstance(){
	return (new DQS_Clock_Skew());
}


DDR3_PD::DDR3_PD():
PackageDescriptor("DDR3"){
	this->setNumberOfParameters(9);
	init();
	Range* range = NULL;
	range = new Range(RangeUtility::GTE(0.0),RangeUtility::LTE(P_INF));
	defineParameter(0,ParameterUtility::RealParameter("SpeedGrade",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(1,ParameterUtility::RealParameter("vihAC",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(2,ParameterUtility::RealParameter("vihDC",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(3,ParameterUtility::RealParameter("vRef",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(4,ParameterUtility::RealParameter("vilDC",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(5,ParameterUtility::RealParameter("vilAC",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(6,ParameterUtility::RealParameter("vDD",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(7,ParameterUtility::RealParameter("vSS",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(8,ParameterUtility::RealParameter("vMeas",range));

	defineMeasurement(new DDR3_DataTimingDQ_MD);
	defineMeasurement(new DDR3_DataTimingDQS_MD);
	defineMeasurement(new DDR3_CmdAddTimingCmdAdd_MD);
	defineMeasurement(new DDR3_CmdAddTimingClk_MD);
	defineMeasurement(new DDR3_ElectricalDQ_MD);
	defineMeasurement(new DDR3_ElectricalDQS_MD);
	defineMeasurement(new DDR3_ElectricalCmdAdd_MD);
	defineMeasurement(new DDR3_ElectricalClock_MD);
	defineMeasurement(new DDR3_DQ_DQS_Skew_MD);
	defineMeasurement(new DDR3_CmdAdd_Clock_Skew_MD);
	defineMeasurement(new DDR3_DQS_Clock_Skew_MD);

	defineSignalType("DQ");
	defineSignalType("DQ_Reference");
	defineSignalType("DQS");
	defineSignalType("DQS_Reference");
	defineSignalType("CmdAdd");
	defineSignalType("CmdAdd_Reference");
	defineSignalType("Clock");
	defineSignalType("Clock_Reference");
}
DDR3_PD::~DDR3_PD(){}

Package* DDR3_PD::createInstance(){
	Package* package = new DDR3_Package;
	package->setDescriptor(this);
	return package;
}


