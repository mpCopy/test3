#ifndef __DDR3__DESCRIPTOR__INCLUDE_FILE__
#define __DDR3__DESCRIPTOR__INCLUDE_FILE__
#include "TDCM.h"

class DDR3_PD:public TDCM::PackageDescriptor{
public:
	DDR3_PD();
	virtual ~DDR3_PD();
	virtual TDCM::Package* createInstance();
};


class DDR3_DataTimingDQ_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_DataTimingDQ_MD();
	 virtual ~DDR3_DataTimingDQ_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_DataTimingDQS_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_DataTimingDQS_MD();
	 virtual ~DDR3_DataTimingDQS_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_CmdAddTimingCmdAdd_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_CmdAddTimingCmdAdd_MD();
	 virtual ~DDR3_CmdAddTimingCmdAdd_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_CmdAddTimingClk_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_CmdAddTimingClk_MD();
	 virtual ~DDR3_CmdAddTimingClk_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_ElectricalDQ_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_ElectricalDQ_MD();
	 virtual ~DDR3_ElectricalDQ_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_ElectricalDQS_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_ElectricalDQS_MD();
	 virtual ~DDR3_ElectricalDQS_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_ElectricalCmdAdd_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_ElectricalCmdAdd_MD();
	 virtual ~DDR3_ElectricalCmdAdd_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_ElectricalClock_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_ElectricalClock_MD();
	 virtual ~DDR3_ElectricalClock_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_DQ_DQS_Skew_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_DQ_DQS_Skew_MD();
	 virtual ~DDR3_DQ_DQS_Skew_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_CmdAdd_Clock_Skew_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_CmdAdd_Clock_Skew_MD();
	 virtual ~DDR3_CmdAdd_Clock_Skew_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_DQS_Clock_Skew_MD:public TDCM::MeasurementDescriptor{
public:
	DDR3_DQS_Clock_Skew_MD();
	 virtual ~DDR3_DQS_Clock_Skew_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR3_Package:public TDCM::Package{
public:
	DDR3_Package();
	 virtual ~DDR3_Package();
#include "__TDCM__Package__DDR3"

	virtual char* getConstraintsFileName();

	virtual void check(TDCM::Measurement* measurement,
		const char* name,
		TDCM::DoubleVector& value,const char* outputName){
			if(value.size() == 0){

				return;}

			Package::check(measurement,name,value,outputName);
}
			virtual void finalize(){

			Package::finalize();

TDCM::Container<TDCM::Measurement*>* link = measurements.head();
while(link){
TDCM::Measurement* m = link->data();
m->initialize();link = link->next();}}
virtual void initialize(){
char buffer[1024];
if(!this->measurementsCreated){
Package::initialize();
}
}

};


#endif
