// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "Descriptor.h"

using namespace TDCM;

DDR3_Package::DDR3_Package():Package(){}

DDR3_Package::~DDR3_Package(){}

char* DDR3_Package::getConstraintsFileName(){
  char buffer[2048];
  sprintf(buffer,"constraints_%d.xml",(int)parameter.SpeedGrade);
  return buffer;
}


