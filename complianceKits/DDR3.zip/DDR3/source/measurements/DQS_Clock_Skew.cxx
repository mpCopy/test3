// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "DQS_Clock_Skew.h"
#include "DataTimingDQS.h"
#include "CmdAddTimingClk.h"
#include <math.h>

DQS_Clock_Skew::DQS_Clock_Skew(){}

DQS_Clock_Skew::~DQS_Clock_Skew(){}

/// Define functions of class DQS_Clock_Skew
/// These functions are for skews calculation between DQS and Clock singals.

void DQS_Clock_Skew::initialize(){
    // initial clearup of vectors
    dqsSkewFallMax.clear();
    dqsSkewFallMin.clear();
    dqsSkewRiseMax.clear();
    dqsSkewRiseMin.clear();
}
void DQS_Clock_Skew::event(Trigger* trigger){}

void DQS_Clock_Skew::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void DQS_Clock_Skew::finalize(){
    DataTimingDQS*  dqsDataTiming  = (DataTimingDQS*)this->package->getMeasurement("DataTimingDQS",signal.DQS);
    CmdAddTimingClk* clkCmdAddTiming = (CmdAddTimingClk*)this->package->getMeasurement("CmdAddTimingClk",signal.Clock);

    if((!dqsDataTiming) || (!clkCmdAddTiming)){
        package->error("DQS_Clock_Skew requires both DataTimingDQS and CmdAddTimingClock selected.");
        return;
    }

    double tempValue, clkFlightTimeMax, clkFlightTimeMin, dqsFlightTimeFallMax, dqsFlightTimeFallMin, dqsFlightTimeRiseMax, dqsFlightTimeRiseMin;
    int index, numSkip=3;

    // Get max and min clkFlightTime from clkFlightTimeFall and clkFlightTimeRise
    Container<double>* clkFlightTimeFall = clkCmdAddTiming->clkFlightTimeFall.head();
    Container<double>* clkFlightTimeRise = clkCmdAddTiming->clkFlightTimeRise.head();
    if(!(clkFlightTimeFall) || !(clkFlightTimeRise)){
        package->error("No data from CmdAddTimingClock. Check Clock probe connection.");
        return;
    }
    for(index=0; index < numSkip; index++){
        if(clkFlightTimeFall->next())
            clkFlightTimeFall = clkFlightTimeFall->next();
        if(clkFlightTimeRise->next())
            clkFlightTimeRise = clkFlightTimeRise->next();
    }
    clkFlightTimeMax = clkFlightTimeFall->data();
    clkFlightTimeMin = clkFlightTimeFall->data();
    while(clkFlightTimeFall->next()){
        clkFlightTimeFall = clkFlightTimeFall->next();
        tempValue = clkFlightTimeFall->data();
        if(clkFlightTimeMax < tempValue)
            clkFlightTimeMax = tempValue;
        if(clkFlightTimeMin > tempValue)
            clkFlightTimeMin = tempValue;
    }
    while(clkFlightTimeRise->next()){
        clkFlightTimeRise = clkFlightTimeRise->next();
        tempValue = clkFlightTimeRise->data();
        if(clkFlightTimeMax < tempValue)
            clkFlightTimeMax = tempValue;
        if(clkFlightTimeMin > tempValue)
            clkFlightTimeMin = tempValue;
    }

    //Get max and min dqsFlightTime from dqsFlightTimeFall and dqsFlightTimeRise
    //calculate and save dqs to clock skews as:
    //    dqsSkewFallMax = dqsFlightTimeFallMax - clkFlightTimeMin
    //    dqsSkewFallMin = dqsFlightTimeFallMin - clkFlightTimeMax
    //    dqsSkewRiseMax = dqsFlightTimeRiseMax - clkFlightTimeMin
    //    dqsSkewRiseMin = dqsFlightTimeRiseMin - clkFlightTimeMax
    Container<double>* dqsFlightTimeFall = dqsDataTiming->dqsFlightTimeFall.head();
    Container<double>* dqsFlightTimeRise = dqsDataTiming->dqsFlightTimeRise.head();
    if(!(dqsFlightTimeFall) || !(dqsFlightTimeRise)){
        package->error("No data from DataTimingDQS. Check DQS probe connection.");
        return;
    }
    for(index=0; index < numSkip; index++) {
        if(dqsFlightTimeFall->next())
            dqsFlightTimeFall = dqsFlightTimeFall->next();
        if(dqsFlightTimeRise->next())
            dqsFlightTimeRise = dqsFlightTimeRise->next();
    }
    dqsFlightTimeFallMax = dqsFlightTimeFall->data();
    dqsFlightTimeFallMin = dqsFlightTimeFall->data();
    while(dqsFlightTimeFall->next()){
        dqsFlightTimeFall = dqsFlightTimeFall->next();
        tempValue = dqsFlightTimeFall->data();
        if(dqsFlightTimeFallMax < tempValue)
            dqsFlightTimeFallMax = tempValue;
        if(dqsFlightTimeFallMin > tempValue)
            dqsFlightTimeFallMin = tempValue;
    }
    dqsFlightTimeRiseMax = dqsFlightTimeRise->data();
    dqsFlightTimeRiseMin = dqsFlightTimeRise->data();
    while(dqsFlightTimeRise->next()){
        dqsFlightTimeRise = dqsFlightTimeRise->next();
        tempValue = dqsFlightTimeRise->data();
        if(dqsFlightTimeRiseMax < tempValue)
            dqsFlightTimeRiseMax = tempValue;
        if(dqsFlightTimeRiseMin > tempValue)
            dqsFlightTimeRiseMin = tempValue;
    }
    dqsSkewFallMax.append(dqsFlightTimeFallMax - clkFlightTimeMin);
    dqsSkewFallMin.append(dqsFlightTimeFallMin - clkFlightTimeMax);
    dqsSkewRiseMax.append(dqsFlightTimeRiseMax - clkFlightTimeMin);
    dqsSkewRiseMin.append(dqsFlightTimeRiseMin - clkFlightTimeMax);

    // save the results
    PackageSignal* packageSignal = (PackageSignal*)signal.DQS.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("DQS_ClockSkewFallMax", "Index", generateName(buffer,"DQS_ClockSkewFallMax",nodeName), dqsSkewFallMax);
    save("DQS_ClockSkewFallMin", "Index", generateName(buffer,"DQS_ClockSkewFallMin",nodeName), dqsSkewFallMin);
    save("DQS_ClockSkewRiseMax", "Index", generateName(buffer,"DQS_ClockSkewRiseMax",nodeName), dqsSkewRiseMax);
    save("DQS_ClockSkewRiseMin", "Index", generateName(buffer,"DQS_ClockSkewRiseMin",nodeName), dqsSkewRiseMin);
}

void DQS_Clock_Skew::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQS.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    DDR3_Package* p = static_cast<DDR3_Package*>(this->__package__());
   
    p->check(this,"DQS_ClockSkewFallMax", dqsSkewFallMax, generateName(buffer,"DQS_ClockSkewFallMax",nodeName));
    p->check(this,"DQS_ClockSkewFallMin", dqsSkewFallMin, generateName(buffer,"DQS_ClockSkewFallMin",nodeName));
    p->check(this,"DQS_ClockSkewRiseMax", dqsSkewRiseMax, generateName(buffer,"DQS_ClockSkewRiseMax",nodeName));
    p->check(this,"DQS_ClockSkewRiseMin", dqsSkewRiseMin, generateName(buffer,"DQS_ClockSkewRiseMin",nodeName));
}
