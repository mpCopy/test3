// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "DataTimingDQ.h"
#include <math.h>

DataTimingDQ::DataTimingDQ(){}

DataTimingDQ::~DataTimingDQ(){}

/// Define functions of class DataTimingDQ
/// These functions are for data timing measurements on DQ signals.

void DataTimingDQ::initialize(){
    //package->status("DDR3 DataTimingDQ Initialize");
    setEnableEvaluation(true); //evaluation is enabled.
    evalState = true;
    dqSlewRMode = false;
    dqSlewRModeAC150 = false;
    dqFlightTimeSetupAvil = false;
    dqFlightTimeSetupAvilAC150 = false;
    dqReadFlightTimeAvil = false;
    qPop = false;

    // initial clearup of vectors
    dqFlightTimeSetupFall.clear();
    dqFlightTimeSetupRise.clear();
    dqFlightTimeSetupFallAC150.clear();
    dqFlightTimeSetupRiseAC150.clear();
    dqFlightTimeHoldFall.clear();
    dqFlightTimeHoldRise.clear();
    dqReadFlightTimeFallMin.clear();
    dqReadFlightTimeFallMax.clear();
    dqReadFlightTimeRiseMin.clear();
    dqReadFlightTimeRiseMax.clear();
    dqSlewRSetupFall.clear();
    dqSlewRSetupRise.clear();
    dqSlewRSetupFallAC150.clear();
    dqSlewRSetupRiseAC150.clear();
    dqSlewRHoldRise.clear();
    dqSlewRHoldFall.clear();
    dqtVACHigh.clear();
    dqtVACLow.clear();
    dqtVACMarginHigh.clear();
    dqtVACMarginLow.clear();
    dqtVACHighAC150.clear();
    dqtVACLowAC150.clear();
    dqtVACMarginHighAC150.clear();
    dqtVACMarginLowAC150.clear();

    dqSlewRWaveform.clear();
    dqSlewRTime.clear();
    dqSlewRWaveformAC150.clear();
    dqSlewRTimeAC150.clear();
    dqRefFallvMeasTime.clear();
    dqRefRisevMeasTime.clear();
    
    // Set the 2nd AC value.
    SecAcValue = 0.15;
    //If second AC value is not 0.15, the internal result could still be saved in the variables of *AC150.
    //And in the finalize(), the correct output varible names (ACValue) could be used.

    // set up triggers with specific threshold voltages
    dqFallvihACTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vihAC);
    dqFallvihAC150Trigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vRef+SecAcValue);
    dqFallvihDCTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vihDC);
    dqFallvRefTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vRef);
    dqFallvilDCTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vilDC);
    dqFallvilAC150Trigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vRef-SecAcValue);
    dqFallvilACTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vilAC);
    dqRisevilACTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vilAC);
    dqRisevilAC150Trigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vRef-SecAcValue);
    dqRisevilDCTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vilDC);
    dqRisevRefTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vRef);
    dqRisevihDCTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vihDC);
    dqRisevihAC150Trigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vRef+SecAcValue);
    dqRisevihACTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vihAC);

    dqRefFallvMeasTrigger = addFallingEdgeTrigger(&signal.DQ_Reference, package->parameter.vMeas);
    dqRefRisevMeasTrigger = addRisingEdgeTrigger(&signal.DQ_Reference, package->parameter.vMeas);

    // initialize the saved trigger times
    lastdqRefFallvMeas = -1;
    lastdqRefRisevMeas = -1;
    firstdqFallvRef = -1;
    lastdqFallvRef = -1;
    lastdqFallvilDC = -1;
    firstdqFallvilAC = -1;
    lastdqFallvilAC = -1;
    firstdqFallvilAC150 = -1;
    lastdqFallvilAC150 = -1;
    firstdqRisevilAC = -1;
    firstdqRisevilAC150 = -1;
    firstdqRisevilDC = -1;
    lastdqRisevilDC = -1;
    firstdqRisevRef = -1;
    lastdqRisevRef = -1;
    lastdqRisevihDC = -1;
    firstdqRisevihAC = -1;
    lastdqRisevihAC = -1;
    firstdqRisevihAC150 = -1;
    lastdqRisevihAC150 = -1;
    firstdqFallvihAC = -1;
    firstdqFallvihAC150 = -1;
    firstdqFallvihDC = -1;
    lastdqFallvihDC = -1;

    dqFlightTimeSetupTemp = 0;
    dqFlightTimeSetupTempAC150 = 0;
    dqSlewRSetupTemp = 0;
    dqSlewRSetupTempAC150 = 0;
    dqReadFlightTimeMinTemp = 0;
    dqReadFlightTimeMaxTemp = 0;
    UI = 1e-6/package->parameter.SpeedGrade; // one UI
}

void DataTimingDQ::event(Trigger* trigger){
    if(trigger == dqRefFallvMeasTrigger){
        dqRefFallvMeasTime.push(trigger->time());
    }
    if(trigger == dqFallvRefTrigger){
        if(((firstdqFallvRef < 0) || ((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) >= 0.5*UI))) && // the very first falling edge or not the noise at current edge
           ((firstdqRisevRef < 0) || ((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) >= 0.5*UI)))) { // not the noise at any rising edge
            firstdqFallvRef = trigger->time();
            if(!dqRefFallvMeasTime.empty())
                qPop = dqRefFallvMeasTime.pop(&lastdqRefFallvMeas);
            dqReadFlightTimeAvil = false;
            if(lastdqRefFallvMeas > 0){
                dqReadFlightTimeMinTemp = firstdqFallvRef-lastdqRefFallvMeas;
                dqReadFlightTimeAvil = true;
            }
            //calculate and save dqFlightTimeHoldFall and dqSlewRHoldFall (from lastdqFallvihDC to firstdqFallvRef)
            if ((lastdqRefFallvMeas > 0) && (firstdqFallvihDC > 0)){
                // Two conditions: dqFlightTimeHoldFall will be valid.
                // last one: There was a full logic high already. Has enought data for dqSlewRHoldFall.
                dqSlewRMode = false; //finish data collection for dqSlewRHoldFall
                dqSlewRWaveform.append(package->parameter.vRef);
                dqSlewRTime.append(firstdqFallvRef);
                dqFlightTimeHoldFall.append((firstdqFallvihDC-lastdqRefFallvMeas)*1e12);
		Container<double>* waveformLink = dqSlewRWaveform.head();
		Container<double>* timeLink = dqSlewRTime.head();
		Container<double>* waveformLinkTail = dqSlewRWaveform.tail();
		Container<double>* timeLinkTail = dqSlewRTime.tail();
		double vfix = waveformLink->data(); //fix at the first point vihDC
                double tfix = timeLink->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLinkTail->data())/(tfix-timeLinkTail->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                dqSlewRHoldFall.append(slewR*1e-9);
            }
        }
        if((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) < 0.5*UI)) { // close to or is the first crossing 
            lastdqFallvRef = trigger->time();
            //prepare for dqSlewRSetupFall (from lastdqFallvRef to firstdqFallvilAC)
            //prepare for dqSlewRSetupFallAC150 (from lastdqFallvRef to firstdqFallvilAC150)
            //this has to be done for each lastdqFallvRef since we don't know which one is the last yet. 
            dqSlewRMode = true;
            dqSlewRWaveform.clear();
            dqSlewRTime.clear();
            dqSlewRWaveform.append(package->parameter.vRef);
            dqSlewRTime.append(lastdqFallvRef);
            dqSlewRModeAC150 = true;
            dqSlewRWaveformAC150.clear();
            dqSlewRTimeAC150.clear();
            dqSlewRWaveformAC150.append(package->parameter.vRef);
            dqSlewRTimeAC150.append(lastdqFallvRef);
            if(lastdqRefFallvMeas > 0)
                dqReadFlightTimeMaxTemp = lastdqFallvRef-lastdqRefFallvMeas; //To be saved later to make sure the max (last).
        }
    }
    if((trigger == dqFallvilDCTrigger) && (firstdqFallvRef > 0)){
        //entering logic low
        if((trigger->time()-firstdqFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastdqFallvilDC = trigger->time();
        }
    }
    if((trigger == dqFallvilAC150Trigger) && (firstdqFallvRef > 0)){
        if((trigger->time()-firstdqFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastdqFallvilAC150 = trigger->time();
            //calculate and save dqFlightTimeSetupFallAC150 (from dqRefFallvMeas to lastdqFallvilAC150) and dqSlewRSetupFallAC150 (from lastdqFallVref to firstdqFallvilAC150) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstdqRisevilAC150.
            //calculate dqFlightTimeSetupFallAC150
            dqFlightTimeSetupAvilAC150 = false;
            if(lastdqRefFallvMeas > 0){
                //condition: dqFlightTimeSetupFallAC150 will be valid
                dqFlightTimeSetupTempAC150 = lastdqFallvilAC150-lastdqRefFallvMeas;
                dqFlightTimeSetupAvilAC150 = true;
            }
            if((firstdqFallvilAC150 < 0) || ((firstdqFallvilAC150 > 0) && ((trigger->time()-firstdqFallvilAC150) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstdqFallvilAC150 > 0) && ((trigger->time()-firstdqFallvilAC150) < 0.5*UI) && (firstdqFallvilAC150 < lastdqFallvRef))){ // noise but there is dqFallvRef after firstdqFallvilAC150 (noise > vRef-vilAC150) -> reset firstdqFallvilAC150 
                firstdqFallvilAC150 = trigger->time();
                //calculate dqSlewRSetupFallAC150 (from lastdqFallVref to firstdqFallvilAC150)
                dqSlewRModeAC150 = false; //finish data collection for dqSlewRSetupFallAC150
                dqSlewRWaveformAC150.append(package->parameter.vRef-SecAcValue);
                dqSlewRTimeAC150.append(firstdqFallvilAC150);
                Container<double>* waveformLink = dqSlewRWaveformAC150.head();
                Container<double>* timeLink = dqSlewRTimeAC150.head();
                Container<double>* waveformLinkTail = dqSlewRWaveformAC150.tail();
                Container<double>* timeLinkTail = dqSlewRTimeAC150.tail();
                double vfix = waveformLinkTail->data();  //fix at the last point vilAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                dqSlewRSetupTempAC150 = slewR*1e-9;
            }
        }
    }
    if((trigger == dqFallvilACTrigger) && (firstdqFallvRef > 0)){
        if((trigger->time()-firstdqFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastdqFallvilAC = trigger->time();
            //calculate and save dqFlightTimeSetupFall (from dqRefFallvMeas to lastdqFallvilAC) and dqSlewRSetupFall (from lastdqFallVref to firstdqFallvilAC) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstdqRisevilAC.
            //calculate dqFlightTimeSetupFall
            dqFlightTimeSetupAvil = false;
            if(lastdqRefFallvMeas > 0){
                //condition: dqFlightTimeSetupFall will be valid
                dqFlightTimeSetupTemp = lastdqFallvilAC-lastdqRefFallvMeas;
                dqFlightTimeSetupAvil = true;
            }
            if((firstdqFallvilAC < 0) || ((firstdqFallvilAC > 0) && ((trigger->time()-firstdqFallvilAC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstdqFallvilAC > 0) && ((trigger->time()-firstdqFallvilAC) < 0.5*UI) && (firstdqFallvilAC < lastdqFallvRef))){ // noise but there is dqFallvRef after firstdqFallvilAC (noise > vRef-vilAC) -> reset firstdqFallvilAC 
                firstdqFallvilAC = trigger->time();
                //calculate dqSlewRSetupFall (from lastdqFallVref to firstdqFallvilAC)
                dqSlewRMode = false; //finish data collection for dqSlewRSetupFall
                dqSlewRWaveform.append(package->parameter.vilAC);
                dqSlewRTime.append(firstdqFallvilAC);
                Container<double>* waveformLink = dqSlewRWaveform.head();
                Container<double>* timeLink = dqSlewRTime.head();
                Container<double>* waveformLinkTail = dqSlewRWaveform.tail();
                Container<double>* timeLinkTail = dqSlewRTime.tail();
                double vfix = waveformLinkTail->data();  //fix at the last point vilAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                dqSlewRSetupTemp = slewR*1e-9;
            }
        }
    }
    if((trigger == dqRisevilACTrigger) && (firstdqFallvRef > 0)){
        if(((trigger->time()-firstdqFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstdqRisevilAC < 0) || ((firstdqRisevilAC > 0) && ((trigger->time()-firstdqRisevilAC) > 0.5*UI)))){ // not the noise at current edge -> first one
            firstdqRisevilAC = trigger->time(); //no need for lastdqRisevilAC -> don't need to check for noise after firstdqRisevRef
            if(dqFlightTimeSetupAvil){ 
                // save dqFlightTimeSetupFall and dqSlewRSetupFall
                // also calculate and save dqtVACLow since it is related to dqSlewRSetupFall
                dqFlightTimeSetupFall.append(dqFlightTimeSetupTemp*1e12);
                dqSlewRSetupFall.append(dqSlewRSetupTemp);
                dqtVACLow.append((firstdqRisevilAC-lastdqFallvilAC)*1e12);
            }
        }
    }
    if((trigger == dqRisevilAC150Trigger) && (firstdqFallvRef > 0)){
        if(((trigger->time()-firstdqFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstdqRisevilAC150 < 0) || ((firstdqRisevilAC150 > 0) && ((trigger->time()-firstdqRisevilAC150) > 0.5*UI)))){ // not the noise at current edge -> first one
            firstdqRisevilAC150 = trigger->time(); //no need for lastdqRisevilAC150 -> don't need to check for noise after firstdqRisevRef
            if(dqFlightTimeSetupAvilAC150){ 
                // save dqFlightTimeSetupFallAC150 and dqSlewRSetupFallAC150
                // also calculate and save dqtVACLowAC150 since it is related to dqSlewRSetupFallAC150
                dqFlightTimeSetupFallAC150.append(dqFlightTimeSetupTempAC150*1e12);
                dqSlewRSetupFallAC150.append(dqSlewRSetupTempAC150);
                dqtVACLowAC150.append((firstdqRisevilAC150-lastdqFallvilAC150)*1e12);
            }
        }
    }
    if((trigger == dqRisevilDCTrigger) && (firstdqFallvRef > 0)){
        //leaving logic low
        if(((trigger->time()-firstdqFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstdqRisevRef < 0) || ((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) > 0.5*UI)))){ // not the noise after firstdqRiseRef (in a logic high cycle)
            lastdqRisevilDC = trigger->time();
            //prepare for dqSlewRHoldRise from (lastdqRisevilDC to firstdqRisevRef)
            dqSlewRMode = true;
            dqSlewRWaveform.clear();
            dqSlewRTime.clear();
            dqSlewRWaveform.append(package->parameter.vilDC);
            dqSlewRTime.append(lastdqRisevilDC);

            if((firstdqRisevilDC < 0) || ((firstdqRisevilDC > 0) && ((trigger->time()-firstdqRisevilDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstdqRisevilDC = trigger->time();
                //save dqReadFlightTimeMin and dqReadFlightTimeMax together.
                if(dqReadFlightTimeAvil){
                    dqReadFlightTimeFallMin.append(dqReadFlightTimeMinTemp*1e12);
                    dqReadFlightTimeFallMax.append(dqReadFlightTimeMaxTemp*1e12);
                }
            }
        }
    }
    if(trigger == dqRefRisevMeasTrigger){
        dqRefRisevMeasTime.push(trigger->time());
    }
    if(trigger == dqRisevRefTrigger){
        if(((firstdqRisevRef < 0) || ((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) >= 0.5*UI))) && // the very first Rising edge or not the noise at current edge
           ((firstdqFallvRef < 0) || ((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) >= 0.5*UI)))) { // not the noise at any falling edge
            firstdqRisevRef = trigger->time();
            if(!dqRefRisevMeasTime.empty())
                qPop = dqRefRisevMeasTime.pop(&lastdqRefRisevMeas);
            dqReadFlightTimeAvil = false;
            if(lastdqRefRisevMeas > 0){
                dqReadFlightTimeMinTemp = firstdqRisevRef-lastdqRefRisevMeas;
                dqReadFlightTimeAvil = true;
            }
            //calculate and save dqFlightTimeHoldRise and dqSlewRHoldRise (from lastdqRisevilDC to firstdqRisevRef)
            if((lastdqRefRisevMeas > 0) && (firstdqRisevilDC > 0)){
                dqSlewRMode = false; //finish data collection for dqSlewRHoldRise
                dqSlewRWaveform.append(package->parameter.vRef);
                dqSlewRTime.append(firstdqRisevRef);
                dqFlightTimeHoldRise.append((firstdqRisevilDC-lastdqRefRisevMeas)*1e12);
                Container<double>* waveformLink = dqSlewRWaveform.head();
                Container<double>* timeLink = dqSlewRTime.head();
                Container<double>* waveformLinkTail = dqSlewRWaveform.tail();
                Container<double>* timeLinkTail = dqSlewRTime.tail();
                double vfix = waveformLink->data(); // fix at the first point vilDC 
                double tfix = timeLink->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLinkTail->data())/(tfix-timeLinkTail->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                dqSlewRHoldRise.append(slewR*1e-9);
            }
        }
        if((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) < 0.5*UI)) { // close to or is the first crossing 
            lastdqRisevRef = trigger->time();
            //prepare for dqSlewRSetupRise (from lastdqRisevRef to firstdqRisevihAC)
            //prepare for dqSlewRSetupRiseAC150 (from lastdqRisevRef to firstdqRisevihAC150)
            //this has to be done for each lastdqRisevRef since we don't know which one is the last yet.
            dqSlewRMode = true;
            dqSlewRWaveform.clear();
            dqSlewRTime.clear();
            dqSlewRWaveform.append(package->parameter.vRef);
            dqSlewRTime.append(lastdqRisevRef);
            dqSlewRModeAC150 = true;
            dqSlewRWaveformAC150.clear();
            dqSlewRTimeAC150.clear();
            dqSlewRWaveformAC150.append(package->parameter.vRef);
            dqSlewRTimeAC150.append(lastdqRisevRef);
            if(lastdqRefRisevMeas > 0)
                dqReadFlightTimeMaxTemp = lastdqRisevRef-lastdqRefRisevMeas; //To be saved later to make sure the max (last).
        }
    }
    if((trigger == dqRisevihDCTrigger) && (firstdqRisevRef > 0)){
        //entering logic high
        if((trigger->time()-firstdqRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastdqRisevihDC = trigger->time();
        }
    }
    if((trigger == dqRisevihAC150Trigger) && (firstdqRisevRef > 0)){
        if((trigger->time()-firstdqRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastdqRisevihAC150 = trigger->time();
            //calculate and save dqFlightTimeSetupRiseAC150 (from dqRefRisevMeas to lastdqRisevihAC150) and dqSlewRSetupRiseAC150 (from lastdqRiseVref to firstdqRisevihAC150) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstdqFallvihAC150.
            //calculate dqFlightTimeSetupRiseAC150
            dqFlightTimeSetupAvilAC150 = false;
            if(lastdqRefRisevMeas > 0){
                //condition: dqFlightTimeSetupRiseAC150 will be valid
                dqFlightTimeSetupTempAC150 = lastdqRisevihAC150-lastdqRefRisevMeas;
                dqFlightTimeSetupAvilAC150 = true;
            }
            if((firstdqRisevihAC150 < 0) || ((firstdqRisevihAC150 > 0) && ((trigger->time()-firstdqRisevihAC150) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstdqRisevihAC150 > 0) && ((trigger->time()-firstdqRisevihAC150) < 0.5*UI) && (firstdqRisevihAC150 < lastdqRisevRef))){ // noise but there is dqRisevRef after firstdqRisevihAC150 (noise > vihAC150-vRef) -> reset firstdqRisevihAC150 
                firstdqRisevihAC150 = trigger->time();
                //calculate dqSlewRSetupRiseAC150 (from lastdqRiseVref to firstdqRisevihAC150)
                dqSlewRModeAC150 = false; //finish data collection for dqSlewRSetupRiseAC150
                dqSlewRWaveformAC150.append(package->parameter.vRef+SecAcValue);
                dqSlewRTimeAC150.append(firstdqRisevihAC150);
                Container<double>* waveformLink = dqSlewRWaveformAC150.head();
                Container<double>* timeLink = dqSlewRTimeAC150.head();
                Container<double>* waveformLinkTail = dqSlewRWaveformAC150.tail();
                Container<double>* timeLinkTail = dqSlewRTimeAC150.tail();
                double vfix = waveformLinkTail->data(); //fix at the last point vihAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                dqSlewRSetupTempAC150 = slewR*1e-9;
            }
        }
    }
    if((trigger == dqRisevihACTrigger) && (firstdqRisevRef > 0)){
        if((trigger->time()-firstdqRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastdqRisevihAC = trigger->time();
            //calculate and save dqFlightTimeSetupRise (from dqRefRisevMeas to lastdqRisevihAC) and dqSlewRSetupRise (from lastdqRiseVref to firstdqRisevihAC) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstdqFallvihAC.
            //calculate dqFlightTimeSetupRise
            dqFlightTimeSetupAvil = false;
            if(lastdqRefRisevMeas > 0){
                //condition: dqFlightTimeSetupRise will be valid
                dqFlightTimeSetupTemp = lastdqRisevihAC-lastdqRefRisevMeas;
                dqFlightTimeSetupAvil = true;
            }
            if((firstdqRisevihAC < 0) || ((firstdqRisevihAC > 0) && ((trigger->time()-firstdqRisevihAC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstdqRisevihAC > 0) && ((trigger->time()-firstdqRisevihAC) < 0.5*UI) && (firstdqRisevihAC < lastdqRisevRef))){ // noise but there is dqRisevRef after firstdqRisevihAC (noise > vihAC-vRef) -> reset firstdqRisevihAC 
                firstdqRisevihAC = trigger->time();
                //calculate dqSlewRSetupRise (from lastdqRiseVref to firstdqRisevihAC)
                dqSlewRMode = false; //finish data collection for dqSlewRSetupRise
                dqSlewRWaveform.append(package->parameter.vihAC);
                dqSlewRTime.append(firstdqRisevihAC);
                Container<double>* waveformLink = dqSlewRWaveform.head();
                Container<double>* timeLink = dqSlewRTime.head();
                Container<double>* waveformLinkTail = dqSlewRWaveform.tail();
                Container<double>* timeLinkTail = dqSlewRTime.tail();
                double vfix = waveformLinkTail->data(); //fix at the last point vihAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                dqSlewRSetupTemp = slewR*1e-9;
            }
        }
    }
    if((trigger == dqFallvihACTrigger) && (firstdqRisevRef > 0)){
        if(((trigger->time()-firstdqRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstdqFallvihAC < 0) || ((firstdqFallvihAC > 0) && ((trigger->time()-firstdqFallvihAC) > 0.5*UI)))){ // not the noise at current edge -> first one
               firstdqFallvihAC = trigger->time(); //no need for lastdqFallvihAC -> don't need to check for noise after firstdqFallvRef
               if(dqFlightTimeSetupAvil){ 
                   // save dqFlightTimeSetupRise and dqSlewRSetupRise
                   // also calculate and save dqtVACHigh since it is related  to dqSlewRSetupRise
                   dqFlightTimeSetupRise.append(dqFlightTimeSetupTemp*1e12);
                   dqSlewRSetupRise.append(dqSlewRSetupTemp);
                   dqtVACHigh.append((firstdqFallvihAC-lastdqRisevihAC)*1e12);
               }    
        }
    }
    if((trigger == dqFallvihAC150Trigger) && (firstdqRisevRef > 0)){
        if(((trigger->time()-firstdqRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstdqFallvihAC150 < 0) || ((firstdqFallvihAC150 > 0) && ((trigger->time()-firstdqFallvihAC150) > 0.5*UI)))){ // not the noise at current edge -> first one
               firstdqFallvihAC150 = trigger->time(); //no need for lastdqFallvihAC150 -> don't need to check for noise after firstdqFallvRef
               if(dqFlightTimeSetupAvilAC150){ 
                   // save dqFlightTimeSetupRiseAC150 and dqSlewRSetupRiseAC150
                   // also calculate and save dqtVACHighAC150 since it is related to dqSlewRSetupRiseAC150
                   dqFlightTimeSetupRiseAC150.append(dqFlightTimeSetupTempAC150*1e12);
                   dqSlewRSetupRiseAC150.append(dqSlewRSetupTempAC150);
                   dqtVACHighAC150.append((firstdqFallvihAC150-lastdqRisevihAC150)*1e12);
               }
        }
    }
    if((trigger == dqFallvihDCTrigger) && (firstdqRisevRef > 0)){
        //leaving logic high
        if(((trigger->time()-firstdqRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstdqFallvRef < 0) || ((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) > 0.5*UI)))){ // not the noise after firstdqFallRef (in a logic low cycle)
            lastdqFallvihDC = trigger->time();
            //prepare for dqSlewRHoldFall from (lastdqFallvihDC to firstdqFallvRef)
            dqSlewRMode = true;
            dqSlewRWaveform.clear();
            dqSlewRTime.clear();
            dqSlewRWaveform.append(package->parameter.vihDC);
            dqSlewRTime.append(lastdqFallvihDC);        

            if((firstdqFallvihDC < 0) || ((firstdqFallvihDC > 0) && ((trigger->time()-firstdqFallvihDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstdqFallvihDC = trigger->time();
                // save dqReadFlightTimeMin and dqReadFlightTimeMax together.
                if(dqReadFlightTimeAvil){
                    dqReadFlightTimeRiseMin.append(dqReadFlightTimeMinTemp*1e12);
                    dqReadFlightTimeRiseMax.append(dqReadFlightTimeMaxTemp*1e12);
                }
            }
        }
    }   
}

void DataTimingDQ::evaluate(double time){
    if(dqSlewRMode){
        dqSlewRWaveform.append(signal.DQ.p-signal.DQ.n);
        dqSlewRTime.append(time);
    }
    if(dqSlewRModeAC150){
        dqSlewRWaveformAC150.append(signal.DQ.p-signal.DQ.n);
        dqSlewRTimeAC150.append(time);
    }
}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void DataTimingDQ::finalize(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQ.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    double speedGrade = package->parameter.SpeedGrade;

    //get derating tables based on speed grade
    CSVData* Data_tVAC_Constraint = NULL;
    CSVVector* tVAC_Constraint = NULL;
    CSVVector* tVAC_Constraint_AC150 = NULL;
    double tVAC_Constraint_value = 0.0;
    if ((fabs(speedGrade-800.0) < 1e-3) || (fabs(speedGrade-1066.0) < 1e-3)) //800/1066
        Data_tVAC_Constraint = CSVData::parse(this->package,"DDR3_tVAC_constraint.csv");
    else if ((fabs(speedGrade-1333.0) < 1e-3) || (fabs(speedGrade-1600.0) < 1e-3)) //1333/1600
        Data_tVAC_Constraint = CSVData::parse(this->package,"DDR3_tVAC_constraint_DQ_1333_1600.csv");
    else if (fabs(speedGrade-1866.0) < 1e-3) //1866
        Data_tVAC_Constraint = CSVData::parse(this->package,"DDR3_tVAC_constraint_DQ_1866.csv");
    else if (fabs(speedGrade-2133.0) < 1e-3) //2133
        Data_tVAC_Constraint = CSVData::parse(this->package,"DDR3_tVAC_constraint_DQ_2133.csv");
    if(CSVData::errorOccured())
        package->warn(CSVData::error());
    if (Data_tVAC_Constraint)
    {
        tVAC_Constraint = static_cast<CSVVector*>(Data_tVAC_Constraint);
    //Since we don't have the clarification for JEDEC on DQ AC150 yet, the regular tVAC constraint will be used on both AC175 and AC150.
    //CSVData* Data_tVAC_Constraint_AC150 = CSVData::parse(this->package,"DDR3_tVAC_constraint_AC150.csv");;
    //if(CSVData::errorOccured())
    //    package->error(CSVData::error());
    //CSVVector* tVAC_Constraint_AC150 = static_dqst<CSVVector*>(Data_tVAC_Constraint_AC150);
        tVAC_Constraint_AC150 = tVAC_Constraint;
    }

    // calculate tVAC margins.
    Container<double>* dqtVACHighLink = dqtVACHigh.head();
    Container<double>* dqSlewRSetupRiseLink = dqSlewRSetupRise.head();
    Container<double>* dqtVACLowLink = dqtVACLow.head();
    Container<double>* dqSlewRSetupFallLink = dqSlewRSetupFall.head();
    while(dqtVACHighLink && dqSlewRSetupRiseLink){
        tVAC_Constraint_value = 0.0;
        if (tVAC_Constraint)
            tVAC_Constraint_value = tVAC_Constraint->lookup(0,dqSlewRSetupRiseLink->data());
        dqtVACMarginHigh.append(dqtVACHighLink->data() - tVAC_Constraint_value);
        dqtVACHighLink = dqtVACHighLink->next();
        dqSlewRSetupRiseLink = dqSlewRSetupRiseLink->next();
    }
    while(dqtVACLowLink && dqSlewRSetupFallLink){
        tVAC_Constraint_value = 0.0;
        if (tVAC_Constraint)
            tVAC_Constraint_value = tVAC_Constraint->lookup(0,dqSlewRSetupFallLink->data());
        dqtVACMarginLow.append(dqtVACLowLink->data() - tVAC_Constraint_value);
        dqtVACLowLink = dqtVACLowLink->next();
        dqSlewRSetupFallLink = dqSlewRSetupFallLink->next();
    }

    Container<double>* dqtVACHighAC150Link = dqtVACHighAC150.head();
    Container<double>* dqSlewRSetupRiseAC150Link = dqSlewRSetupRiseAC150.head();
    Container<double>* dqtVACLowAC150Link = dqtVACLowAC150.head();
    Container<double>* dqSlewRSetupFallAC150Link = dqSlewRSetupFallAC150.head();
    while(dqtVACHighAC150Link && dqSlewRSetupRiseAC150Link){
        tVAC_Constraint_value = 0.0;
        if (tVAC_Constraint_AC150)
            tVAC_Constraint_value = tVAC_Constraint_AC150->lookup(0,dqSlewRSetupRiseAC150Link->data());
        dqtVACMarginHighAC150.append(dqtVACHighAC150Link->data() - tVAC_Constraint_value);
        dqtVACHighAC150Link = dqtVACHighAC150Link->next();
        dqSlewRSetupRiseAC150Link = dqSlewRSetupRiseAC150Link->next();
    }
    while(dqtVACLowAC150Link && dqSlewRSetupFallAC150Link){
        tVAC_Constraint_value = 0.0;
        if (tVAC_Constraint_AC150)
            tVAC_Constraint_value = tVAC_Constraint_AC150->lookup(0,dqSlewRSetupFallAC150Link->data());
        dqtVACMarginLowAC150.append(dqtVACLowAC150Link->data() - tVAC_Constraint_value);
        dqtVACLowAC150Link = dqtVACLowAC150Link->next();
        dqSlewRSetupFallAC150Link = dqSlewRSetupFallAC150Link->next();
    }

    save("DQFlightTimeSetupFall", "Index", generateName(buffer,"DQFlightTimeSetupFall",nodeName), dqFlightTimeSetupFall);
    save("DQFlightTimeSetupRise", "Index", generateName(buffer,"DQFlightTimeSetupRise",nodeName), dqFlightTimeSetupRise);
    save("DQFlightTimeSetupFallAC150", "Index", generateName(buffer,"DQFlightTimeSetupFallAC150",nodeName), dqFlightTimeSetupFallAC150);
    save("DQFlightTimeSetupRiseAC150", "Index", generateName(buffer,"DQFlightTimeSetupRiseAC150",nodeName), dqFlightTimeSetupRiseAC150);
    save("DQFlightTimeHoldFall", "Index", generateName(buffer,"DQFlightTimeHoldFall",nodeName), dqFlightTimeHoldFall);
    save("DQFlightTimeHoldRise", "Index", generateName(buffer,"DQFlightTimeHoldRise",nodeName), dqFlightTimeHoldRise);
    save("DQFlightTimeReadFallMin", "Index", generateName(buffer,"DQFlightTimeReadFallMin",nodeName), dqReadFlightTimeFallMin);
    save("DQFlightTimeReadFallMax", "Index", generateName(buffer,"DQFlightTimeReadFallMax",nodeName), dqReadFlightTimeFallMax);
    save("DQFlightTimeReadRiseMin", "Index", generateName(buffer,"DQFlightTimeReadRiseMin",nodeName), dqReadFlightTimeRiseMin);
    save("DQFlightTimeReadRiseMax", "Index", generateName(buffer,"DQFlightTimeReadRiseMax",nodeName), dqReadFlightTimeRiseMax);
    save("DQSlewRSetupFall", "Index", generateName(buffer,"DQSlewRSetupFall",nodeName), dqSlewRSetupFall);
    save("DQSlewRSetupRise", "Index", generateName(buffer,"DQSlewRSetupRise",nodeName), dqSlewRSetupRise);
    save("DQSlewRSetupFallAC150", "Index", generateName(buffer,"DQSlewRSetupFallAC150",nodeName), dqSlewRSetupFallAC150);
    save("DQSlewRSetupRiseAC150", "Index", generateName(buffer,"DQSlewRSetupRiseAC150",nodeName), dqSlewRSetupRiseAC150);
    save("DQSlewRHoldFall", "Index", generateName(buffer,"DQSlewRHoldFall",nodeName), dqSlewRHoldFall);
    save("DQSlewRHoldRise", "Index", generateName(buffer,"DQSlewRHoldRise",nodeName), dqSlewRHoldRise);
    save("DQtVACHigh", "Index", generateName(buffer,"DQtVACHigh",nodeName), dqtVACHigh);
    save("DQtVACLow", "Index", generateName(buffer,"DQtVACLow",nodeName), dqtVACLow);
    save("DQtVACMarginHigh", "Index", generateName(buffer,"DQtVACMarginHigh",nodeName), dqtVACMarginHigh);
    save("DQtVACMarginLow", "Index", generateName(buffer,"DQtVACMarginLow",nodeName), dqtVACMarginLow);
    save("DQtVACHighAC150", "Index", generateName(buffer,"DQtVACHighAC150",nodeName), dqtVACHighAC150);
    save("DQtVACLowAC150", "Index", generateName(buffer,"DQtVACLowAC150",nodeName), dqtVACLowAC150);
    save("DQtVACMarginHighAC150", "Index", generateName(buffer,"DQtVACMarginHighAC150",nodeName), dqtVACMarginHighAC150);
    save("DQtVACMarginLowAC150", "Index", generateName(buffer,"DQtVACMarginLowAC150",nodeName), dqtVACMarginLowAC150);
}

void DataTimingDQ::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQ.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    DDR3_Package* p = static_cast<DDR3_Package*>(this->__package__());
    p->check(this,"DQFlightTimeSetupFall", dqFlightTimeSetupFall, generateName(buffer,"DQFlightTimeSetupFall",nodeName));
    p->check(this,"DQFlightTimeSetupRise", dqFlightTimeSetupRise, generateName(buffer,"DQFlightTimeSetupRise",nodeName));
    p->check(this,"DQFlightTimeSetupFallAC150", dqFlightTimeSetupFallAC150, generateName(buffer,"DQFlightTimeSetupFallAC150",nodeName));
    p->check(this,"DQFlightTimeSetupRiseAC150", dqFlightTimeSetupRiseAC150, generateName(buffer,"DQFlightTimeSetupRiseAC150",nodeName));
    p->check(this,"DQFlightTimeHoldFall", dqFlightTimeHoldFall, generateName(buffer,"DQFlightTimeHoldFall",nodeName));
    p->check(this,"DQFlightTimeHoldRise", dqFlightTimeHoldRise, generateName(buffer,"DQFlightTimeHoldRise",nodeName));
    p->check(this,"DQFlightTimeReadFallMin", dqReadFlightTimeFallMin, generateName(buffer,"DQFlightTimeReadFallMin",nodeName));
    p->check(this,"DQFlightTimeReadFallMax", dqReadFlightTimeFallMax, generateName(buffer,"DQFlightTimeReadFallMax",nodeName));
    p->check(this,"DQFlightTimeReadRiseMin", dqReadFlightTimeRiseMin, generateName(buffer,"DQFlightTimeReadRiseMin",nodeName));
    p->check(this,"DQFlightTimeReadRiseMax", dqReadFlightTimeRiseMax, generateName(buffer,"DQFlightTimeReadRiseMax",nodeName));
    p->check(this,"DQSlewRSetupFall", dqSlewRSetupFall, generateName(buffer,"DQSlewRSetupFall",nodeName));
    p->check(this,"DQSlewRSetupRise", dqSlewRSetupRise, generateName(buffer,"DQSlewRSetupRise",nodeName));
    p->check(this,"DQSlewRSetupFallAC150", dqSlewRSetupFallAC150, generateName(buffer,"DQSlewRSetupFallAC150",nodeName));
    p->check(this,"DQSlewRSetupRiseAC150", dqSlewRSetupRiseAC150, generateName(buffer,"DQSlewRSetupRiseAC150",nodeName));
    p->check(this,"DQSlewRHoldFall", dqSlewRHoldFall, generateName(buffer,"DQSlewRHoldFall",nodeName));
    p->check(this,"DQSlewRHoldRise", dqSlewRHoldRise, generateName(buffer,"DQSlewRHoldRise",nodeName));
    p->check(this,"DQtVACHigh", dqtVACHigh, generateName(buffer,"DQtVACHigh",nodeName));
    p->check(this,"DQtVACLow", dqtVACLow, generateName(buffer,"DQtVACLow",nodeName));
    p->check(this,"DQtVACMarginHigh", dqtVACMarginHigh, generateName(buffer,"DQtVACMarginHigh",nodeName));
    p->check(this,"DQtVACMarginLow", dqtVACMarginLow, generateName(buffer,"DQtVACMarginLow",nodeName));
    p->check(this,"DQtVACHighAC150", dqtVACHighAC150, generateName(buffer,"DQtVACHighAC150",nodeName));
    p->check(this,"DQtVACLowAC150", dqtVACLowAC150, generateName(buffer,"DQtVACLowAC150",nodeName));
    p->check(this,"DQtVACMarginHighAC150", dqtVACMarginHighAC150, generateName(buffer,"DQtVACMarginHighAC150",nodeName));
    p->check(this,"DQtVACMarginLowAC150", dqtVACMarginLowAC150, generateName(buffer,"DQtVACMarginLowAC150",nodeName));
}
