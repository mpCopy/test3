// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "CmdAdd_Clock_Skew.h"
#include "CmdAddTimingCmdAdd.h"
#include "CmdAddTimingClk.h"
#include <math.h>

CmdAdd_Clock_Skew::CmdAdd_Clock_Skew(){}

CmdAdd_Clock_Skew::~CmdAdd_Clock_Skew(){}

/// Define functions of class CmdAdd_Clock_Skew
/// These functions are for skews calculation between Cmd/Add and Clock singals.

void CmdAdd_Clock_Skew::initialize(){
    // initial clearup of vectors
    caSkewSetupFall.clear();
    caSkewSetupRise.clear();
    caSkewSetupFallAC150.clear();
    caSkewSetupRiseAC150.clear();
    caSkewHoldFall.clear();
    caSkewHoldRise.clear();
}
void CmdAdd_Clock_Skew::event(Trigger* trigger){}

void CmdAdd_Clock_Skew::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void CmdAdd_Clock_Skew::finalize(){
    CmdAddTimingCmdAdd*  caCmdAddTiming  = (CmdAddTimingCmdAdd*)this->package->getMeasurement("CmdAddTimingCmdAdd",signal.CmdAdd);
    CmdAddTimingClk* clkCmdAddTiming = (CmdAddTimingClk*)this->package->getMeasurement("CmdAddTimingClk",signal.Clock);
    double speedGrade = package->parameter.SpeedGrade; 

    if((!caCmdAddTiming) || (!clkCmdAddTiming)){
        package->error("CmdAdd_Clock_Skew requires both CmdAddTimingCmdAdd and CmdAddTimingClock selected.");
        return;
    }

    double tempValue, clkFlightTimeMax, clkFlightTimeMin, clkSlewRMax;
    int index, numSkip=3;

    // Get max and min clkFlightTime from clkFlightTimeFall and clkFlightTimeRise
    // Get max clkSlewR from clkSlewRFall and clkSkewRRise
    Container<double>* clkFlightTimeFall = clkCmdAddTiming->clkFlightTimeFall.head();
    Container<double>* clkFlightTimeRise = clkCmdAddTiming->clkFlightTimeRise.head();
    Container<double>* clkSlewRFall = clkCmdAddTiming->clkSlewRFall.head();
    Container<double>* clkSlewRRise = clkCmdAddTiming->clkSlewRRise.head();
    if(!(clkFlightTimeFall) || !(clkFlightTimeRise) || !(clkSlewRFall) || !(clkSlewRRise)){
        package->error("No data from CmdAddTimingClock. Check Clock probe connection.");
        return;
    }
    for(index=0; index < numSkip; index++){
        if(clkFlightTimeFall->next())
            clkFlightTimeFall = clkFlightTimeFall->next();
        if(clkFlightTimeRise->next())
            clkFlightTimeRise = clkFlightTimeRise->next();
        if(clkSlewRFall->next())
            clkSlewRFall = clkSlewRFall->next();
        if(clkSlewRRise->next())
            clkSlewRRise = clkSlewRRise->next();
    }
    clkFlightTimeMax = clkFlightTimeFall->data();
    clkFlightTimeMin = clkFlightTimeFall->data();
    while(clkFlightTimeFall->next()){
        clkFlightTimeFall = clkFlightTimeFall->next();
        tempValue = clkFlightTimeFall->data();
        if(clkFlightTimeMax < tempValue)
            clkFlightTimeMax = tempValue;
        if(clkFlightTimeMin > tempValue)
            clkFlightTimeMin = tempValue;
    }
    while(clkFlightTimeRise->next()){
        clkFlightTimeRise = clkFlightTimeRise->next();
        tempValue = clkFlightTimeRise->data();
        if(clkFlightTimeMax < tempValue)
            clkFlightTimeMax = tempValue;
        if(clkFlightTimeMin > tempValue)
            clkFlightTimeMin = tempValue;
    }
    clkSlewRMax = clkSlewRFall->data();
    while(clkSlewRFall->next()){
        clkSlewRFall = clkSlewRFall->next();
        tempValue = clkSlewRFall->data();
        if(clkSlewRMax < tempValue)
            clkSlewRMax = tempValue;
    }
    while(clkSlewRRise->next()){
        clkSlewRRise = clkSlewRRise->next();
        tempValue = clkSlewRRise->data();
        if(clkSlewRMax < tempValue)
            clkSlewRMax = tempValue;
    }

    // calculate derated skews
    Container<double>* caFlightTimeSetupFall = caCmdAddTiming->caFlightTimeSetupFall.head();
    Container<double>* caFlightTimeSetupRise = caCmdAddTiming->caFlightTimeSetupRise.head();
    Container<double>* caFlightTimeSetupFallAC150 = caCmdAddTiming->caFlightTimeSetupFallAC150.head();
    Container<double>* caFlightTimeSetupRiseAC150 = caCmdAddTiming->caFlightTimeSetupRiseAC150.head();
    Container<double>* caFlightTimeHoldFall = caCmdAddTiming->caFlightTimeHoldFall.head();
    Container<double>* caFlightTimeHoldRise = caCmdAddTiming->caFlightTimeHoldRise.head();
    Container<double>* caSlewRSetupFall = caCmdAddTiming->caSlewRSetupFall.head();
    Container<double>* caSlewRSetupRise = caCmdAddTiming->caSlewRSetupRise.head();
    Container<double>* caSlewRSetupFallAC150 = caCmdAddTiming->caSlewRSetupFallAC150.head();
    Container<double>* caSlewRSetupRiseAC150 = caCmdAddTiming->caSlewRSetupRiseAC150.head();
    Container<double>* caSlewRHoldFall = caCmdAddTiming->caSlewRHoldFall.head();
    Container<double>* caSlewRHoldRise = caCmdAddTiming->caSlewRHoldRise.head();

    //get derating tables based on speed grade
    CSVData* Data_Derating_CmdAdd_Setup = NULL;
    CSVData* Data_Derating_CmdAdd_Setup_AC150 = NULL;
    CSVData* Data_Derating_CmdAdd_Hold = NULL;
    CSVMatrix* Derating_CmdAdd_Setup = NULL;
    CSVMatrix* Derating_CmdAdd_Setup_AC150 = NULL;
    CSVMatrix* Derating_CmdAdd_Hold = NULL;
    bool AC125 = false;
    if ((fabs(speedGrade-800.0) < 1e-3) || (fabs(speedGrade-1066.0) < 1e-3) ||
        (fabs(speedGrade-1333.0) < 1e-3) || (fabs(speedGrade-1600.0) < 1e-3)) //800/1066/1333/1600
    {
        Data_Derating_CmdAdd_Setup = CSVData::parse(this->package,"DDR3_derating_table_CmdAdd_Setup.csv");
        Data_Derating_CmdAdd_Setup_AC150 = CSVData::parse(this->package,"DDR3_derating_table_CmdAdd_Setup_AC150.csv");
        Data_Derating_CmdAdd_Hold = CSVData::parse(this->package,"DDR3_derating_table_CmdAdd_Hold.csv");
    }
    else if (fabs(speedGrade-1866.0) < 1e-3) //1866
    {
        Data_Derating_CmdAdd_Setup = CSVData::parse(this->package,"DDR3_derating_table_CmdAdd_Setup_1866.csv");
        Data_Derating_CmdAdd_Setup_AC150 = CSVData::parse(this->package,"DDR3_derating_table_CmdAdd_Setup_1866_AC125.csv");
        Data_Derating_CmdAdd_Hold = CSVData::parse(this->package,"DDR3_derating_table_CmdAdd_Hold_1866.csv");
        AC125 = true;
    }
    else if (fabs(speedGrade-2133.0) < 1e-3) //2133
    {
        Data_Derating_CmdAdd_Setup = CSVData::parse(this->package,"DDR3_derating_table_CmdAdd_Setup_2133.csv");
        Data_Derating_CmdAdd_Setup_AC150 = CSVData::parse(this->package,"DDR3_derating_table_CmdAdd_Setup_2133_AC125.csv");
        Data_Derating_CmdAdd_Hold = CSVData::parse(this->package,"DDR3_derating_table_CmdAdd_Hold_2133.csv");
        AC125 = true;
    }
    if(CSVData::errorOccured())
        package->warn(CSVData::error());
    if (Data_Derating_CmdAdd_Setup)
        Derating_CmdAdd_Setup = static_cast<CSVMatrix*>(Data_Derating_CmdAdd_Setup);
    if (Data_Derating_CmdAdd_Setup_AC150)
        Derating_CmdAdd_Setup_AC150 = static_cast<CSVMatrix*>(Data_Derating_CmdAdd_Setup_AC150);
    if (Data_Derating_CmdAdd_Hold)
        Derating_CmdAdd_Hold = static_cast<CSVMatrix*>(Data_Derating_CmdAdd_Hold);

    // calculate skews
    // setup skews
    while(caFlightTimeSetupFall && caSlewRSetupFall){
        tempValue = caFlightTimeSetupFall->data() - clkFlightTimeMin;
        if (Derating_CmdAdd_Setup)
            tempValue += Derating_CmdAdd_Setup->lookup(clkSlewRMax, caSlewRSetupFall->data());
        caSkewSetupFall.append(tempValue);
        caFlightTimeSetupFall = caFlightTimeSetupFall->next();
        caSlewRSetupFall = caSlewRSetupFall->next();
    }
    while(caFlightTimeSetupRise && caSlewRSetupRise){
        tempValue = caFlightTimeSetupRise->data() - clkFlightTimeMin;
        if (Derating_CmdAdd_Setup)
            tempValue += Derating_CmdAdd_Setup->lookup(clkSlewRMax, caSlewRSetupRise->data());
        caSkewSetupRise.append(tempValue);
        caFlightTimeSetupRise = caFlightTimeSetupRise->next();
        caSlewRSetupRise = caSlewRSetupRise->next();
    }
    while(caFlightTimeSetupFallAC150 && caSlewRSetupFallAC150){
        tempValue = caFlightTimeSetupFallAC150->data() - clkFlightTimeMin;
        if (Derating_CmdAdd_Setup_AC150)
            tempValue += Derating_CmdAdd_Setup_AC150->lookup(clkSlewRMax, caSlewRSetupFallAC150->data());
        caSkewSetupFallAC150.append(tempValue);
        caFlightTimeSetupFallAC150 = caFlightTimeSetupFallAC150->next();
        caSlewRSetupFallAC150 = caSlewRSetupFallAC150->next();
    }
    while(caFlightTimeSetupRiseAC150 && caSlewRSetupRiseAC150){
        tempValue = caFlightTimeSetupRiseAC150->data() - clkFlightTimeMin;
        if (Derating_CmdAdd_Setup_AC150)
            tempValue += Derating_CmdAdd_Setup_AC150->lookup(clkSlewRMax, caSlewRSetupRiseAC150->data());
        caSkewSetupRiseAC150.append(tempValue);
        caFlightTimeSetupRiseAC150 = caFlightTimeSetupRiseAC150->next();
        caSlewRSetupRiseAC150 = caSlewRSetupRiseAC150->next();
    }
    // hold skews
    while(caFlightTimeHoldFall && caSlewRHoldFall){
        tempValue = clkFlightTimeMax - caFlightTimeHoldFall->data();
        if (Derating_CmdAdd_Hold)
            tempValue += Derating_CmdAdd_Hold->lookup(clkSlewRMax, caSlewRHoldFall->data());
        caSkewHoldFall.append(tempValue);
        caFlightTimeHoldFall = caFlightTimeHoldFall->next();
        caSlewRHoldFall = caSlewRHoldFall->next();
    }
    while(caFlightTimeHoldRise && caSlewRHoldRise){
        tempValue = clkFlightTimeMax - caFlightTimeHoldRise->data();
        if (Derating_CmdAdd_Hold)
            tempValue += Derating_CmdAdd_Hold->lookup(clkSlewRMax, caSlewRHoldRise->data());
        caSkewHoldRise.append(tempValue);
        caFlightTimeHoldRise = caFlightTimeHoldRise->next();
        caSlewRHoldRise = caSlewRHoldRise->next();
    }

    // save the results
    PackageSignal* packageSignal = (PackageSignal*)signal.CmdAdd.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("CmdAdd_ClockSkewSetupFall", "Index", generateName(buffer,"CmdAdd_ClockSkewSetupFall",nodeName), caSkewSetupFall);
    save("CmdAdd_ClockSkewSetupRise", "Index", generateName(buffer,"CmdAdd_ClockSkewSetupRise",nodeName), caSkewSetupRise);
    save("CmdAdd_ClockSkewHoldFall", "Index", generateName(buffer,"CmdAdd_ClockSkewHoldFall",nodeName), caSkewHoldFall);
    save("CmdAdd_ClockSkewHoldRise", "Index", generateName(buffer,"CmdAdd_ClockSkewHoldRise",nodeName), caSkewHoldRise);
    if (AC125)
    {   // save in *AC125 output variables
        save("CmdAdd_ClockSkewSetupFallAC125", "Index", generateName(buffer,"CmdAdd_ClockSkewSetupFallAC125",nodeName), caSkewSetupFallAC150);
        save("CmdAdd_ClockSkewSetupRiseAC125", "Index", generateName(buffer,"CmdAdd_ClockSkewSetupRiseAC125",nodeName), caSkewSetupRiseAC150);
    }
    else
    {
        save("CmdAdd_ClockSkewSetupFallAC150", "Index", generateName(buffer,"CmdAdd_ClockSkewSetupFallAC150",nodeName), caSkewSetupFallAC150);
        save("CmdAdd_ClockSkewSetupRiseAC150", "Index", generateName(buffer,"CmdAdd_ClockSkewSetupRiseAC150",nodeName), caSkewSetupRiseAC150);
    }

}

void CmdAdd_Clock_Skew::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.CmdAdd.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    DDR3_Package* p = static_cast<DDR3_Package*>(this->__package__());
    double speedGrade = package->parameter.SpeedGrade;
    bool AC125 = false;
    if ((fabs(speedGrade-1866.0) < 1e-3) || (fabs(speedGrade-2133.0) < 1e-3)) //1866/2133
        AC125 = true;

    p->check(this,"CmdAdd_ClockSkewSetupFall", caSkewSetupFall, generateName(buffer,"CmdAdd_ClockSkewSetupFall",nodeName));
    p->check(this,"CmdAdd_ClockSkewSetupRise", caSkewSetupRise, generateName(buffer,"CmdAdd_ClockSkewSetupRise",nodeName));
    p->check(this,"CmdAdd_ClockSkewHoldFall", caSkewHoldFall, generateName(buffer,"CmdAdd_ClockSkewHoldFall",nodeName));
    p->check(this,"CmdAdd_ClockSkewHoldRise", caSkewHoldRise, generateName(buffer,"CmdAdd_ClockSkewHoldRise",nodeName));
    if (AC125)
    {
        p->check(this,"CmdAdd_ClockSkewSetupFallAC125", caSkewSetupFallAC150, generateName(buffer,"CmdAdd_ClockSkewSetupFallAC125",nodeName));
        p->check(this,"CmdAdd_ClockSkewSetupRiseAC125", caSkewSetupRiseAC150, generateName(buffer,"CmdAdd_ClockSkewSetupRiseAC125",nodeName));
    }
    else
    {
        p->check(this,"CmdAdd_ClockSkewSetupFallAC150", caSkewSetupFallAC150, generateName(buffer,"CmdAdd_ClockSkewSetupFallAC150",nodeName));
        p->check(this,"CmdAdd_ClockSkewSetupRiseAC150", caSkewSetupRiseAC150, generateName(buffer,"CmdAdd_ClockSkewSetupRiseAC150",nodeName));
    }
}
