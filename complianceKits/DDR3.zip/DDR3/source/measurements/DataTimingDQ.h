// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class DataTimingDQ.
/// This class is for data timing measurements on DQ singals.

class DataTimingDQ:public Measurement{
public:
	DataTimingDQ();
	virtual ~DataTimingDQ();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__DataTimingDQ"

        // vectors to save measurement results
        DoubleVector dqFlightTimeSetupFall;
        DoubleVector dqFlightTimeSetupRise;
        DoubleVector dqFlightTimeSetupFallAC150;
        DoubleVector dqFlightTimeSetupRiseAC150;
        DoubleVector dqFlightTimeHoldFall;
        DoubleVector dqFlightTimeHoldRise;
        DoubleVector dqReadFlightTimeFallMin;
        DoubleVector dqReadFlightTimeFallMax;
        DoubleVector dqReadFlightTimeRiseMin;
        DoubleVector dqReadFlightTimeRiseMax;
        DoubleVector dqSlewRSetupFall;
        DoubleVector dqSlewRSetupRise;
        DoubleVector dqSlewRSetupFallAC150;
        DoubleVector dqSlewRSetupRiseAC150;
        DoubleVector dqSlewRHoldFall;
        DoubleVector dqSlewRHoldRise;
        DoubleVector dqtVACHigh;
        DoubleVector dqtVACLow;
        DoubleVector dqtVACMarginHigh;
        DoubleVector dqtVACMarginLow;
        DoubleVector dqtVACHighAC150;
        DoubleVector dqtVACLowAC150;
        DoubleVector dqtVACMarginHighAC150;
        DoubleVector dqtVACMarginLowAC150;

protected:
        // vectors to save wavefrom for slew rate calculation
        DoubleVector dqSlewRWaveform;
        DoubleVector dqSlewRTime;
        DoubleVector dqSlewRWaveformAC150;
        DoubleVector dqSlewRTimeAC150;

        // queues to save DQ_Reference trigger times
        Queue<double> dqRefFallvMeasTime;
        Queue<double> dqRefRisevMeasTime;

        // DQ triggers at threshold voltages
        Trigger* dqFallvihACTrigger;
        Trigger* dqFallvihAC150Trigger;
        Trigger* dqFallvihDCTrigger;
        Trigger* dqFallvRefTrigger;
        Trigger* dqFallvilDCTrigger;
        Trigger* dqFallvilAC150Trigger;
        Trigger* dqFallvilACTrigger;
        Trigger* dqRisevilACTrigger;
        Trigger* dqRisevilAC150Trigger;
        Trigger* dqRisevilDCTrigger;
        Trigger* dqRisevRefTrigger;
        Trigger* dqRisevihDCTrigger;
        Trigger* dqRisevihAC150Trigger;
        Trigger* dqRisevihACTrigger;

        // DQ_Reference triggers
        Trigger* dqRefFallvMeasTrigger;
        Trigger* dqRefRisevMeasTrigger;

        bool evalState;
        bool dqSlewRMode;
        bool dqSlewRModeAC150;
        bool dqFlightTimeSetupAvil;
        bool dqFlightTimeSetupAvilAC150;
        bool dqReadFlightTimeAvil;
        bool qPop;

        // variables to save trigger times
        double lastdqRefFallvMeas;
        double lastdqRefRisevMeas;
        double firstdqFallvRef;
        double lastdqFallvRef;
        double lastdqFallvilDC;
        double firstdqFallvilAC;
        double lastdqFallvilAC;
        double firstdqFallvilAC150;
        double lastdqFallvilAC150;
        double firstdqRisevilAC;
        double firstdqRisevilAC150;
        double firstdqRisevilDC;
        double lastdqRisevilDC;
        double firstdqRisevRef;
        double lastdqRisevRef;
        double lastdqRisevihDC;
        double firstdqRisevihAC;
        double lastdqRisevihAC;
        double firstdqRisevihAC150;
        double lastdqRisevihAC150;
        double firstdqFallvihAC;
        double firstdqFallvihAC150;
        double firstdqFallvihDC;
        double lastdqFallvihDC;

        double dqFlightTimeSetupTemp;
        double dqFlightTimeSetupTempAC150;
        double dqSlewRSetupTemp;
        double dqSlewRSetupTempAC150;
        double dqReadFlightTimeMinTemp;
        double dqReadFlightTimeMaxTemp;
        double UI;
        double SecAcValue;
};
