// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "DataTimingDQS.h"
#include <math.h>

DataTimingDQS::DataTimingDQS(){}

DataTimingDQS::~DataTimingDQS(){}

/// Define functions of class DataTimingDQS
/// These functions are for data timing measurements on DQS signal.

void DataTimingDQS::initialize(){
    //package->status("DDR3 DataTimingDQS Initialize");
    setEnableEvaluation(false);
    evalState = false;
    qPop = false;

    // initial cleanup of vectors
    dqsFlightTimeFall.clear();
    dqsFlightTimeRise.clear();
    dqsSlewRFall.clear();
    dqsSlewRRise.clear();

    dqsRefFallZeroTime.clear();
    dqsRefRiseZeroTime.clear();
    
    // set up triggers with specific threshold voltages
    dqsFall0p2Trigger = addFallingEdgeTrigger(&signal.DQS, 0.2);
    dqsFallZeroTrigger = addFallingEdgeTrigger(&signal.DQS, 0.0);
    dqsFallm0p2Trigger = addFallingEdgeTrigger(&signal.DQS, -0.2);
    dqsRisem0p2Trigger = addRisingEdgeTrigger(&signal.DQS, -0.2);
    dqsRiseZeroTrigger = addRisingEdgeTrigger(&signal.DQS, 0.0);
    dqsRise0p2Trigger = addRisingEdgeTrigger(&signal.DQS, 0.2);

    dqsRefFallZeroTrigger = addFallingEdgeTrigger(&signal.DQS_Reference, 0.0);
    dqsRefRiseZeroTrigger = addRisingEdgeTrigger(&signal.DQS_Reference, 0.0);

    // initialize the saved trigger times
    lastdqsRefFallZero = -1;
    lastdqsRefRiseZero = -1;
    lastdqsFall0p2 = -1;
    lastdqsRisem0p2 = -1;
}

void DataTimingDQS::event(Trigger* trigger){
    if(trigger == dqsRefFallZeroTrigger){
        dqsRefFallZeroTime.push(trigger->time());
    }
    if(trigger == dqsFallZeroTrigger){
        if(!dqsRefFallZeroTime.empty()){
            qPop = dqsRefFallZeroTime.pop(&lastdqsRefFallZero);
            dqsFlightTimeFall.append((trigger->time()-lastdqsRefFallZero)*1e12);
        }
    }
    if(trigger == dqsFallm0p2Trigger){
        if(lastdqsFall0p2 > 0)
            dqsSlewRFall.append(0.4/(trigger->time()-lastdqsFall0p2)*1e-9);
    }
    if(trigger == dqsRisem0p2Trigger){
        lastdqsRisem0p2 = trigger->time();
    }
    if(trigger == dqsRefRiseZeroTrigger){
        dqsRefRiseZeroTime.push(trigger->time());
    }
    if(trigger == dqsRiseZeroTrigger){
        if(!dqsRefRiseZeroTime.empty()){
            qPop = dqsRefRiseZeroTime.pop(&lastdqsRefRiseZero);
            dqsFlightTimeRise.append((trigger->time()-lastdqsRefRiseZero)*1e12);
        }
    }
    if(trigger == dqsRise0p2Trigger){
        if(lastdqsRisem0p2 > 0)
            dqsSlewRRise.append(0.4/(trigger->time()-lastdqsRisem0p2)*1e-9);
    }
    if(trigger == dqsFall0p2Trigger){
        lastdqsFall0p2 = trigger->time();
    }   
}

void DataTimingDQS::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void DataTimingDQS::finalize(){
  PackageSignal* packageSignal = (PackageSignal*)signal.DQS.packageSignal;
  const char* nodeName =  this->package->getNodeName(packageSignal->positive);
  char buffer[4096];
  save("DQSFlightTimeFall", "Index", generateName(buffer,"DQSFlightTimeFall",nodeName), dqsFlightTimeFall);
  save("DQSFlightTimeRise", "Index", generateName(buffer,"DQSFlightTimeRise",nodeName), dqsFlightTimeRise);
  save("DQSSlewRFall", "Index", generateName(buffer,"DQSSlewRFall",nodeName), dqsSlewRFall);
  save("DQSSlewRRise", "Index", generateName(buffer,"DQSSlewRRise",nodeName), dqsSlewRRise);
}

void DataTimingDQS::checkCompliance(){
  PackageSignal* packageSignal = (PackageSignal*)signal.DQS.packageSignal;
  const char* nodeName =  this->package->getNodeName(packageSignal->positive);
  char buffer[4096];
  DDR3_Package* p = static_cast<DDR3_Package*>(this->__package__());
   
  p->check(this,"DQSFlightTimeFall", dqsFlightTimeFall, generateName(buffer,"DQSFlightTimeFall",nodeName));
  p->check(this,"DQSFlightTimeRise", dqsFlightTimeRise, generateName(buffer,"DQSFlightTimeRise",nodeName));
  p->check(this,"DQSSlewRFall", dqsSlewRFall, generateName(buffer,"DQSSlewRFall",nodeName));
  p->check(this,"DQSSlewRRise", dqsSlewRRise, generateName(buffer,"DQSSlewRRise",nodeName));
}
