// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "CmdAddTimingCmdAdd.h"
#include <math.h>

CmdAddTimingCmdAdd::CmdAddTimingCmdAdd(){}

CmdAddTimingCmdAdd::~CmdAddTimingCmdAdd(){}

/// Define functions of class CmdAddTimingCmdAdd
/// These functions are for Command/Address timing measurements on Command/Address signals.

void CmdAddTimingCmdAdd::initialize(){
    //package->status("DDR3 CmdAddTimingCmdAdd Initialize");
    setEnableEvaluation(true); //evaluation is enabled.
    evalState = true;
    caSlewRMode = false;
    caSlewRModeAC150 = false;
    caFlightTimeSetupAvil = false;
    caFlightTimeSetupAvilAC150 = false;
    qPop = false;

    // initial clearup of vectors
    caFlightTimeSetupFall.clear();
    caFlightTimeSetupRise.clear();
    caFlightTimeSetupFallAC150.clear();
    caFlightTimeSetupRiseAC150.clear();
    caFlightTimeHoldFall.clear();
    caFlightTimeHoldRise.clear();
    caSlewRSetupFall.clear();
    caSlewRSetupRise.clear();
    caSlewRSetupFallAC150.clear();
    caSlewRSetupRiseAC150.clear();
    caSlewRHoldRise.clear();
    caSlewRHoldFall.clear();
    catVACHigh.clear();
    catVACLow.clear();
    catVACMarginHigh.clear();
    catVACMarginLow.clear();
    catVACHighAC150.clear();
    catVACLowAC150.clear();
    catVACMarginHighAC150.clear();
    catVACMarginLowAC150.clear();

    caSlewRWaveform.clear();
    caSlewRTime.clear();
    caSlewRWaveformAC150.clear();
    caSlewRTimeAC150.clear();
    caRefFallvMeasTime.clear();
    caRefRisevMeasTime.clear();
    
    // Set the 2nd AC value based on speed grade
    SecAcValue = 0.15;
    if ((fabs(package->parameter.SpeedGrade-1866.0) < 1e-3) || (fabs(package->parameter.SpeedGrade-2133.0) < 1e-3)) //1866/2133
        SecAcValue = 0.125; 
    //Second AC value is 0.125 for 1866/2133 speed grades. But the variables of *AC150 are still used to save the internal results.
    //And in the finalize(), the correct output varible names (*AC125) will be used.

    // set up triggers with specific threshold voltages
    caFallvihACTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vihAC);
    caFallvihAC150Trigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vRef+SecAcValue);
    caFallvihDCTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vihDC);
    caFallvRefTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vRef);
    caFallvilDCTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vilDC);
    caFallvilAC150Trigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vRef-SecAcValue);
    caFallvilACTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vilAC);
    caRisevilACTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vilAC);
    caRisevilAC150Trigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vRef-SecAcValue);
    caRisevilDCTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vilDC);
    caRisevRefTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vRef);
    caRisevihDCTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vihDC);
    caRisevihAC150Trigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vRef+SecAcValue);
    caRisevihACTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vihAC);

    caRefFallvMeasTrigger = addFallingEdgeTrigger(&signal.CmdAdd_Reference, package->parameter.vMeas);
    caRefRisevMeasTrigger = addRisingEdgeTrigger(&signal.CmdAdd_Reference, package->parameter.vMeas);

    // initialize the saved trigger times
    lastcaRefFallvMeas = -1;
    lastcaRefRisevMeas = -1;
    firstcaFallvRef = -1;
    lastcaFallvRef = -1;
    lastcaFallvilDC = -1;
    firstcaFallvilAC = -1;
    lastcaFallvilAC = -1;
    firstcaFallvilAC150 = -1;
    lastcaFallvilAC150 = -1;
    firstcaRisevilAC = -1;
    firstcaRisevilAC150 = -1;
    firstcaRisevilDC = -1;
    lastcaRisevilDC = -1;
    firstcaRisevRef = -1;
    lastcaRisevRef = -1;
    lastcaRisevihDC = -1;
    firstcaRisevihAC = -1;
    lastcaRisevihAC = -1;
    firstcaRisevihAC150 = -1;
    lastcaRisevihAC150 = -1;
    firstcaFallvihAC = -1;
    firstcaFallvihAC150 = -1;
    firstcaFallvihDC = -1;
    lastcaFallvihDC = -1;

    caFlightTimeSetupTemp = 0;
    caFlightTimeSetupTempAC150 = 0;
    caSlewRSetupTemp = 0;
    caSlewRSetupTempAC150 = 0;
    UI = 1e-6/package->parameter.SpeedGrade; // one UI
}

void CmdAddTimingCmdAdd::event(Trigger* trigger){
    if(trigger == caRefFallvMeasTrigger){
        caRefFallvMeasTime.push(trigger->time());
    }
    if(trigger == caFallvRefTrigger){
        if(((firstcaFallvRef < 0) || ((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) >= 0.5*UI))) && // the very first falling edge or not the noise at current edge
           ((firstcaRisevRef < 0) || ((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) >= 0.5*UI)))) { // not the noise at any rising edge
            firstcaFallvRef = trigger->time();
            if(!caRefFallvMeasTime.empty())
                qPop = caRefFallvMeasTime.pop(&lastcaRefFallvMeas);
            //calculate and save caFlightTimeHoldFall and caSlewRHoldFall (from lastcaFallvihDC to firstcaFallvRef)
            if ((lastcaRefFallvMeas > 0) && (firstcaFallvihDC > 0)){
                // Two conditions: caFlightTimeHoldFall will be valid.
                // last one: There was a full logic high already. Has enought data for caSlewRHoldFall.
                caSlewRMode = false; //finish data collection for caSlewRHoldFall
                caSlewRWaveform.append(package->parameter.vRef);
                caSlewRTime.append(firstcaFallvRef);
                caFlightTimeHoldFall.append((firstcaFallvihDC-lastcaRefFallvMeas)*1e12);
		Container<double>* waveformLink = caSlewRWaveform.head();
		Container<double>* timeLink = caSlewRTime.head();
		Container<double>* waveformLinkTail = caSlewRWaveform.tail();
		Container<double>* timeLinkTail = caSlewRTime.tail();
		double vfix = waveformLink->data(); //fix at the first point vihDC
                double tfix = timeLink->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLinkTail->data())/(tfix-timeLinkTail->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                caSlewRHoldFall.append(slewR*1e-9);
            }
        }
        if((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) < 0.5*UI)) { // close to or is the first crossing 
            lastcaFallvRef = trigger->time();
            //prepare for caSlewRSetupFall (from lastcaFallvRef to firstcaFallvilAC)
            //prepare for caSlewRSetupFallAC150 (from lastcaFallvRef to firstcaFallvilAC150)
            //this has to be done for each lastcaFallvRef since we don't know which one is the last yet. 
            caSlewRMode = true;
            caSlewRWaveform.clear();
            caSlewRTime.clear();
            caSlewRWaveform.append(package->parameter.vRef);
            caSlewRTime.append(lastcaFallvRef);
            caSlewRModeAC150 = true;
            caSlewRWaveformAC150.clear();
            caSlewRTimeAC150.clear();
            caSlewRWaveformAC150.append(package->parameter.vRef);
            caSlewRTimeAC150.append(lastcaFallvRef);
        }
    }
    if((trigger == caFallvilDCTrigger) && (firstcaFallvRef > 0)){
        //entering logic low
        if((trigger->time()-firstcaFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastcaFallvilDC = trigger->time();
        }
    }
    if((trigger == caFallvilAC150Trigger) && (firstcaFallvRef > 0)){
        if((trigger->time()-firstcaFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastcaFallvilAC150 = trigger->time();
            //calculate and save caFlightTimeSetupFallAC150 (from caRefFallvMeas to lastcaFallvilAC150) and caSlewRSetupFallAC150 (from lastcaFallVref to firstcaFallvilAC150) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstcaRisevilAC150.
            //calculate caFlightTimeSetupFallAC150
            caFlightTimeSetupAvilAC150 = false;
            if(lastcaRefFallvMeas > 0){
                //condition: caFlightTimeSetupFallAC150 will be valid
                caFlightTimeSetupTempAC150 = lastcaFallvilAC150-lastcaRefFallvMeas;
                caFlightTimeSetupAvilAC150 = true;
            }
            if((firstcaFallvilAC150 < 0) || ((firstcaFallvilAC150 > 0) && ((trigger->time()-firstcaFallvilAC150) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstcaFallvilAC150 > 0) && ((trigger->time()-firstcaFallvilAC150) < 0.5*UI) && (firstcaFallvilAC150 < lastcaFallvRef))){ // noise but there is caFallvRef after firstcaFallvilAC150 (noise > vRef-vilAC150) -> reset firstcaFallvilAC150 
                firstcaFallvilAC150 = trigger->time();
                //calculate caSlewRSetupFallAC150 (from lastcaFallVref to firstcaFallvilAC150)
                caSlewRModeAC150 = false; //finish data collection for caSlewRSetupFallAC150
                caSlewRWaveformAC150.append(package->parameter.vRef-SecAcValue);
                caSlewRTimeAC150.append(firstcaFallvilAC150);
                Container<double>* waveformLink = caSlewRWaveformAC150.head();
                Container<double>* timeLink = caSlewRTimeAC150.head();
                Container<double>* waveformLinkTail = caSlewRWaveformAC150.tail();
                Container<double>* timeLinkTail = caSlewRTimeAC150.tail();
                double vfix = waveformLinkTail->data();  //fix at the last point vilAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                caSlewRSetupTempAC150 = slewR*1e-9;
            }
        }
    }
    if((trigger == caFallvilACTrigger) && (firstcaFallvRef > 0)){
        if((trigger->time()-firstcaFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastcaFallvilAC = trigger->time();
            //calculate and save caFlightTimeSetupFall (from caRefFallvMeas to lastcaFallvilAC) and caSlewRSetupFall (from lastcaFallVref to firstcaFallvilAC) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstcaRisevilAC.
            //calculate caFlightTimeSetupFall
            caFlightTimeSetupAvil = false;
            if(lastcaRefFallvMeas > 0){
                //condition: caFlightTimeSetupFall will be valid
                caFlightTimeSetupTemp = lastcaFallvilAC-lastcaRefFallvMeas;
                caFlightTimeSetupAvil = true;
            }
            if((firstcaFallvilAC < 0) || ((firstcaFallvilAC > 0) && ((trigger->time()-firstcaFallvilAC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstcaFallvilAC > 0) && ((trigger->time()-firstcaFallvilAC) < 0.5*UI) && (firstcaFallvilAC < lastcaFallvRef))){ // noise but there is caFallvRef after firstcaFallvilAC (noise > vRef-vilAC) -> reset firstcaFallvilAC 
                firstcaFallvilAC = trigger->time();
                //calculate caSlewRSetupFall (from lastcaFallVref to firstcaFallvilAC)
                caSlewRMode = false; //finish data collection for caSlewRSetupFall
                caSlewRWaveform.append(package->parameter.vilAC);
                caSlewRTime.append(firstcaFallvilAC);
                Container<double>* waveformLink = caSlewRWaveform.head();
                Container<double>* timeLink = caSlewRTime.head();
                Container<double>* waveformLinkTail = caSlewRWaveform.tail();
                Container<double>* timeLinkTail = caSlewRTime.tail();
                double vfix = waveformLinkTail->data();  //fix at the last point vilAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                caSlewRSetupTemp = slewR*1e-9;
            }
        }
    }
    if((trigger == caRisevilACTrigger) && (firstcaFallvRef > 0)){
        if(((trigger->time()-firstcaFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstcaRisevilAC < 0) || ((firstcaRisevilAC > 0) && ((trigger->time()-firstcaRisevilAC) > 0.5*UI)))){ // not the noise at current edge -> first one
            firstcaRisevilAC = trigger->time(); //no need for lastcaRisevilAC -> don't need to check for noise after firstcaRisevRef
            if(caFlightTimeSetupAvil){ 
                // save caFlightTimeSetupFall and caSlewRSetupFall
                // also calculate and save catVACLow since it is related to caSlewRSetupFall
                caFlightTimeSetupFall.append(caFlightTimeSetupTemp*1e12);
                caSlewRSetupFall.append(caSlewRSetupTemp);
                catVACLow.append((firstcaRisevilAC-lastcaFallvilAC)*1e12);
            }
        }
    }
    if((trigger == caRisevilAC150Trigger) && (firstcaFallvRef > 0)){
        if(((trigger->time()-firstcaFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstcaRisevilAC150 < 0) || ((firstcaRisevilAC150 > 0) && ((trigger->time()-firstcaRisevilAC150) > 0.5*UI)))){ // not the noise at current edge -> first one
            firstcaRisevilAC150 = trigger->time(); //no need for lastcaRisevilAC150 -> don't need to check for noise after firstcaRisevRef
            if(caFlightTimeSetupAvilAC150){ 
                // save caFlightTimeSetupFallAC150 and caSlewRSetupFallAC150
                // also calculate and save catVACLowAC150 since it is related to caSlewRSetupFallAC150
                caFlightTimeSetupFallAC150.append(caFlightTimeSetupTempAC150*1e12);
                caSlewRSetupFallAC150.append(caSlewRSetupTempAC150);
                catVACLowAC150.append((firstcaRisevilAC150-lastcaFallvilAC150)*1e12);
            }
        }
    }
    if((trigger == caRisevilDCTrigger) && (firstcaFallvRef > 0)){
        //leaving logic low
        if(((trigger->time()-firstcaFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstcaRisevRef < 0) || ((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) > 0.5*UI)))){ // not the noise after firstcaRiseRef (in a logic high cycle)
            lastcaRisevilDC = trigger->time();
            //prepare for caSlewRHoldRise from (lastcaRisevilDC to firstcaRisevRef)
            caSlewRMode = true;
            caSlewRWaveform.clear();
            caSlewRTime.clear();
            caSlewRWaveform.append(package->parameter.vilDC);
            caSlewRTime.append(lastcaRisevilDC);

            if((firstcaRisevilDC < 0) || ((firstcaRisevilDC > 0) && ((trigger->time()-firstcaRisevilDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstcaRisevilDC = trigger->time();
            }
        }
    }
    if(trigger == caRefRisevMeasTrigger){
        caRefRisevMeasTime.push(trigger->time());
    }
    if(trigger == caRisevRefTrigger){
        if(((firstcaRisevRef < 0) || ((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) >= 0.5*UI))) && // the very first Rising edge or not the noise at current edge
           ((firstcaFallvRef < 0) || ((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) >= 0.5*UI)))) { // not the noise at any falling edge
            firstcaRisevRef = trigger->time();
            if(!caRefRisevMeasTime.empty())
                qPop = caRefRisevMeasTime.pop(&lastcaRefRisevMeas);
            //calculate and save caFlightTimeHoldRise and caSlewRHoldRise (from lastcaRisevilDC to firstcaRisevRef)
            if((lastcaRefRisevMeas > 0) && (firstcaRisevilDC > 0)){
                caSlewRMode = false; //finish data collection for caSlewRHoldRise
                caSlewRWaveform.append(package->parameter.vRef);
                caSlewRTime.append(firstcaRisevRef);
                caFlightTimeHoldRise.append((firstcaRisevilDC-lastcaRefRisevMeas)*1e12);
                Container<double>* waveformLink = caSlewRWaveform.head();
                Container<double>* timeLink = caSlewRTime.head();
                Container<double>* waveformLinkTail = caSlewRWaveform.tail();
                Container<double>* timeLinkTail = caSlewRTime.tail();
                double vfix = waveformLink->data(); // fix at the first point vilDC 
                double tfix = timeLink->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLinkTail->data())/(tfix-timeLinkTail->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                caSlewRHoldRise.append(slewR*1e-9);
            }
        }
        if((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) < 0.5*UI)) { // close to or is the first crossing 
            lastcaRisevRef = trigger->time();
            //prepare for caSlewRSetupRise (from lastcaRisevRef to firstcaRisevihAC)
            //prepare for caSlewRSetupRiseAC150 (from lastcaRisevRef to firstcaRisevihAC150)
            //this has to be done for each lastcaRisevRef since we don't know which one is the last yet.
            caSlewRMode = true;
            caSlewRWaveform.clear();
            caSlewRTime.clear();
            caSlewRWaveform.append(package->parameter.vRef);
            caSlewRTime.append(lastcaRisevRef);
            caSlewRModeAC150 = true;
            caSlewRWaveformAC150.clear();
            caSlewRTimeAC150.clear();
            caSlewRWaveformAC150.append(package->parameter.vRef);
            caSlewRTimeAC150.append(lastcaRisevRef);
        }
    }
    if((trigger == caRisevihDCTrigger) && (firstcaRisevRef > 0)){
        //entering logic high
        if((trigger->time()-firstcaRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastcaRisevihDC = trigger->time();
        }
    }
    if((trigger == caRisevihAC150Trigger) && (firstcaRisevRef > 0)){
        if((trigger->time()-firstcaRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastcaRisevihAC150 = trigger->time();
            //calculate and save caFlightTimeSetupRiseAC150 (from caRefRisevMeas to lastcaRisevihAC150) and caSlewRSetupRiseAC150 (from lastcaRiseVref to firstcaRisevihAC150) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstcaFallvihAC150.
            //calculate caFlightTimeSetupRiseAC150
            caFlightTimeSetupAvilAC150 = false;
            if(lastcaRefRisevMeas > 0){
                //condition: caFlightTimeSetupRiseAC150 will be valid
                caFlightTimeSetupTempAC150 = lastcaRisevihAC150-lastcaRefRisevMeas;
                caFlightTimeSetupAvilAC150 = true;
            }
            if((firstcaRisevihAC150 < 0) || ((firstcaRisevihAC150 > 0) && ((trigger->time()-firstcaRisevihAC150) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstcaRisevihAC150 > 0) && ((trigger->time()-firstcaRisevihAC150) < 0.5*UI) && (firstcaRisevihAC150 < lastcaRisevRef))){ // noise but there is caRisevRef after firstcaRisevihAC150 (noise > vihAC150-vRef) -> reset firstcaRisevihAC150 
                firstcaRisevihAC150 = trigger->time();
                //calculate caSlewRSetupRiseAC150 (from lastcaRiseVref to firstcaRisevihAC150)
                caSlewRModeAC150 = false; //finish data collection for caSlewRSetupRiseAC150
                caSlewRWaveformAC150.append(package->parameter.vRef+SecAcValue);
                caSlewRTimeAC150.append(firstcaRisevihAC150);
                Container<double>* waveformLink = caSlewRWaveformAC150.head();
                Container<double>* timeLink = caSlewRTimeAC150.head();
                Container<double>* waveformLinkTail = caSlewRWaveformAC150.tail();
                Container<double>* timeLinkTail = caSlewRTimeAC150.tail();
                double vfix = waveformLinkTail->data(); //fix at the last point vihAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                caSlewRSetupTempAC150 = slewR*1e-9;
            }
        }
    }
    if((trigger == caRisevihACTrigger) && (firstcaRisevRef > 0)){
        if((trigger->time()-firstcaRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastcaRisevihAC = trigger->time();
            //calculate and save caFlightTimeSetupRise (from caRefRisevMeas to lastcaRisevihAC) and caSlewRSetupRise (from lastcaRiseVref to firstcaRisevihAC) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstcaFallvihAC.
            //calculate caFlightTimeSetupRise
            caFlightTimeSetupAvil = false;
            if(lastcaRefRisevMeas > 0){
                //condition: caFlightTimeSetupRise will be valid
                caFlightTimeSetupTemp = lastcaRisevihAC-lastcaRefRisevMeas;
                caFlightTimeSetupAvil = true;
            }
            if((firstcaRisevihAC < 0) || ((firstcaRisevihAC > 0) && ((trigger->time()-firstcaRisevihAC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstcaRisevihAC > 0) && ((trigger->time()-firstcaRisevihAC) < 0.5*UI) && (firstcaRisevihAC < lastcaRisevRef))){ // noise but there is caRisevRef after firstcaRisevihAC (noise > vihAC-vRef) -> reset firstcaRisevihAC 
                firstcaRisevihAC = trigger->time();
                //calculate caSlewRSetupRise (from lastcaRiseVref to firstcaRisevihAC)
                caSlewRMode = false; //finish data collection for caSlewRSetupRise
                caSlewRWaveform.append(package->parameter.vihAC);
                caSlewRTime.append(firstcaRisevihAC);
                Container<double>* waveformLink = caSlewRWaveform.head();
                Container<double>* timeLink = caSlewRTime.head();
                Container<double>* waveformLinkTail = caSlewRWaveform.tail();
                Container<double>* timeLinkTail = caSlewRTime.tail();
                double vfix = waveformLinkTail->data(); //fix at the last point vihAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                caSlewRSetupTemp = slewR*1e-9;
            }
        }
    }
    if((trigger == caFallvihACTrigger) && (firstcaRisevRef > 0)){
        if(((trigger->time()-firstcaRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstcaFallvihAC < 0) || ((firstcaFallvihAC > 0) && ((trigger->time()-firstcaFallvihAC) > 0.5*UI)))){ // not the noise at current edge -> first one
               firstcaFallvihAC = trigger->time(); //no need for lastcaFallvihAC -> don't need to check for noise after firstcaFallvRef
               if(caFlightTimeSetupAvil){ 
                   // save caFlightTimeSetupRise and caSlewRSetupRise
                   // also calculate and save catVACHigh since it is related to caSlewRSetupRise
                   caFlightTimeSetupRise.append(caFlightTimeSetupTemp*1e12);
                   caSlewRSetupRise.append(caSlewRSetupTemp);
                   catVACHigh.append((firstcaFallvihAC-lastcaRisevihAC)*1e12);
               }
        }
    }
    if((trigger == caFallvihAC150Trigger) && (firstcaRisevRef > 0)){
        if(((trigger->time()-firstcaRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstcaFallvihAC150 < 0) || ((firstcaFallvihAC150 > 0) && ((trigger->time()-firstcaFallvihAC150) > 0.5*UI)))){ // not the noise at current edge -> first one
               firstcaFallvihAC150 = trigger->time(); //no need for lastcaFallvihAC150 -> don't need to check for noise after firstcaFallvRef
               if(caFlightTimeSetupAvilAC150){ 
                   // save caFlightTimeSetupRiseAC150 and caSlewRSetupRiseAC150
                   // also calculate and save catVACHighAC150 since it is related to caSlewRSetupRiseAC150
                   caFlightTimeSetupRiseAC150.append(caFlightTimeSetupTempAC150*1e12);
                   caSlewRSetupRiseAC150.append(caSlewRSetupTempAC150);
                   catVACHighAC150.append((firstcaFallvihAC150-lastcaRisevihAC150)*1e12);
               }
        }
    }
    if((trigger == caFallvihDCTrigger) && (firstcaRisevRef > 0)){
        //leaving logic high
        if(((trigger->time()-firstcaRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstcaFallvRef < 0) || ((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) > 0.5*UI)))){ // not the noise after firstcaFallRef (in a logic low cycle)
            lastcaFallvihDC = trigger->time();
            //prepare for caSlewRHoldFall from (lastcaFallvihDC to firstcaFallvRef)
            caSlewRMode = true;
            caSlewRWaveform.clear();
            caSlewRTime.clear();
            caSlewRWaveform.append(package->parameter.vihDC);
            caSlewRTime.append(lastcaFallvihDC);        

            if((firstcaFallvihDC < 0) || ((firstcaFallvihDC > 0) && ((trigger->time()-firstcaFallvihDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstcaFallvihDC = trigger->time();
            }
        }
    }   
}

void CmdAddTimingCmdAdd::evaluate(double time){
    if(caSlewRMode){
        caSlewRWaveform.append(signal.CmdAdd.p-signal.CmdAdd.n);
        caSlewRTime.append(time);
    }
    if(caSlewRModeAC150){
        caSlewRWaveformAC150.append(signal.CmdAdd.p-signal.CmdAdd.n);
        caSlewRTimeAC150.append(time);
    }
}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void CmdAddTimingCmdAdd::finalize(){
    PackageSignal* packageSignal = (PackageSignal*)signal.CmdAdd.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    double speedGrade = package->parameter.SpeedGrade;

    //get derating tables based on speed grade
    CSVData* Data_tVAC_Constraint = NULL;
    CSVData* Data_tVAC_Constraint_AC150 = NULL;
    CSVVector* tVAC_Constraint = NULL;
    CSVVector* tVAC_Constraint_AC150 = NULL;
    double tVAC_Constraint_value = 0.0;
    bool AC125 = false;
    if ((fabs(speedGrade-800.0) < 1e-3) || (fabs(speedGrade-1066.0) < 1e-3) ||
        (fabs(speedGrade-1333.0) < 1e-3) || (fabs(speedGrade-1600.0) < 1e-3)) //800/1066/1333/1600
    {
        Data_tVAC_Constraint = CSVData::parse(this->package,"DDR3_tVAC_constraint.csv");
        Data_tVAC_Constraint_AC150 = CSVData::parse(this->package,"DDR3_tVAC_constraint_AC150.csv");
    }
    else if (fabs(speedGrade-1866.0) < 1e-3) //1866
    {
        Data_tVAC_Constraint = CSVData::parse(this->package,"DDR3_tVAC_constraint_CmdAdd_1866.csv");
        Data_tVAC_Constraint_AC150 = CSVData::parse(this->package,"DDR3_tVAC_constraint_CmdAdd_1866_AC125.csv");
        AC125 = true;
    }
    else if (fabs(speedGrade-2133.0) < 1e-3) //2133
    {
        Data_tVAC_Constraint = CSVData::parse(this->package,"DDR3_tVAC_constraint_CmdAdd_2133.csv");
        Data_tVAC_Constraint_AC150 = CSVData::parse(this->package,"DDR3_tVAC_constraint_CmdAdd_2133_AC125.csv");
        AC125 = true;
    }
    if(CSVData::errorOccured())
        package->warn(CSVData::error());
    if (Data_tVAC_Constraint)
        tVAC_Constraint = static_cast<CSVVector*>(Data_tVAC_Constraint);
    if (Data_tVAC_Constraint_AC150)
        tVAC_Constraint_AC150 = static_cast<CSVVector*>(Data_tVAC_Constraint_AC150);

    // calculate tVAC margins.
    Container<double>* catVACHighLink = catVACHigh.head();
    Container<double>* caSlewRSetupRiseLink = caSlewRSetupRise.head();
    Container<double>* catVACLowLink = catVACLow.head();
    Container<double>* caSlewRSetupFallLink = caSlewRSetupFall.head();
    while(catVACHighLink && caSlewRSetupRiseLink){
        tVAC_Constraint_value = 0.0;
        if (tVAC_Constraint)
            tVAC_Constraint_value = tVAC_Constraint->lookup(0,caSlewRSetupRiseLink->data());
        catVACMarginHigh.append(catVACHighLink->data() - tVAC_Constraint_value);
        catVACHighLink = catVACHighLink->next();
        caSlewRSetupRiseLink = caSlewRSetupRiseLink->next();
    }
    while(catVACLowLink && caSlewRSetupFallLink){
        tVAC_Constraint_value = 0.0;
        if (tVAC_Constraint)
            tVAC_Constraint_value = tVAC_Constraint->lookup(0,caSlewRSetupFallLink->data());
        catVACMarginLow.append(catVACLowLink->data() - tVAC_Constraint_value);
        catVACLowLink = catVACLowLink->next();
        caSlewRSetupFallLink = caSlewRSetupFallLink->next();
    }
    Container<double>* catVACHighAC150Link = catVACHighAC150.head();
    Container<double>* caSlewRSetupRiseAC150Link = caSlewRSetupRiseAC150.head();
    Container<double>* catVACLowAC150Link = catVACLowAC150.head();
    Container<double>* caSlewRSetupFallAC150Link = caSlewRSetupFallAC150.head();
    while(catVACHighAC150Link && caSlewRSetupRiseAC150Link){
        tVAC_Constraint_value = 0.0;
        if (tVAC_Constraint_AC150)
            tVAC_Constraint_value = tVAC_Constraint_AC150->lookup(0,caSlewRSetupRiseAC150Link->data());
        catVACMarginHighAC150.append(catVACHighAC150Link->data() - tVAC_Constraint_value);
        catVACHighAC150Link = catVACHighAC150Link->next();
        caSlewRSetupRiseAC150Link = caSlewRSetupRiseAC150Link->next();
    }
    while(catVACLowAC150Link && caSlewRSetupFallAC150Link){
        tVAC_Constraint_value = 0.0;
        if (tVAC_Constraint_AC150)
            tVAC_Constraint_value = tVAC_Constraint_AC150->lookup(0,caSlewRSetupFallAC150Link->data());
        catVACMarginLowAC150.append(catVACLowAC150Link->data() - tVAC_Constraint_value);
        catVACLowAC150Link = catVACLowAC150Link->next();
        caSlewRSetupFallAC150Link = caSlewRSetupFallAC150Link->next();
    }

    save("CmdAddFlightTimeSetupFall", "Index", generateName(buffer,"CmdAddFlightTimeSetupFall",nodeName), caFlightTimeSetupFall);
    save("CmdAddFlightTimeSetupRise", "Index", generateName(buffer,"CmdAddFlightTimeSetupRise",nodeName), caFlightTimeSetupRise);
    save("CmdAddFlightTimeHoldFall", "Index", generateName(buffer,"CmdAddFlightTimeHoldFall",nodeName), caFlightTimeHoldFall);
    save("CmdAddFlightTimeHoldRise", "Index", generateName(buffer,"CmdAddFlightTimeHoldRise",nodeName), caFlightTimeHoldRise);
    save("CmdAddSlewRSetupFall", "Index", generateName(buffer,"CmdAddSlewRSetupFall",nodeName), caSlewRSetupFall);
    save("CmdAddSlewRSetupRise", "Index", generateName(buffer,"CmdAddSlewRSetupRise",nodeName), caSlewRSetupRise);
    save("CmdAddSlewRHoldFall", "Index", generateName(buffer,"CmdAddSlewRHoldFall",nodeName), caSlewRHoldFall);
    save("CmdAddSlewRHoldRise", "Index", generateName(buffer,"CmdAddSlewRHoldRise",nodeName), caSlewRHoldRise);
    save("CmdAddtVACHigh", "Index", generateName(buffer,"CmdAddtVACHigh",nodeName), catVACHigh);
    save("CmdAddtVACLow", "Index", generateName(buffer,"CmdAddtVACLow",nodeName), catVACLow);
    save("CmdAddtVACMarginHigh", "Index", generateName(buffer,"CmdAddtVACMarginHigh",nodeName), catVACMarginHigh);
    save("CmdAddtVACMarginLow", "Index", generateName(buffer,"CmdAddtVACMarginLow",nodeName), catVACMarginLow);
    if (AC125)
    {   // save in *AC125 output variables 
        save("CmdAddSlewRSetupFallAC125", "Index", generateName(buffer,"CmdAddSlewRSetupFallAC125",nodeName), caSlewRSetupFallAC150);
        save("CmdAddSlewRSetupRiseAC125", "Index", generateName(buffer,"CmdAddSlewRSetupRiseAC125",nodeName), caSlewRSetupRiseAC150);
        save("CmdAddFlightTimeSetupFallAC125", "Index", generateName(buffer,"CmdAddFlightTimeSetupFallAC125",nodeName), caFlightTimeSetupFallAC150);
        save("CmdAddFlightTimeSetupRiseAC125", "Index", generateName(buffer,"CmdAddFlightTimeSetupRiseAC125",nodeName), caFlightTimeSetupRiseAC150);
        save("CmdAddtVACHighAC125", "Index", generateName(buffer,"CmdAddtVACHighAC125",nodeName), catVACHighAC150);
        save("CmdAddtVACLowAC125", "Index", generateName(buffer,"CmdAddtVACLowAC125",nodeName), catVACLowAC150);
        save("CmdAddtVACMarginHighAC125", "Index", generateName(buffer,"CmdAddtVACMarginHighAC125",nodeName), catVACMarginHighAC150);
        save("CmdAddtVACMarginLowAC125", "Index", generateName(buffer,"CmdAddtVACMarginLowAC125",nodeName), catVACMarginLowAC150);
    }
    else
    {
        save("CmdAddSlewRSetupFallAC150", "Index", generateName(buffer,"CmdAddSlewRSetupFallAC150",nodeName), caSlewRSetupFallAC150);
        save("CmdAddSlewRSetupRiseAC150", "Index", generateName(buffer,"CmdAddSlewRSetupRiseAC150",nodeName), caSlewRSetupRiseAC150);
        save("CmdAddFlightTimeSetupFallAC150", "Index", generateName(buffer,"CmdAddFlightTimeSetupFallAC150",nodeName), caFlightTimeSetupFallAC150);
        save("CmdAddFlightTimeSetupRiseAC150", "Index", generateName(buffer,"CmdAddFlightTimeSetupRiseAC150",nodeName), caFlightTimeSetupRiseAC150);
        save("CmdAddtVACHighAC150", "Index", generateName(buffer,"CmdAddtVACHighAC150",nodeName), catVACHighAC150);
        save("CmdAddtVACLowAC150", "Index", generateName(buffer,"CmdAddtVACLowAC150",nodeName), catVACLowAC150);
        save("CmdAddtVACMarginHighAC150", "Index", generateName(buffer,"CmdAddtVACMarginHighAC150",nodeName), catVACMarginHighAC150);
        save("CmdAddtVACMarginLowAC150", "Index", generateName(buffer,"CmdAddtVACMarginLowAC150",nodeName), catVACMarginLowAC150);
    }
}

void CmdAddTimingCmdAdd::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.CmdAdd.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    DDR3_Package* p = static_cast<DDR3_Package*>(this->__package__());
    double speedGrade = package->parameter.SpeedGrade;
    bool AC125 = false;
    if ((fabs(speedGrade-1866.0) < 1e-3) || (fabs(speedGrade-2133.0) < 1e-3)) //1866/2133
        AC125 = true;

    p->check(this,"CmdAddFlightTimeSetupFall", caFlightTimeSetupFall, generateName(buffer,"CmdAddFlightTimeSetupFall",nodeName));
    p->check(this,"CmdAddFlightTimeSetupRise", caFlightTimeSetupRise, generateName(buffer,"CmdAddFlightTimeSetupRise",nodeName));
    p->check(this,"CmdAddFlightTimeHoldFall", caFlightTimeHoldFall, generateName(buffer,"CmdAddFlightTimeHoldFall",nodeName));
    p->check(this,"CmdAddFlightTimeHoldRise", caFlightTimeHoldRise, generateName(buffer,"CmdAddFlightTimeHoldRise",nodeName));
    p->check(this,"CmdAddSlewRSetupFall", caSlewRSetupFall, generateName(buffer,"CmdAddSlewRSetupFall",nodeName));
    p->check(this,"CmdAddSlewRSetupRise", caSlewRSetupRise, generateName(buffer,"CmdAddSlewRSetupRise",nodeName));
    p->check(this,"CmdAddSlewRHoldFall", caSlewRHoldFall, generateName(buffer,"CmdAddSlewRHoldFall",nodeName));
    p->check(this,"CmdAddSlewRHoldRise", caSlewRHoldRise, generateName(buffer,"CmdAddSlewRHoldRise",nodeName));
    p->check(this,"CmdAddtVACHigh", catVACHigh, generateName(buffer,"CmdAddtVACHigh",nodeName));
    p->check(this,"CmdAddtVACLow", catVACLow, generateName(buffer,"CmdAddtVACLow",nodeName));
    p->check(this,"CmdAddtVACMarginHigh", catVACMarginHigh, generateName(buffer,"CmdAddtVACMarginHigh",nodeName));
    p->check(this,"CmdAddtVACMarginLow", catVACMarginLow, generateName(buffer,"CmdAddtVACMarginLow",nodeName));
    if (AC125)
    {
        p->check(this,"CmdAddFlightTimeSetupFallAC125", caFlightTimeSetupFallAC150, generateName(buffer,"CmdAddFlightTimeSetupFallAC125",nodeName));
        p->check(this,"CmdAddFlightTimeSetupRiseAC125", caFlightTimeSetupRiseAC150, generateName(buffer,"CmdAddFlightTimeSetupRiseAC125",nodeName));
        p->check(this,"CmdAddSlewRSetupFallAC125", caSlewRSetupFallAC150, generateName(buffer,"CmdAddSlewRSetupFallAC125",nodeName));
        p->check(this,"CmdAddSlewRSetupRiseAC125", caSlewRSetupRiseAC150, generateName(buffer,"CmdAddSlewRSetupRiseAC125",nodeName));
        p->check(this,"CmdAddtVACHighAC125", catVACHighAC150, generateName(buffer,"CmdAddtVACHighAC125",nodeName));
        p->check(this,"CmdAddtVACLowAC125", catVACLowAC150, generateName(buffer,"CmdAddtVACLowAC125",nodeName));
        p->check(this,"CmdAddtVACMarginHighAC125", catVACMarginHighAC150, generateName(buffer,"CmdAddtVACMarginHighAC125",nodeName));
        p->check(this,"CmdAddtVACMarginLowAC125", catVACMarginLowAC150, generateName(buffer,"CmdAddtVACMarginLowAC125",nodeName));
    }
    else
    {
        p->check(this,"CmdAddFlightTimeSetupFallAC150", caFlightTimeSetupFallAC150, generateName(buffer,"CmdAddFlightTimeSetupFallAC150",nodeName));
        p->check(this,"CmdAddFlightTimeSetupRiseAC150", caFlightTimeSetupRiseAC150, generateName(buffer,"CmdAddFlightTimeSetupRiseAC150",nodeName));
        p->check(this,"CmdAddSlewRSetupFallAC150", caSlewRSetupFallAC150, generateName(buffer,"CmdAddSlewRSetupFallAC150",nodeName));
        p->check(this,"CmdAddSlewRSetupRiseAC150", caSlewRSetupRiseAC150, generateName(buffer,"CmdAddSlewRSetupRiseAC150",nodeName));
        p->check(this,"CmdAddtVACHighAC150", catVACHighAC150, generateName(buffer,"CmdAddtVACHighAC150",nodeName));
        p->check(this,"CmdAddtVACLowAC150", catVACLowAC150, generateName(buffer,"CmdAddtVACLowAC150",nodeName));
        p->check(this,"CmdAddtVACMarginHighAC150", catVACMarginHighAC150, generateName(buffer,"CmdAddtVACMarginHighAC150",nodeName));
        p->check(this,"CmdAddtVACMarginLowAC150", catVACMarginLowAC150, generateName(buffer,"CmdAddtVACMarginLowAC150",nodeName));
    }
}
