// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class DataTimingDQS.
/// This class is for data timing measurements on DQS singal.

class DataTimingDQS:public Measurement{
public:
	DataTimingDQS();
	virtual ~DataTimingDQS();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__DataTimingDQS"

        // vectors to save measurement results
        DoubleVector dqsFlightTimeFall;
        DoubleVector dqsFlightTimeRise;
        DoubleVector dqsSlewRFall;
        DoubleVector dqsSlewRRise;

protected:
        // queues to save DQS_Reference trigger times
        Queue<double> dqsRefFallZeroTime;
        Queue<double> dqsRefRiseZeroTime;

        // DQS triggers at threshold voltages
        Trigger* dqsFall0p2Trigger;
        Trigger* dqsFallZeroTrigger;
        Trigger* dqsFallm0p2Trigger;
        Trigger* dqsRisem0p2Trigger;
        Trigger* dqsRiseZeroTrigger;
        Trigger* dqsRise0p2Trigger;

        // DQS_Reference triggers
        Trigger* dqsRefFallZeroTrigger;
        Trigger* dqsRefRiseZeroTrigger;

        bool evalState;
        bool qPop;

        // variables to save trigger times
        double lastdqsRefFallZero;
        double lastdqsRefRiseZero;
        double lastdqsFall0p2;
        double lastdqsRisem0p2;
};
