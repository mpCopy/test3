// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "DQ_DQS_Skew.h"
#include "DataTimingDQ.h"
#include "DataTimingDQS.h"
#include <math.h>

DQ_DQS_Skew::DQ_DQS_Skew(){}

DQ_DQS_Skew::~DQ_DQS_Skew(){}

/// Define functions of class DQ_DQS_Skew
/// These functions are for skews calculation between DQ and DQS singals.

void DQ_DQS_Skew::initialize(){
    // initial clearup of vectors
    dqSkewSetupFall.clear();
    dqSkewSetupRise.clear();
    dqSkewSetupFallAC150.clear();
    dqSkewSetupRiseAC150.clear();
    dqSkewHoldFall.clear();
    dqSkewHoldRise.clear();
    dqReadSkewSetupFall.clear();
    dqReadSkewSetupRise.clear();
    dqReadSkewHoldFall.clear();
    dqReadSkewHoldRise.clear();
}
void DQ_DQS_Skew::event(Trigger* trigger){}

void DQ_DQS_Skew::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void DQ_DQS_Skew::finalize(){
    DataTimingDQ*  dqDataTiming  = (DataTimingDQ*)this->package->getMeasurement("DataTimingDQ",signal.DQ);
    DataTimingDQS* dqsDataTiming = (DataTimingDQS*)this->package->getMeasurement("DataTimingDQS",signal.DQS);
    double speedGrade = package->parameter.SpeedGrade;

    if(!(dqDataTiming) || !(dqsDataTiming)){
        package->error("DQ_DQS_Skew requires both DataTimingDQ and DataTimingDQS selected.");
        return;
    }

    double tempValue, dqsFlightTimeMax, dqsFlightTimeMin, dqsSlewRMax;
    int index, numSkip=3;

    // Get max and dqsFlightTime from dqsFlightTimeFall and dqsFlightTimeRise
    // Get max dqsSlewR from dqsSlewRFall and dqsSkewRRise
    Container<double>* dqsFlightTimeFall = dqsDataTiming->dqsFlightTimeFall.head();
    Container<double>* dqsFlightTimeRise = dqsDataTiming->dqsFlightTimeRise.head();
    Container<double>* dqsSlewRFall = dqsDataTiming->dqsSlewRFall.head();
    Container<double>* dqsSlewRRise = dqsDataTiming->dqsSlewRRise.head();
    if(!(dqsFlightTimeFall) || !(dqsFlightTimeRise) || !(dqsSlewRFall) || !(dqsSlewRRise)){
        package->error("No data from DataTimingDQS. Check DQS probe connection.");
        return;
    }
    for(index=0; index < numSkip; index++) {
        if(dqsFlightTimeFall->next())
            dqsFlightTimeFall = dqsFlightTimeFall->next();
        if(dqsFlightTimeRise->next())
            dqsFlightTimeRise = dqsFlightTimeRise->next();
        if(dqsSlewRFall->next())
            dqsSlewRFall = dqsSlewRFall->next();
        if(dqsSlewRRise->next())
            dqsSlewRRise = dqsSlewRRise->next();
    }
    dqsFlightTimeMax = dqsFlightTimeFall->data();
    dqsFlightTimeMin = dqsFlightTimeFall->data();
    while(dqsFlightTimeFall->next()){
        dqsFlightTimeFall = dqsFlightTimeFall->next();
        tempValue = dqsFlightTimeFall->data();
        if(dqsFlightTimeMax < tempValue)
            dqsFlightTimeMax = tempValue;
        if(dqsFlightTimeMin > tempValue)
            dqsFlightTimeMin = tempValue;
    }
    while(dqsFlightTimeRise->next()){
        dqsFlightTimeRise = dqsFlightTimeRise->next();
        tempValue = dqsFlightTimeRise->data();
        if(dqsFlightTimeMax < tempValue)
            dqsFlightTimeMax = tempValue;
        if(dqsFlightTimeMin > tempValue)
            dqsFlightTimeMin = tempValue;
    }
    dqsSlewRMax = dqsSlewRFall->data();
    while(dqsSlewRFall->next()){
        dqsSlewRFall = dqsSlewRFall->next();
        tempValue = dqsSlewRFall->data();
        if(dqsSlewRMax < tempValue)
            dqsSlewRMax = tempValue;
    }
    while(dqsSlewRRise->next()){
        dqsSlewRRise = dqsSlewRRise->next();
        tempValue = dqsSlewRRise->data();
        if(dqsSlewRMax < tempValue)
            dqsSlewRMax = tempValue;
    }

    // calculate derated skews
    Container<double>* dqFlightTimeSetupFall = dqDataTiming->dqFlightTimeSetupFall.head();
    Container<double>* dqFlightTimeSetupRise = dqDataTiming->dqFlightTimeSetupRise.head();
    Container<double>* dqFlightTimeSetupFallAC150 = dqDataTiming->dqFlightTimeSetupFallAC150.head();
    Container<double>* dqFlightTimeSetupRiseAC150 = dqDataTiming->dqFlightTimeSetupRiseAC150.head();
    Container<double>* dqFlightTimeHoldFall = dqDataTiming->dqFlightTimeHoldFall.head();
    Container<double>* dqFlightTimeHoldRise = dqDataTiming->dqFlightTimeHoldRise.head();
    Container<double>* dqSlewRSetupFall = dqDataTiming->dqSlewRSetupFall.head();
    Container<double>* dqSlewRSetupRise = dqDataTiming->dqSlewRSetupRise.head();
    Container<double>* dqSlewRSetupFallAC150 = dqDataTiming->dqSlewRSetupFallAC150.head();
    Container<double>* dqSlewRSetupRiseAC150 = dqDataTiming->dqSlewRSetupRiseAC150.head();
    Container<double>* dqSlewRHoldFall = dqDataTiming->dqSlewRHoldFall.head();
    Container<double>* dqSlewRHoldRise = dqDataTiming->dqSlewRHoldRise.head();
    Container<double>* dqReadFlightTimeFallMin = dqDataTiming->dqReadFlightTimeFallMin.head();
    Container<double>* dqReadFlightTimeFallMax = dqDataTiming->dqReadFlightTimeFallMax.head();
    Container<double>* dqReadFlightTimeRiseMin = dqDataTiming->dqReadFlightTimeRiseMin.head();
    Container<double>* dqReadFlightTimeRiseMax = dqDataTiming->dqReadFlightTimeRiseMax.head();

    //get derating tables based on speed grade
    CSVData* Data_Derating_DQ_Setup = NULL;
    CSVData* Data_Derating_DQ_Hold = NULL;
    CSVMatrix* Derating_DQ_Setup = NULL;
    CSVMatrix* Derating_DQ_Hold = NULL;
    CSVMatrix* Derating_DQ_Setup_AC150 = NULL;
    if ((fabs(speedGrade-800.0) < 1e-3) || (fabs(speedGrade-1066.0) < 1e-3)) //800/1066
    {
        Data_Derating_DQ_Setup = CSVData::parse(this->package,"DDR3_derating_table_DQ_Setup_800_1066.csv");
        Data_Derating_DQ_Hold = CSVData::parse(this->package,"DDR3_derating_table_DQ_Hold.csv");
    }
    else if ((fabs(speedGrade-1333.0) < 1e-3) || (fabs(speedGrade-1600.0) < 1e-3)) //1333/1600
    {
        Data_Derating_DQ_Setup = CSVData::parse(this->package,"DDR3_derating_table_DQ_Setup_1333_1600.csv");
        Data_Derating_DQ_Hold = CSVData::parse(this->package,"DDR3_derating_table_DQ_Hold.csv");
    }
    else if (fabs(speedGrade-1866.0) < 1e-3) //1866
    {
        Data_Derating_DQ_Setup = CSVData::parse(this->package,"DDR3_derating_table_DQ_Setup_1866.csv");
        Data_Derating_DQ_Hold = CSVData::parse(this->package,"DDR3_derating_table_DQ_Hold_1866.csv");
    }
    else if (fabs(speedGrade-2133.0) < 1e-3) //2133
    {
        Data_Derating_DQ_Setup = CSVData::parse(this->package,"DDR3_derating_table_DQ_Setup_2133.csv");
        Data_Derating_DQ_Hold = CSVData::parse(this->package,"DDR3_derating_table_DQ_Hold_2133.csv");
    }
    if(CSVData::errorOccured())
        package->warn(CSVData::error());
    if (Data_Derating_DQ_Setup)
    {
        Derating_DQ_Setup = static_cast<CSVMatrix*>(Data_Derating_DQ_Setup);
        //Since we don't have the clarification for JEDEC on DQ AC150 yet, the regular derating table will be used on both AC175 and AC150.
        Derating_DQ_Setup_AC150 = Derating_DQ_Setup;
    }
    if (Data_Derating_DQ_Hold)
        Derating_DQ_Hold = static_cast<CSVMatrix*>(Data_Derating_DQ_Hold);

    // calcualte skews.
    // setup skews.
    while(dqFlightTimeSetupFall && dqSlewRSetupFall){
        tempValue = dqFlightTimeSetupFall->data() - dqsFlightTimeMin;
        if (Derating_DQ_Setup)
            tempValue +=  Derating_DQ_Setup->lookup(dqsSlewRMax, dqSlewRSetupFall->data());
        dqSkewSetupFall.append(tempValue);
        dqFlightTimeSetupFall = dqFlightTimeSetupFall->next();
        dqSlewRSetupFall = dqSlewRSetupFall->next();
    }
    while(dqFlightTimeSetupRise && dqSlewRSetupRise){
        tempValue = dqFlightTimeSetupRise->data() - dqsFlightTimeMin;
        if (Derating_DQ_Setup)
           tempValue += Derating_DQ_Setup->lookup(dqsSlewRMax, dqSlewRSetupRise->data());
        dqSkewSetupRise.append(tempValue);
        dqFlightTimeSetupRise = dqFlightTimeSetupRise->next();
        dqSlewRSetupRise = dqSlewRSetupRise->next();
    }
    while(dqFlightTimeSetupFallAC150 && dqSlewRSetupFallAC150){
        tempValue = dqFlightTimeSetupFallAC150->data() - dqsFlightTimeMin;
        if (Derating_DQ_Setup_AC150)
            tempValue += Derating_DQ_Setup_AC150->lookup(dqsSlewRMax, dqSlewRSetupFallAC150->data());
        dqSkewSetupFallAC150.append(tempValue);
        dqFlightTimeSetupFallAC150 = dqFlightTimeSetupFallAC150->next();
        dqSlewRSetupFallAC150 = dqSlewRSetupFallAC150->next();
    }
    while(dqFlightTimeSetupRiseAC150 && dqSlewRSetupRiseAC150){
        tempValue = dqFlightTimeSetupRiseAC150->data() - dqsFlightTimeMin;
        if (Derating_DQ_Setup_AC150)
            tempValue += Derating_DQ_Setup_AC150->lookup(dqsSlewRMax, dqSlewRSetupRiseAC150->data());
        dqSkewSetupRiseAC150.append(tempValue);
        dqFlightTimeSetupRiseAC150 = dqFlightTimeSetupRiseAC150->next();
        dqSlewRSetupRiseAC150 = dqSlewRSetupRiseAC150->next();
    }
    // hold skews.
    while(dqFlightTimeHoldFall && dqSlewRHoldFall){
        tempValue = dqsFlightTimeMax - dqFlightTimeHoldFall->data();
        if (Derating_DQ_Hold)
            tempValue += Derating_DQ_Hold->lookup(dqsSlewRMax, dqSlewRHoldFall->data());
        dqSkewHoldFall.append(tempValue);
        dqFlightTimeHoldFall = dqFlightTimeHoldFall->next();
        dqSlewRHoldFall = dqSlewRHoldFall->next();
    }
    while(dqFlightTimeHoldRise && dqSlewRHoldRise){
        tempValue = dqsFlightTimeMax - dqFlightTimeHoldRise->data();
        if (Derating_DQ_Hold)
            tempValue += Derating_DQ_Hold->lookup(dqsSlewRMax, dqSlewRHoldRise->data());
        dqSkewHoldRise.append(tempValue);
        dqFlightTimeHoldRise = dqFlightTimeHoldRise->next();
        dqSlewRHoldRise = dqSlewRHoldRise->next();
    }
    // read skews
    while(dqReadFlightTimeFallMax){
        dqReadSkewSetupFall.append(dqReadFlightTimeFallMax->data() - dqsFlightTimeMin);
        dqReadFlightTimeFallMax = dqReadFlightTimeFallMax->next();
    }
    while(dqReadFlightTimeRiseMax){
        dqReadSkewSetupRise.append(dqReadFlightTimeRiseMax->data() - dqsFlightTimeMin);
        dqReadFlightTimeRiseMax = dqReadFlightTimeRiseMax->next();
    }
    while(dqReadFlightTimeFallMin){
        dqReadSkewHoldFall.append(dqsFlightTimeMax - dqReadFlightTimeFallMin->data());
        dqReadFlightTimeFallMin = dqReadFlightTimeFallMin->next();
    }
    while(dqReadFlightTimeRiseMin){
        dqReadSkewHoldRise.append(dqsFlightTimeMax - dqReadFlightTimeRiseMin->data());
        dqReadFlightTimeRiseMin = dqReadFlightTimeRiseMin->next();
    }

    // save the results
    PackageSignal* packageSignal = (PackageSignal*)signal.DQ.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("DQ_DQSSkewSetupFall", "Index", generateName(buffer,"DQ_DQSSkewSetupFall",nodeName), dqSkewSetupFall);
    save("DQ_DQSSkewSetupRise", "Index", generateName(buffer,"DQ_DQSSkewSetupRise",nodeName), dqSkewSetupRise);
    save("DQ_DQSSkewSetupFallAC150", "Index", generateName(buffer,"DQ_DQSSkewSetupFallAC150",nodeName), dqSkewSetupFallAC150);
    save("DQ_DQSSkewSetupRiseAC150", "Index", generateName(buffer,"DQ_DQSSkewSetupRiseAC150",nodeName), dqSkewSetupRiseAC150);
    save("DQ_DQSSkewHoldFall", "Index", generateName(buffer,"DQ_DQSSkewHoldFall",nodeName), dqSkewHoldFall);
    save("DQ_DQSSkewHoldRise", "Index", generateName(buffer,"DQ_DQSSkewHoldRise",nodeName), dqSkewHoldRise);
    save("DQ_DQSSkewReadSetupFall", "Index", generateName(buffer,"DQ_DQSSkewReadSetupFall",nodeName), dqReadSkewSetupFall);
    save("DQ_DQSSkewReadSetupRise", "Index", generateName(buffer,"DQ_DQSSkewReadSetupRise",nodeName), dqReadSkewSetupRise);
    save("DQ_DQSSkewReadHoldFall", "Index", generateName(buffer,"DQ_DQSSkewReadHoldFall",nodeName), dqReadSkewHoldFall);
    save("DQ_DQSSkewReadHoldRise", "Index", generateName(buffer,"DQ_DQSSkewReadHoldRise",nodeName), dqReadSkewHoldRise);
}

void DQ_DQS_Skew::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQ.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    DDR3_Package* p = static_cast<DDR3_Package*>(this->__package__());
   
    p->check(this,"DQ_DQSSkewSetupFall", dqSkewSetupFall, generateName(buffer,"DQ_DQSSkewSetupFall",nodeName));
    p->check(this,"DQ_DQSSkewSetupRise", dqSkewSetupRise, generateName(buffer,"DQ_DQSSkewSetupRise",nodeName));
    p->check(this,"DQ_DQSSkewSetupFallAC150", dqSkewSetupFallAC150, generateName(buffer,"DQ_DQSSkewSetupFallAC150",nodeName));
    p->check(this,"DQ_DQSSkewSetupRiseAC150", dqSkewSetupRiseAC150, generateName(buffer,"DQ_DQSSkewSetupRiseAC150",nodeName));
    p->check(this,"DQ_DQSSkewHoldFall", dqSkewHoldFall, generateName(buffer,"DQ_DQSSkewHoldFall",nodeName));
    p->check(this,"DQ_DQSSkewHoldRise", dqSkewHoldRise, generateName(buffer,"DQ_DQSSkewHoldRise",nodeName));
    p->check(this,"DQ_DQSSkewReadSetupFall", dqReadSkewSetupFall, generateName(buffer,"DQ_DQSSkewReadSetupFall",nodeName));
    p->check(this,"DQ_DQSSkewReadSetupRise", dqReadSkewSetupRise, generateName(buffer,"DQ_DQSSkewReadSetupRise",nodeName));
    p->check(this,"DQ_DQSSkewReadHoldFall", dqReadSkewHoldFall, generateName(buffer,"DQ_DQSSkewReadHoldFall",nodeName));
    p->check(this,"DQ_DQSSkewReadHoldRise", dqReadSkewHoldRise, generateName(buffer,"DQ_DQSSkewReadHoldRise",nodeName));
}
