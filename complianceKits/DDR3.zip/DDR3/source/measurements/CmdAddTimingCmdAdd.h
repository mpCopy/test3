// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class CmdAddTimingCmdAdd.
/// This class is for Command/Address timing measurements on Command/Address singals.

class CmdAddTimingCmdAdd:public Measurement{
public:
	CmdAddTimingCmdAdd();
	virtual ~CmdAddTimingCmdAdd();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__CmdAddTimingCmdAdd"

        // vectors to save measurement results
        DoubleVector caFlightTimeSetupFall;
        DoubleVector caFlightTimeSetupRise;
        DoubleVector caFlightTimeSetupFallAC150;
        DoubleVector caFlightTimeSetupRiseAC150;
        DoubleVector caFlightTimeHoldFall;
        DoubleVector caFlightTimeHoldRise;
        DoubleVector caSlewRSetupFall;
        DoubleVector caSlewRSetupRise;
        DoubleVector caSlewRSetupFallAC150;
        DoubleVector caSlewRSetupRiseAC150;
        DoubleVector caSlewRHoldFall;
        DoubleVector caSlewRHoldRise;
        DoubleVector catVACHigh;
        DoubleVector catVACLow;
        DoubleVector catVACMarginHigh;
        DoubleVector catVACMarginLow;
        DoubleVector catVACHighAC150;
        DoubleVector catVACLowAC150;
        DoubleVector catVACMarginHighAC150;
        DoubleVector catVACMarginLowAC150;

protected:
        // vectors to save wavefrom for slew rate calculation
        DoubleVector caSlewRWaveform;
        DoubleVector caSlewRTime;
        DoubleVector caSlewRWaveformAC150;
        DoubleVector caSlewRTimeAC150;

        // queues to save CmdAdd_Reference trigger times
        Queue<double> caRefFallvMeasTime;
        Queue<double> caRefRisevMeasTime;

        // CmdAdd triggers at threshold voltages
        Trigger* caFallvihACTrigger;
        Trigger* caFallvihAC150Trigger;
        Trigger* caFallvihDCTrigger;
        Trigger* caFallvRefTrigger;
        Trigger* caFallvilDCTrigger;
        Trigger* caFallvilAC150Trigger;
        Trigger* caFallvilACTrigger;
        Trigger* caRisevilACTrigger;
        Trigger* caRisevilAC150Trigger;
        Trigger* caRisevilDCTrigger;
        Trigger* caRisevRefTrigger;
        Trigger* caRisevihDCTrigger;
        Trigger* caRisevihAC150Trigger;
        Trigger* caRisevihACTrigger;

        // CmdAdd_Reference triggers
        Trigger* caRefFallvMeasTrigger;
        Trigger* caRefRisevMeasTrigger;

        bool evalState;
        bool caSlewRMode;
        bool caSlewRModeAC150;
        bool caFlightTimeSetupAvil;
        bool caFlightTimeSetupAvilAC150;
        bool qPop;

        // variables to save trigger times
        double lastcaRefFallvMeas;
        double lastcaRefRisevMeas;
        double firstcaFallvRef;
        double lastcaFallvRef;
        double lastcaFallvilDC;
        double firstcaFallvilAC;
        double lastcaFallvilAC;
        double firstcaFallvilAC150;
        double lastcaFallvilAC150;
        double firstcaRisevilAC;
        double firstcaRisevilAC150;
        double firstcaRisevilDC;
        double lastcaRisevilDC;
        double firstcaRisevRef;
        double lastcaRisevRef;
        double lastcaRisevihDC;
        double firstcaRisevihAC;
        double lastcaRisevihAC;
        double firstcaRisevihAC150;
        double lastcaRisevihAC150;
        double firstcaFallvihAC;
        double firstcaFallvihAC150;
        double firstcaFallvihDC;
        double lastcaFallvihDC;

        double caFlightTimeSetupTemp;
        double caFlightTimeSetupTempAC150;
        double caSlewRSetupTemp;
        double caSlewRSetupTempAC150;
        double UI;
        double SecAcValue;
};
