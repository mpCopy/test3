// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "CmdAddTimingClk.h"
#include <math.h>

CmdAddTimingClk::CmdAddTimingClk(){}

CmdAddTimingClk::~CmdAddTimingClk(){}

/// Define functions of class CmdAddTimingClk
/// These functions are for Command/Address timing measurements on Clock signal.

void CmdAddTimingClk::initialize(){
    //package->status("DDR3 CmdAddTimingClk Initialize");
    setEnableEvaluation(false);
    evalState = false;
    qPop = false;

    // initial cleanup of vectors
    clkFlightTimeFall.clear();
    clkFlightTimeRise.clear();
    clkSlewRFall.clear();
    clkSlewRRise.clear();

    clkRefFallZeroTime.clear();
    clkRefRiseZeroTime.clear();

    // set up triggers with specific threshold voltages    
    clkFall0p2Trigger = addFallingEdgeTrigger(&signal.Clock, 0.2);
    clkFallZeroTrigger = addFallingEdgeTrigger(&signal.Clock, 0.0);
    clkFallm0p2Trigger = addFallingEdgeTrigger(&signal.Clock, -0.2);
    clkRisem0p2Trigger = addRisingEdgeTrigger(&signal.Clock, -0.2);
    clkRiseZeroTrigger = addRisingEdgeTrigger(&signal.Clock, 0.0);
    clkRise0p2Trigger = addRisingEdgeTrigger(&signal.Clock, 0.2);

    clkRefFallZeroTrigger = addFallingEdgeTrigger(&signal.Clock_Reference, 0.0);
    clkRefRiseZeroTrigger = addRisingEdgeTrigger(&signal.Clock_Reference, 0.0);

    // initialize the saved trigger times
    lastclkRefFallZero = -1;
    lastclkRefRiseZero = -1;
    lastclkFall0p2 = -1;
    lastclkRisem0p2 = -1;
}

void CmdAddTimingClk::event(Trigger* trigger){
    if(trigger == clkRefFallZeroTrigger){
        clkRefFallZeroTime.push(trigger->time());
    }
    if(trigger == clkFallZeroTrigger){
        if(!clkRefFallZeroTime.empty()){
            qPop = clkRefFallZeroTime.pop(&lastclkRefFallZero);
            clkFlightTimeFall.append((trigger->time()-lastclkRefFallZero)*1e12);
        }
    }
    if(trigger == clkFallm0p2Trigger){
        if(lastclkFall0p2 > 0)
            clkSlewRFall.append(0.4/(trigger->time()-lastclkFall0p2)*1e-9);
    }
    if(trigger == clkRisem0p2Trigger){
        lastclkRisem0p2 = trigger->time();
    }
    if(trigger == clkRefRiseZeroTrigger){
        clkRefRiseZeroTime.push(trigger->time());
    }
    if(trigger == clkRiseZeroTrigger){
        if(!clkRefRiseZeroTime.empty()){
            qPop = clkRefRiseZeroTime.pop(&lastclkRefRiseZero);
            clkFlightTimeRise.append((trigger->time()-lastclkRefRiseZero)*1e12);
        }
    }
    if(trigger == clkRise0p2Trigger){
        if(lastclkRisem0p2 > 0)
            clkSlewRRise.append(0.4/(trigger->time()-lastclkRisem0p2)*1e-9);
    }
    if(trigger == clkFall0p2Trigger){
        lastclkFall0p2 = trigger->time();
    }
}

void CmdAddTimingClk::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void CmdAddTimingClk::finalize(){
    PackageSignal* packageSignal = (PackageSignal*)signal.Clock.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("ClockFlightTimeFall", "Index", generateName(buffer,"ClockFlightTimeFall",nodeName), clkFlightTimeFall);
    save("ClockFlightTimeRise", "Index", generateName(buffer,"ClockFlightTimeRise",nodeName), clkFlightTimeRise);
    save("ClockSlewRFall", "Index", generateName(buffer,"ClockSlewRFall",nodeName), clkSlewRFall);
    save("ClockSlewRRise", "Index", generateName(buffer,"ClockSlewRRise",nodeName), clkSlewRRise);
}

void CmdAddTimingClk::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.Clock.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    DDR3_Package* p = static_cast<DDR3_Package*>(this->__package__());
    p->check(this,"ClockFlightTimeFall", clkFlightTimeFall, generateName(buffer,"ClockFlightTimeFall",nodeName));
    p->check(this,"ClockFlightTimeRise", clkFlightTimeRise, generateName(buffer,"ClockFlightTimeRise",nodeName));
    p->check(this,"ClockSlewRFall", clkSlewRFall, generateName(buffer,"ClockSlewRFall",nodeName));
    p->check(this,"ClockSlewRRise", clkSlewRRise, generateName(buffer,"ClockSlewRRise",nodeName));
}
