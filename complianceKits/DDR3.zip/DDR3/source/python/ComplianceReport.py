import csv
import types
import pyExcelerator
from PostProcessing import *
from Design import *
import time
import types

class BatchTable:
    def __init__(self):
        self.variables = None
        self.data = []

class ProbeData:
    def __init__(self):
        self.name = None
        self.complianceData = None
        self.cmNames = []
        self.ciNames = None
        self.mData = []

class ComplianceData:
    def __init__(self):
        self.name  = None
        self.lower = None
        self.upper = None
        self.lowerViolation = None
        self.upperViolation = None
        self.passMargin = None
        self.iData = None

class ComplianceDataset:
    def __init__(self):
        self.data = []
        self.iData = None

class __MeasurementData__:
    def __init__(self):
        self.sweepData = []
        self.data = []
        self.name = None
        self.fName = None
        self.average = None
        self.max = None
        self.min = None
        self.iData = None
        self.probe = None

    def getStat(self):
        if len(self.data) > 0:
            self.min = self.data[0][1]
            self.max = self.data[0][1]
            _sum = 0
            for i in self.data:
                value = i[1]
                _sum += value
                if value > self.max:
                    self.max = value
                if value < self.min:
                    self.min = value
            self.average = _sum/len(self.data)
        
        

class ComplianceReport(PostProcessingModule):
    __module = "Compliance Report Module"
    __tdcmData  = 1
    __ddr3Data  = 2
    __measurementData = 4
    __complianceHistogramData = 8
    __complianceData = 16
    __batchTableData = 32

    def __setup(self,arguments):
        self.simulation = Simulation.getInstance()
        self.designName = self.simulation.getDesignName()
        self.time = time.asctime(time.localtime())
        self.fileTime = self.time.replace(' ','_').replace(':','_')

        self.fileName = "ComplianceReport.xls"
        self.saveComplianceSummary = True
        self.saveMeasurementSummary = True
        self.saveMeasurementMS = False
        self.saveMeasurementSS = False
        self.saveMeasurementPS = False
        self.sortMethod = 0
        length = len(arguments)
        if length == 6:
            self.fileName = arguments[0]
            self.saveComplianceSummary = arguments[1]
            self.saveMeasurementSummary = arguments[2]
            self.saveMeasurementMS = arguments[3]
            self.saveMeasurementSS = arguments[4]
            self.saveMeasurementPS = arguments[5]
        elif length == 5:
            self.fileName = arguments[0]
            self.saveComplianceSummary = arguments[1]
            self.saveMeasurementSummary = arguments[2]
            self.saveMeasurementMS = arguments[3]
            self.saveMeasurementSS = arguments[4]
        elif length == 4:
            self.fileName = arguments[0]
            self.saveComplianceSummary = arguments[1]
            self.saveMeasurementSummary = arguments[2]
            self.saveMeasurementMS = arguments[3]
        elif length == 3:
            self.fileName = arguments[0]
            self.saveComplianceSummary = arguments[1]
            self.saveMeasurementSummary = arguments[2]
        elif length == 2:
            self.fileName = arguments[0]
            self.saveComplianceSummary = arguments[1]
        elif length == 1:
            self.fileName = arguments[0]
            
        self.saveMeasurementData = (self.saveMeasurementMS or self.saveMeasurementSS or  self.saveMeasurementPS) 
        if len(self.fileName) == 0:
            self.fileName = "ComplianceReport.xls"
        else:
            if self.fileName.find(".xls") == -1:
                self.fileName = self.fileName + ".xls"
     
     
    def process(self,output,arguments):
        self.__setup(arguments)
        self.sortByMeasurement = True
        self.measurementData = []
        self.measurementMap = {}
        self.measurementSignalMap = {}
        self.outputSize = 0
        self.probeMap = {}
        self.batchTable = None
        cIndex = 0
        for data in output:
            (dataType,probeName) = self.getDataType(data)
            if(dataType & ComplianceReport.__tdcmData):
                isComplianceHistogramData = (dataType & ComplianceReport.__complianceHistogramData)
                isComplianceData = (dataType & ComplianceReport.__complianceData)
                
                if isComplianceData:
                    probe = None
                    if self.probeMap.has_key(probeName):
                        probe = self.probeMap[probeName]
                    else:
                        probe = ProbeData()
                        probe.name = probeName
                        self.probeMap[probeName] = probe
                        probe.ciNames = data.independentNames()
                    complianceDataset = ComplianceDataset()
                    for node in data:
                        for d in node:
                            if len(d) == 6:
                                c = ComplianceData()
                                c.lowerViolation = d[1]
                                c.upperViolation = d[2]
                                c.passMargin = d[3]
                                c.lower = d[4]
                                c.upper = d[5]
                                c.iData = node.independentData()
                                complianceDataset.data.append(c)
                    probe.complianceData = complianceDataset
                elif isComplianceHistogramData:
                    probe = None
                    if self.probeMap.has_key(probeName):
                        probe = self.probeMap[probeName]
                    else:
                        probe = ProbeData
                        probe.name = probeName
                        self.probeMap[probeName] = probe
                    name = data.name()
                    nindex = name.find(".ComplianceHistogram.")
                    if nindex > 0:
                        name = name[nindex:]
                        name = name[len(".ComplianceHistogram."):]                  
                    probe.cmNames.append(name)
                elif (len(data.dependentNames()) == 1) and (self.saveMeasurementData or self.saveMeasurementSummary):
                    index = probeName.rfind(".")
                    if (index > 0):
                        probeName = probeName[:index]
                    index = probeName.rfind(".")
                    if (index > 0):
                        probeName = probeName[:index]
                    if self.probeMap.has_key(probeName):
                        probe = self.probeMap[probeName]
                    else:
                        probe = ProbeData()
                        probe.name = probeName
                        self.probeMap[probeName] = probe
                        probe.ciNames = data.independentNames()
                  
                    for node in data:
                        mData = __MeasurementData__()
                        mData.name = data.dependentNames()[0]
                        mData.fName = data.name()
                        probe.mData.append(mData)
                        mData.probe = probe
                        for d in node:
                            mData.data.append(d)
                        mData.iData = node.independentData()
                        mName = mData.name
                        sName = mData.name
                        index = mName.find(".")
                        if index > 0:
                            mName = mName[:index]
                            sName = sName[index+1:]
                        if not self.measurementMap.has_key(mName):
                            self.measurementMap[mName] = []
                        l = self.measurementMap[mName]
                        l.append(mData)
                        self.measurementMap[mName] = l

                        if not self.measurementSignalMap.has_key(sName):
                            self.measurementSignalMap[sName] = []
                        l = self.measurementSignalMap[sName]
                        l.append(mData)
                        self.measurementSignalMap[sName] = l
            elif dataType == ComplianceReport.__batchTableData:
                self.batchTable = BatchTable()
                self.batchTable.variables = data.dependentNames()
                for node in data:
                    for d in node:
                        self.batchTable.data.append(d)
        
        w = pyExcelerator.Workbook()
        if self.saveComplianceSummary:
            self.outputExcelComplianceData(w)
            
        if self.saveMeasurementSummary:
            self.outputExcelMeasurementSummaryData(w)
            
        if self.batchTable:
            self.outputExcelBatchTable(w)
            
        if self.saveMeasurementMS:
            self.outputExcelMeasurement_SortedByMeasurementName(w)
            
        if self.saveMeasurementSS:
            self.outputExcelMeasurement_SortedBySignalName(w);
            
        if self.saveMeasurementPS:
            self.outputExcelMeasurement_SortedByProbeName(w);

        if self.outputSize > 0:
            try:
                f = file(self.fileName,'wb')
                f.close()
            except:
                _temp_ = self.fileTime + "_" + self.fileName
                self.simulation.printWarning("Compliance Excel Report","Unable to open excel file '" +
                                             self.fileName + "'\n Trying the following name '" +
                                             _temp_ +"'.\n")
                self.fileName = _temp_
            w.save(self.fileName)
        
    def outputExcelBatchTable(self,w):
        columnStyle = self.__style(True,None,1.0)
        p = w.add_sheet("Batch Table")
        p.col(0).width = 0x0FE1
        rIndex = 0
        p.write(rIndex,0,"BatchNumber",columnStyle)
        index = 1
        for i in self.batchTable.variables:
            p.col(index).width = 0x0FE1
            p.write(rIndex,index,i,columnStyle)
            index += 1
        rIndex = 1
        for i in self.batchTable.data:
            index = 0
            for j in i:
                p.write(rIndex,index,j)
                index += 1
            rIndex += 1
        self.outputSize += 1
        
                        
    def outputExcelMeasurementSummaryData(self,w):
        columnStyle = self.__style(True,None,1.0)
        total = 0
        independents = None
        sameIndependent = True
        maxISize = 0
 
        for i in self.probeMap:
            probe = self.probeMap[i]
            if total == 0:
                independents = probe.ciNames
            else:
                if independents != probe.ciNames:
                    sameIndependent = False
            if probe.ciNames:
                l = len(probe.ciNames)
                if l > maxISize:
                    maxISize = l
            if probe.complianceData:
                total += 1
 
        if total == 0:
            return
        if(independents):
            if len(independents) >= 1:
                independents = independents[0:len(independents)-1]
                
        p = w.add_sheet("Measurement Summary")
        p.col(0).width = 0x24E1
        p.col(1).width = 0x24E1
        p.col(2).width = 0x0FE1
        p.col(3).width = 0x0FE1
        p.col(4).width = 0x0FE1
        p.col(5).width = 0x0FE1
        for i in xrange(maxISize):
            p.col(6+i).width = 0x0FE1
            
        rIndex = 0
        p.write(rIndex,0,"Probe",columnStyle)
        p.write(rIndex,1,"Measurement",columnStyle)
        p.write(rIndex,2,"Signal",columnStyle)
        p.write(rIndex,3,"Minimum",columnStyle)
        p.write(rIndex,4,"Maximum",columnStyle)
        p.write(rIndex,5,"Average",columnStyle)
        if sameIndependent:
            ii = 0
            for c in independents:
                p.write(rIndex,6+ii,c,columnStyle)
                ii += 1
        rIndex += 1
        sortedProbeMap = {}
        for i in self.probeMap:
            probe = self.probeMap[i]
            index = probe.name.rfind(".")
            probe.name = probe.name[index+1:]
            sortedProbeMap[probe.name] = probe
        keys = sortedProbeMap.keys()
        keys.sort()
        for i in keys:
            probe = sortedProbeMap[i]
            index = probe.name.rfind(".")
            for m in probe.mData:
                m.getStat()
                index = m.name.find(".")
                sName = "None"
                mName = m.name
                if index > 0:
                    sName = m.name[index+1:]
                    mName = m.name[:index]
                p.write(rIndex,0,probe.name)
                p.write(rIndex,1,mName)
                p.write(rIndex,2,sName)
                if (m.min != None) and (m.max != None) and (m.average != None):
                    p.write(rIndex,3,m.min)
                    p.write(rIndex,4,m.max)
                    p.write(rIndex,5,m.average)
                    if sameIndependent:
                        if m.iData:
                            ii = 0
                            for c in m.iData:
                                p.write(rIndex,6+ii,(c))
                                ii += 1
                    rIndex += 1
                else:
                    rIndex += 1
        self.outputSize += 1
            
        
    def __formatLimits(self,data):
        P_inf = 1e100
        N_inf = -1e100
        if data > P_inf:
            return "infinity"
        if data < N_inf:
            return "-infinity"
        return data

    def __style(self,bold,color=None,factor=1):   
	font = pyExcelerator.Font()
	font.bold = bold
        font.height = int(font.height * factor)
        if color:
            if color == 'red':
                font.colour_index = 2
            elif color == 'blue':
                font.colour_index = 3
        style = pyExcelerator.XFStyle()
        style.font = font
        
	return style   

    def outputExcelComplianceData(self,w):
        total = 0
        independents = None
        sameIndependent = True
        maxISize = 0
        for i in self.probeMap:
            probe = self.probeMap[i]
            if total == 0:
                independents = probe.ciNames
            else:
                if independents != probe.ciNames:
                    sameIndependent = False
            if probe.ciNames:
                l = len(probe.ciNames)
                if l > maxISize:
                    maxISize = l
            if probe.complianceData:
                total += 1
        if total == 0:
            return
        if(independents):
            if len(independents) >= 1:
                independents = independents[0:len(independents)-1]
        p = w.add_sheet("Compliance Report")
        p.col(0).width = 0x24E1
        p.col(1).width = 0x24E1
        p.col(2).width = 0x0FE1
        p.col(3).width = 0x0FE1
        p.col(4).width = 0x0FE1
        p.col(5).width = 0x0FE1
        for i in xrange(maxISize):
            p.col(6+i).width = 0x0FE1

        passData = []
        failData = []

        sortedProbeMap = {}
        for i in self.probeMap:
            probe = self.probeMap[i]
            index = probe.name.rfind(".")
            probe.name = probe.name[index+1:]
            sortedProbeMap[probe.name] = probe
        keys = sortedProbeMap.keys()
        keys.sort()
        for i in keys:
            probe = sortedProbeMap[i]
            if probe.complianceData:
                length = len(probe.cmNames)
                index = 0
                for j in probe.complianceData.data:
                    if abs(j.passMargin) > 0:
                        d = [probe.name,probe.cmNames[index],j.iData,j.lower,j.upper,j.passMargin]
                        passData.append(d)
                    else:
                        d = [probe.name,probe.cmNames[index],j.iData,j.lower,j.upper,j.lowerViolation,j.upperViolation]
                        failData.append(d)
                    index += 1
                    if index >= length:
                        index = 0
             
        p.write(0,0,"Compliance Report",self.__style(True,None,2))
        rIndex = 2
        p.write(rIndex,0,"Design",self.__style(False,None,1.1))
        p.write(rIndex,1,self.designName,self.__style(False,None,1.1))
        rIndex += 1
        p.write(rIndex,0,"Date",self.__style(False,None,1.1))
        p.write(rIndex,1,str(self.time),self.__style(False,None,1.1))
        rIndex += 2
        p.write(rIndex,0,"Pass",self.__style(False,None,1.5))
        p.write(rIndex,1,len(passData),self.__style(False,None,1.5))
        rIndex += 1
        p.write(rIndex,0,"Fail",self.__style(False,'red',1.5))
        p.write(rIndex,1,len(failData),self.__style(False,'red',1.5))
        rIndex += 2
        P_inf = 1e100
        N_inf = -1e100
        headingStyle = self.__style(True,None,1.2)
        columnStyle = self.__style(True,None,1.0)
        if len(passData) > 0:
            p.write(rIndex,0,"Passing Tests",headingStyle)
            rIndex += 1
            p.write(rIndex,0,"Probe",columnStyle)
            p.write(rIndex,1,"Measurement",columnStyle)
            p.write(rIndex,2,"Lower limit",columnStyle)
            p.write(rIndex,3,"Upper limit",columnStyle)
            p.write(rIndex,4,"Margin",columnStyle)
            if sameIndependent:
                ii = 0
                for c in independents:
                    p.write(rIndex,5+ii,c,columnStyle)
                    ii += 1
            rIndex += 1
            for i in passData:
                probeName = i[0]
                mNames = i[1]
                iData = i[2]
                lower = i[3]
                upper = i[4]
                passMargin = i[5]
                p.write(rIndex,0,probeName)
                p.write(rIndex,1,mNames)
                p.write(rIndex,2,self.__formatLimits(lower))
                p.write(rIndex,3,self.__formatLimits(upper))
                p.write(rIndex,4,passMargin)
                if sameIndependent:
                    if iData:
                        ii = 0
                        for c in iData:
                            p.write(rIndex,5+ii,(c))
                            ii += 1
                rIndex += 1
        rIndex += 2
        headingStyle = self.__style(True,'red',1.2)
        if len(failData) > 0:
            p.write(rIndex,0,"Failing Tests",headingStyle)
            rIndex += 1
            p.write(rIndex,0,"Probe",columnStyle)
            p.write(rIndex,1,"Measurement",columnStyle)
            p.write(rIndex,2,"Lower limit",columnStyle)
            p.write(rIndex,3,"Upper limit",columnStyle)
            p.write(rIndex,4,"Lower Violation",columnStyle)
            p.write(rIndex,5,"Upper Violation",columnStyle)
            if sameIndependent:
                ii = 0
                for c in independents:
                    p.write(rIndex,6+ii,c,columnStyle)
                    ii += 1
            rIndex += 1
            for i in failData:
                probeName = i[0]
                mNames = i[1]
                iData = i[2]
                lower = i[3]
                upper = i[4]
                lowerViolation = i[5]
                upperViolation = i[6]
                p.write(rIndex,0,probeName)
                p.write(rIndex,1,mNames)
                p.write(rIndex,2,self.__formatLimits(lower))
                p.write(rIndex,3,self.__formatLimits(upper))
                p.write(rIndex,4,lowerViolation)
                p.write(rIndex,5,upperViolation)
                if sameIndependent:
                    if iData:
                        ii = 0
                        for c in iData:
                            p.write(rIndex,6+ii,(c))
                            ii += 1
                            
                rIndex += 1
        self.outputSize += 1   
        return
    
    def outputExcelMeasurement_SortedByProbeName(self,w):
        headerStyle = self.__style(True,None,0.9)
        dataStyle = self.__style(True,None,0.9)
        sortedProbeMap = {}
        for i in self.probeMap:
            probe = self.probeMap[i]
            index = probe.name.rfind(".")
            probe.name = probe.name[index+1:]
            sortedProbeMap[probe.name] = probe
        keys = sortedProbeMap.keys()
        keys.sort()

        if len(keys) == 0:
            return
        for i in keys:
            p = w.add_sheet(i)
            probe = sortedProbeMap[i]
            varIndex = 0
            for mData in probe.mData:
                name = mData.name
                if mData.iData:
                    iName = []
                    for i in mData.iData:
                        if type(i) == types.FloatType:
                            iName.append(str("%g")%i)
                        else:
                            iName.append(str(i))
                    name = name + str(iName)
                p.write(0,varIndex,name,headerStyle)
                length = len(name)
                if length < 20:
                    p.col(varIndex).width = 0x14E1
                else:
                    l = (length << 8) | (0xE1)
                    p.col(varIndex).width = l
                dataIndex = 1
                for data in mData.data:
                    _data = data[1]
                    p.write(dataIndex,varIndex,_data)
                    dataIndex += 1              
                varIndex += 1
        self.outputSize += 1
        
        
        return
        
    def outputExcelMeasurement_SortedBySignalName(self,w):
        keys = self.measurementSignalMap.keys()
        columnStyle = self.__style(True,None,0.9)
        if len(keys) == 0:
            return
        for i in keys:
            p = w.add_sheet(i)
            data = self.measurementSignalMap[i]
            data.reverse()
            varIndex = -1
            for j in data:
                varIndex += 1
                name = j.name
                nIndex = name.index(".")
                if nIndex > 0:
                    name = name[:nIndex]
                if j.iData == None:
                    p.write(0,varIndex,(name),columnStyle)
                else:
                    n = name + str(j.iData)
                    p.write(0,varIndex,n,columnStyle)
               
                length = len(name)
                if length < 20:
                    p.col(varIndex).width = 0x14E1
                else:
                    l = (length << 8) | (0xE1)
                    p.col(varIndex).width = l
                index = 1
                for k in j.data:
                    p.write(index,varIndex,k[1])
                    index += 1
        self.outputSize += 1

    def outputExcelMeasurement_SortedByMeasurementName(self,w):
        keys = self.measurementMap.keys()
        columnStyle = self.__style(True,None,0.9)
        if len(keys) == 0:
            return
        for i in keys:
            p = w.add_sheet(i)
            data = self.measurementMap[i]
            data.reverse()
            varIndex = -1
            for j in data:
                varIndex += 1
                name = j.name
                nIndex = name.index(".")
                if nIndex > 0:
                    name = name[nIndex+1:]
                length = len(name)
                if length < 20:
                    p.col(varIndex).width = 0x14E1
                else:
                    l = (length << 8) | (0xE1)
                    p.col(varIndex).width = l   
                
                if j.iData == None:
                    p.write(0,varIndex,(name),columnStyle)
                else:
                    n = name + str(j.iData)
                    p.write(0,varIndex,n,columnStyle)
               
                index = 1
                for k in j.data:
                    p.write(index,varIndex,k[1])
                    index += 1
        self.outputSize += 1
        
    def getDataType(self,data):
        dataType = 0
        name = data.name()
        if name.find("TDCM.") == 0:
            dataType = ComplianceReport.__tdcmData
            if name.find(".DDR3.") > 0:
                dataType = dataType | ComplianceReport.__ddr3Data
            if name.find(".ComplianceHistogram.") > 0:
                dataType = dataType | ComplianceReport.__complianceHistogramData
                name = name[:name.find(".ComplianceHistogram.")]
            else:
                i = name.rfind(".")
                if name[i:] == ".Compliance":
                    dataType = dataType |  ComplianceReport.__complianceData
                    name = name[:name.rfind(".Compliance")]
        elif name.find(".BatchSim.TDCM.") >= 0:
            dataType = ComplianceReport.__tdcmData
            if name.find(".DDR3.") > 0:
                dataType = dataType | ComplianceReport.__ddr3Data
            if name.find(".ComplianceHistogram.") > 0:
                dataType = dataType | ComplianceReport.__complianceHistogramData
                name = name[:name.find(".ComplianceHistogram.")]
            else:
                i = name.rfind(".")
                if name[i:] == ".Compliance":
                    dataType = dataType |  ComplianceReport.__complianceData
                    name = name[:name.rfind(".Compliance")]
        elif name == "BatchTable":
            dataType = ComplianceReport.__batchTableData
            name = name
        return (dataType,name)

