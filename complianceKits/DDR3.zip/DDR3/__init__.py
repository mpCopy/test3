from DDR3_Descriptor import *
from DDR3 import *


GlobalLoaders.getComponentLoader().register( DDR3 )
