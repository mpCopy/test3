from ADSSim_Modules import *
from Design import *
from Component import *
DDR3_Descriptor = TDCM_Descriptor("DDR3")
SpeedGradeID = 0
DDR3_Descriptor[SpeedGradeID] = ParameterDescriptor("SpeedGrade")
DDR3_Descriptor[SpeedGradeID].setIsModifiable(True)
DDR3_Descriptor[SpeedGradeID].setIsReadable(True)
DDR3_Descriptor[SpeedGradeID].setIsRequired(False)
DDR3_Descriptor[SpeedGradeID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vihACID = 1
DDR3_Descriptor[vihACID] = ParameterDescriptor("vihAC")
DDR3_Descriptor[vihACID].setIsModifiable(True)
DDR3_Descriptor[vihACID].setIsReadable(True)
DDR3_Descriptor[vihACID].setIsRequired(False)
DDR3_Descriptor[vihACID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vihDCID = 2
DDR3_Descriptor[vihDCID] = ParameterDescriptor("vihDC")
DDR3_Descriptor[vihDCID].setIsModifiable(True)
DDR3_Descriptor[vihDCID].setIsReadable(True)
DDR3_Descriptor[vihDCID].setIsRequired(False)
DDR3_Descriptor[vihDCID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vRefID = 3
DDR3_Descriptor[vRefID] = ParameterDescriptor("vRef")
DDR3_Descriptor[vRefID].setIsModifiable(True)
DDR3_Descriptor[vRefID].setIsReadable(True)
DDR3_Descriptor[vRefID].setIsRequired(False)
DDR3_Descriptor[vRefID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vilDCID = 4
DDR3_Descriptor[vilDCID] = ParameterDescriptor("vilDC")
DDR3_Descriptor[vilDCID].setIsModifiable(True)
DDR3_Descriptor[vilDCID].setIsReadable(True)
DDR3_Descriptor[vilDCID].setIsRequired(False)
DDR3_Descriptor[vilDCID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vilACID = 5
DDR3_Descriptor[vilACID] = ParameterDescriptor("vilAC")
DDR3_Descriptor[vilACID].setIsModifiable(True)
DDR3_Descriptor[vilACID].setIsReadable(True)
DDR3_Descriptor[vilACID].setIsRequired(False)
DDR3_Descriptor[vilACID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vDDID = 6
DDR3_Descriptor[vDDID] = ParameterDescriptor("vDD")
DDR3_Descriptor[vDDID].setIsModifiable(True)
DDR3_Descriptor[vDDID].setIsReadable(True)
DDR3_Descriptor[vDDID].setIsRequired(False)
DDR3_Descriptor[vDDID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vSSID = 7
DDR3_Descriptor[vSSID] = ParameterDescriptor("vSS")
DDR3_Descriptor[vSSID].setIsModifiable(True)
DDR3_Descriptor[vSSID].setIsReadable(True)
DDR3_Descriptor[vSSID].setIsRequired(False)
DDR3_Descriptor[vSSID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vMeasID = 8
DDR3_Descriptor[vMeasID] = ParameterDescriptor("vMeas")
DDR3_Descriptor[vMeasID].setIsModifiable(True)
DDR3_Descriptor[vMeasID].setIsReadable(True)
DDR3_Descriptor[vMeasID].setIsRequired(False)
DDR3_Descriptor[vMeasID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



