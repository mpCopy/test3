# Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
from ADSSim_Modules import *
from Design import *
from Component import *
DDR2_Descriptor = TDCM_Descriptor("DDR2")
SpeedGradeID = 0
DDR2_Descriptor[SpeedGradeID] = ParameterDescriptor("SpeedGrade")
DDR2_Descriptor[SpeedGradeID].setIsModifiable(True)
DDR2_Descriptor[SpeedGradeID].setIsReadable(True)
DDR2_Descriptor[SpeedGradeID].setIsRequired(False)
DDR2_Descriptor[SpeedGradeID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vihACID = 1
DDR2_Descriptor[vihACID] = ParameterDescriptor("vihAC")
DDR2_Descriptor[vihACID].setIsModifiable(True)
DDR2_Descriptor[vihACID].setIsReadable(True)
DDR2_Descriptor[vihACID].setIsRequired(False)
DDR2_Descriptor[vihACID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vihDCID = 2
DDR2_Descriptor[vihDCID] = ParameterDescriptor("vihDC")
DDR2_Descriptor[vihDCID].setIsModifiable(True)
DDR2_Descriptor[vihDCID].setIsReadable(True)
DDR2_Descriptor[vihDCID].setIsRequired(False)
DDR2_Descriptor[vihDCID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vRefID = 3
DDR2_Descriptor[vRefID] = ParameterDescriptor("vRef")
DDR2_Descriptor[vRefID].setIsModifiable(True)
DDR2_Descriptor[vRefID].setIsReadable(True)
DDR2_Descriptor[vRefID].setIsRequired(False)
DDR2_Descriptor[vRefID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vilDCID = 4
DDR2_Descriptor[vilDCID] = ParameterDescriptor("vilDC")
DDR2_Descriptor[vilDCID].setIsModifiable(True)
DDR2_Descriptor[vilDCID].setIsReadable(True)
DDR2_Descriptor[vilDCID].setIsRequired(False)
DDR2_Descriptor[vilDCID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vilACID = 5
DDR2_Descriptor[vilACID] = ParameterDescriptor("vilAC")
DDR2_Descriptor[vilACID].setIsModifiable(True)
DDR2_Descriptor[vilACID].setIsReadable(True)
DDR2_Descriptor[vilACID].setIsRequired(False)
DDR2_Descriptor[vilACID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vDDID = 6
DDR2_Descriptor[vDDID] = ParameterDescriptor("vDD")
DDR2_Descriptor[vDDID].setIsModifiable(True)
DDR2_Descriptor[vDDID].setIsReadable(True)
DDR2_Descriptor[vDDID].setIsRequired(False)
DDR2_Descriptor[vDDID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vSSID = 7
DDR2_Descriptor[vSSID] = ParameterDescriptor("vSS")
DDR2_Descriptor[vSSID].setIsModifiable(True)
DDR2_Descriptor[vSSID].setIsReadable(True)
DDR2_Descriptor[vSSID].setIsRequired(False)
DDR2_Descriptor[vSSID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



vMeasID = 8
DDR2_Descriptor[vMeasID] = ParameterDescriptor("vMeas")
DDR2_Descriptor[vMeasID].setIsModifiable(True)
DDR2_Descriptor[vMeasID].setIsReadable(True)
DDR2_Descriptor[vMeasID].setIsRequired(False)
DDR2_Descriptor[vMeasID].setDataType(PrimitiveDataType[types.FloatType]|PrimitiveDataType[types.IntType])



class  DDR2 (TDCM_Loader):
	descriptor = DDR2_Descriptor

	def __init__(self,instance):
		TDCM_Loader.__init__( self, instance )
		self.package = "DDR2"



GlobalLoaders.getComponentLoader().register( DDR2 )
