// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "CmdAdd_Clock_Skew.h"
#include "CmdAddTimingCmdAdd.h"
#include "CmdAddTimingClk.h"
#include <math.h>

CmdAdd_Clock_Skew::CmdAdd_Clock_Skew(){}

CmdAdd_Clock_Skew::~CmdAdd_Clock_Skew(){}

/// Define functions of class CmdAdd_Clock_Skew
/// These functions are for skews calculation between Cmd/Add and Clock singals.

void CmdAdd_Clock_Skew::initialize(){
    // initial clearup of vectors
    caSkewSetupFall.clear();
    caSkewSetupRise.clear();
    caSkewHoldFall.clear();
    caSkewHoldRise.clear();
}
void CmdAdd_Clock_Skew::event(Trigger* trigger){}

void CmdAdd_Clock_Skew::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void CmdAdd_Clock_Skew::finalize(){
    CmdAddTimingCmdAdd*  caCmdAddTiming  = (CmdAddTimingCmdAdd*)this->package->getMeasurement("CmdAddTimingCmdAdd",signal.CmdAdd);
    CmdAddTimingClk* clkCmdAddTiming = (CmdAddTimingClk*)this->package->getMeasurement("CmdAddTimingClk",signal.Clock);
   
    if((!caCmdAddTiming) || (!clkCmdAddTiming)){
        package->error("CmdAdd_Clock_Skew requires both CmdAddTimingCmdAdd and CmdAddTimingClock selected.");
        return;
    }

    double tempValue, clkFlightTimeMax, clkFlightTimeMin, clkSlewRMax;
    int index, numSkip=3;

    // Get max and min clkFlightTime from clkFlightTimeFall and clkFlightTimeRise
    // Get max clkSlewR from clkSlewRFall and clkSkewRRise
    Container<double>* clkFlightTimeFall = clkCmdAddTiming->clkFlightTimeFall.head();
    Container<double>* clkFlightTimeRise = clkCmdAddTiming->clkFlightTimeRise.head();
    Container<double>* clkSlewRFall = clkCmdAddTiming->clkSlewRFall.head();
    Container<double>* clkSlewRRise = clkCmdAddTiming->clkSlewRRise.head();
    if(!(clkFlightTimeFall) || !(clkFlightTimeRise) || !(clkSlewRFall) || !(clkSlewRRise)){
        package->error("No data from CmdAddTimingClock. Check Clock probe connection.");
        return;
    }
    for(index=0; index < numSkip; index++){
        if(clkFlightTimeFall->next())
            clkFlightTimeFall = clkFlightTimeFall->next();
        if(clkFlightTimeRise->next())
            clkFlightTimeRise = clkFlightTimeRise->next();
        if(clkSlewRFall->next())
            clkSlewRFall = clkSlewRFall->next();
        if(clkSlewRRise->next())
            clkSlewRRise = clkSlewRRise->next();
    }
    clkFlightTimeMax = clkFlightTimeFall->data();
    clkFlightTimeMin = clkFlightTimeFall->data();
    while(clkFlightTimeFall->next()){
        clkFlightTimeFall = clkFlightTimeFall->next();
        tempValue = clkFlightTimeFall->data();
        if(clkFlightTimeMax < tempValue)
            clkFlightTimeMax = tempValue;
        if(clkFlightTimeMin > tempValue)
            clkFlightTimeMin = tempValue;
    }
    while(clkFlightTimeRise->next()){
        clkFlightTimeRise = clkFlightTimeRise->next();
        tempValue = clkFlightTimeRise->data();
        if(clkFlightTimeMax < tempValue)
            clkFlightTimeMax = tempValue;
        if(clkFlightTimeMin > tempValue)
            clkFlightTimeMin = tempValue;
    }
    clkSlewRMax = clkSlewRFall->data();
    while(clkSlewRFall->next()){
        clkSlewRFall = clkSlewRFall->next();
        tempValue = clkSlewRFall->data();
        if(clkSlewRMax < tempValue)
            clkSlewRMax = tempValue;
    }
    while(clkSlewRRise->next()){
        clkSlewRRise = clkSlewRRise->next();
        tempValue = clkSlewRRise->data();
        if(clkSlewRMax < tempValue)
            clkSlewRMax = tempValue;
    }

    // calculate derated skews
    CSVData* Data_Derating;
    CSVMatrix* Derating;
    bool derateAvil;
    Container<double>* caFlightTimeSetupFall = caCmdAddTiming->caFlightTimeSetupFall.head();
    Container<double>* caFlightTimeSetupRise = caCmdAddTiming->caFlightTimeSetupRise.head();
    Container<double>* caFlightTimeHoldFall = caCmdAddTiming->caFlightTimeHoldFall.head();
    Container<double>* caFlightTimeHoldRise = caCmdAddTiming->caFlightTimeHoldRise.head();
    Container<double>* caSlewRSetupFall = caCmdAddTiming->caSlewRSetupFall.head();
    Container<double>* caSlewRSetupRise = caCmdAddTiming->caSlewRSetupRise.head();
    Container<double>* caSlewRHoldFall = caCmdAddTiming->caSlewRHoldFall.head();
    Container<double>* caSlewRHoldRise = caCmdAddTiming->caSlewRHoldRise.head();
    //setup skew
    derateAvil = true;
    if((package->parameter.SpeedGrade == 400) || (package->parameter.SpeedGrade == 533))
        Data_Derating = CSVData::parse(this->package,"DDR2_derating_table_CmdAdd_Setup_400_533.csv");
    else if((package->parameter.SpeedGrade == 677) || (package->parameter.SpeedGrade == 800) || (package->parameter.SpeedGrade == 1066))
        Data_Derating = CSVData::parse(this->package,"DDR2_derating_table_CmdAdd_Setup_677_800_1066.csv");
    else
        derateAvil = false;
    if(CSVData::errorOccured()){
        package->error(CSVData::error());
        derateAvil = false;
    }
    if(derateAvil)
        Derating = static_cast<CSVMatrix*>(Data_Derating);
    while(caFlightTimeSetupFall && caSlewRSetupFall){
        tempValue = caFlightTimeSetupFall->data() - clkFlightTimeMin;
        if(derateAvil)
            tempValue += Derating->lookup(clkSlewRMax, caSlewRSetupFall->data());
        caSkewSetupFall.append(tempValue);
        caFlightTimeSetupFall = caFlightTimeSetupFall->next();
        caSlewRSetupFall = caSlewRSetupFall->next();
    }
    while(caFlightTimeSetupRise && caSlewRSetupRise){
        tempValue = caFlightTimeSetupRise->data() - clkFlightTimeMin;
        if(derateAvil)
            tempValue += Derating->lookup(clkSlewRMax, caSlewRSetupRise->data());
        caSkewSetupRise.append(tempValue);
        caFlightTimeSetupRise = caFlightTimeSetupRise->next();
        caSlewRSetupRise = caSlewRSetupRise->next();
    }
    //hold skew
    derateAvil = true;
    if((package->parameter.SpeedGrade == 400) || (package->parameter.SpeedGrade == 533) || 
        (package->parameter.SpeedGrade == 677) || (package->parameter.SpeedGrade == 800) || (package->parameter.SpeedGrade == 1066))
        Data_Derating = CSVData::parse(this->package,"DDR2_derating_table_CmdAdd_Hold.csv");
    else
        derateAvil = false;
    if(CSVData::errorOccured()){
        package->error(CSVData::error());
        derateAvil = false;
    }
    if(derateAvil)
        Derating = static_cast<CSVMatrix*>(Data_Derating);
    while(caFlightTimeHoldFall && caSlewRHoldFall){
        tempValue = clkFlightTimeMax - caFlightTimeHoldFall->data();
        if(derateAvil)
            tempValue += Derating->lookup(clkSlewRMax, caSlewRHoldFall->data());
        caSkewHoldFall.append(tempValue);
        caFlightTimeHoldFall = caFlightTimeHoldFall->next();
        caSlewRHoldFall = caSlewRHoldFall->next();
    }
    while(caFlightTimeHoldRise && caSlewRHoldRise){
        tempValue = clkFlightTimeMax - caFlightTimeHoldRise->data();
        if(derateAvil)
            tempValue += Derating->lookup(clkSlewRMax, caSlewRHoldRise->data());
        caSkewHoldRise.append(tempValue);
        caFlightTimeHoldRise = caFlightTimeHoldRise->next();
        caSlewRHoldRise = caSlewRHoldRise->next();
    }

    // save the results
    PackageSignal* packageSignal = (PackageSignal*)signal.CmdAdd.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("CmdAdd_ClockSkewSetupFall", "Index", generateName(buffer,"CmdAdd_ClockSkewSetupFall",nodeName), caSkewSetupFall);
    save("CmdAdd_ClockSkewSetupRise", "Index", generateName(buffer,"CmdAdd_ClockSkewSetupRise",nodeName), caSkewSetupRise);
    save("CmdAdd_ClockSkewHoldFall", "Index", generateName(buffer,"CmdAdd_ClockSkewHoldFall",nodeName), caSkewHoldFall);
    save("CmdAdd_ClockSkewHoldRise", "Index", generateName(buffer,"CmdAdd_ClockSkewHoldRise",nodeName), caSkewHoldRise);
}

void CmdAdd_Clock_Skew::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.CmdAdd.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    package->check(this,"CmdAdd_ClockSkewSetupFall", caSkewSetupFall, generateName(buffer,"CmdAdd_ClockSkewSetupFall",nodeName));
    package->check(this,"CmdAdd_ClockSkewSetupRise", caSkewSetupRise, generateName(buffer,"CmdAdd_ClockSkewSetupRise",nodeName));
    package->check(this,"CmdAdd_ClockSkewHoldFall", caSkewHoldFall, generateName(buffer,"CmdAdd_ClockSkewHoldFall",nodeName));
    package->check(this,"CmdAdd_ClockSkewHoldRise", caSkewHoldRise, generateName(buffer,"CmdAdd_ClockSkewHoldRise",nodeName));
}
