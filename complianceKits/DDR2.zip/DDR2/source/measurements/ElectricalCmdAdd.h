// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class ElectricalCmdAdd.
/// This class is for electrical measurements on Command/Address singals.

class ElectricalCmdAdd:public Measurement{
public:
	ElectricalCmdAdd();
	virtual ~ElectricalCmdAdd();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__ElectricalCmdAdd"

        // vectors to save measurement results
        DoubleVector caOvershootPeak;
        DoubleVector caUndershootPeak;
        DoubleVector caOvershootArea;
        DoubleVector caUndershootArea;
        DoubleVector caNoiseMarginHigh;
        DoubleVector caNoiseMarginLow;

protected:
        // vectros to save waveform for overshoot/undershoot calculation
        DoubleVector caShootWaveform;
        DoubleVector caShootTime;

        // CmdAdd triggers at threshold voltages
        Trigger* caFallvDDTrigger;
        Trigger* caFallvihDCTrigger;
        Trigger* caFallvRefTrigger;
        Trigger* caFallvilDCTrigger;
        Trigger* caFallvSSTrigger;
        Trigger* caRisevSSTrigger;
        Trigger* caRisevilDCTrigger;
        Trigger* caRisevRefTrigger;
        Trigger* caRisevihDCTrigger;
        Trigger* caRisevDDTrigger;

        bool evalState;
        bool caShootMode;
        bool caNoiseMarginHighMode;
        bool caNoiseMarginLowMode;
        int lastcaSlope;
        int caSlope;

        // variables to save trigger times
        double firstcaFallvRef;
        double lastcaFallvRef;
        double firstcaFallvilDC;
        double lastcaFallvilDC;
        double firstcaRisevilDC;
        double firstcaRisevRef;
        double lastcaRisevRef;
        double firstcaRisevihDC;
        double lastcaRisevihDC;
        double firstcaFallvihDC;

        double caShootPeakTemp;
        double caShootAreaTemp;
        double caNoiseMarginHighTemp;
        double caNoiseMarginLowTemp;
        double lastca;
        double ca;
        double UI;
};
