// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class CmdAddTimingCmdAdd.
/// This class is for Command/Address timing measurements on Command/Address singals.

class CmdAddTimingCmdAdd:public Measurement{
public:
	CmdAddTimingCmdAdd();
	virtual ~CmdAddTimingCmdAdd();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__CmdAddTimingCmdAdd"

        // vectors to save measurement results
        DoubleVector caFlightTimeSetupFall;
        DoubleVector caFlightTimeSetupRise;
        DoubleVector caFlightTimeHoldFall;
        DoubleVector caFlightTimeHoldRise;
        DoubleVector caSlewRSetupFall;
        DoubleVector caSlewRSetupRise;
        DoubleVector caSlewRHoldFall;
        DoubleVector caSlewRHoldRise;

protected:
        // vectors to save wavefrom for slew rate calculation
        DoubleVector caSlewRWaveform;
        DoubleVector caSlewRTime;

        // queues to save CmdAdd_Reference trigger times
        Queue<double> caRefFallvMeasTime;
        Queue<double> caRefRisevMeasTime;

        // CmdAdd triggers at threshold voltages
        Trigger* caFallvihACTrigger;
        Trigger* caFallvihDCTrigger;
        Trigger* caFallvRefTrigger;
        Trigger* caFallvilDCTrigger;
        Trigger* caFallvilACTrigger;
        Trigger* caRisevilACTrigger;
        Trigger* caRisevilDCTrigger;
        Trigger* caRisevRefTrigger;
        Trigger* caRisevihDCTrigger;
        Trigger* caRisevihACTrigger;

        // CmdAdd_Reference triggers
        Trigger* caRefFallvMeasTrigger;
        Trigger* caRefRisevMeasTrigger;

        bool evalState;
        bool caSlewRMode;
        bool caFlightTimeSetupAvil;
        bool qPop;

        // variables to save trigger times
        double lastcaRefFallvMeas;
        double lastcaRefRisevMeas;
        double firstcaFallvRef;
        double lastcaFallvRef;
        double lastcaFallvilDC;
        double firstcaFallvilAC;
        double lastcaFallvilAC;
        double firstcaRisevilAC;
        double firstcaRisevilDC;
        double lastcaRisevilDC;
        double firstcaRisevRef;
        double lastcaRisevRef;
        double lastcaRisevihDC;
        double firstcaRisevihAC;
        double lastcaRisevihAC;
        double firstcaFallvihAC;
        double firstcaFallvihDC;
        double lastcaFallvihDC;

        double caFlightTimeSetupTemp;
        double caSlewRSetupTemp;
        double UI;
};
