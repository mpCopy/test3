// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class ElectricalDQS.
/// This class is for electrical measurement on DQS singal.

class ElectricalDQS:public Measurement{
public:
	ElectricalDQS();
	virtual ~ElectricalDQS();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__ElectricalDQS"

        // vector to save measurement result
        DoubleVector dqsVix;

protected:
        // DQS triggers at threshold voltages
        Trigger* dqsFallZeroTrigger;
        Trigger* dqsRiseZeroTrigger;

        bool evalState;
        bool singleEnded;
};
