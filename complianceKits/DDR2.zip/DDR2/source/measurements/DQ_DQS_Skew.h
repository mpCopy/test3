// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class DQ_DQS_Skew.
/// This class is for skews calculation between DQ and DQS singals.

class DQ_DQS_Skew:public Measurement{
public:
        DQ_DQS_Skew();
        virtual ~DQ_DQS_Skew();

        virtual void initialize();
        virtual void event(Trigger* trigger);
        virtual void evaluate(double time);
        virtual void finalize();
        virtual void checkCompliance();
#include "__TDCM__Measurement__DQ_DQS_Skew"

        //vectors to save measurement results
        DoubleVector dqSkewSetupFall;
        DoubleVector dqSkewSetupRise;
        DoubleVector dqSkewHoldFall;
        DoubleVector dqSkewHoldRise;
        DoubleVector dqSkewSetupFallVref;
        DoubleVector dqSkewSetupRiseVref;
        DoubleVector dqSkewHoldFallVref;
        DoubleVector dqSkewHoldRiseVref;
        DoubleVector dqReadSkewSetupFall;
        DoubleVector dqReadSkewSetupRise;
        DoubleVector dqReadSkewHoldFall;
        DoubleVector dqReadSkewHoldRise;

protected:
        bool singleEnded;
};
