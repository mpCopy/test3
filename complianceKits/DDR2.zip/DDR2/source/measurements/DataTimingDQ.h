// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class DataTimingDQ.
/// This class is for data timing measurements on DQ singals.

class DataTimingDQ:public Measurement{
public:
	DataTimingDQ();
	virtual ~DataTimingDQ();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__DataTimingDQ"

        // vectors to save measurement results
        DoubleVector dqFlightTimeSetupFall;
        DoubleVector dqFlightTimeSetupRise;
        DoubleVector dqFlightTimeHoldFall;
        DoubleVector dqFlightTimeHoldRise;
        DoubleVector dqReadFlightTimeFallMin;
        DoubleVector dqReadFlightTimeFallMax;
        DoubleVector dqReadFlightTimeRiseMin;
        DoubleVector dqReadFlightTimeRiseMax;
        DoubleVector dqSlewRSetupFall;
        DoubleVector dqSlewRSetupRise;
        DoubleVector dqSlewRHoldFall;
        DoubleVector dqSlewRHoldRise;

protected:
        // vectors to save wavefrom for slew rate calculation
        DoubleVector dqSlewRWaveform;
        DoubleVector dqSlewRTime;

        // queues to save DQ_Reference trigger times
        Queue<double> dqRefFallvMeasTime;
        Queue<double> dqRefRisevMeasTime;

        // DQ triggers at threshold voltages
        Trigger* dqFallvihACTrigger;
        Trigger* dqFallvihDCTrigger;
        Trigger* dqFallvRefTrigger;
        Trigger* dqFallvilDCTrigger;
        Trigger* dqFallvilACTrigger;
        Trigger* dqRisevilACTrigger;
        Trigger* dqRisevilDCTrigger;
        Trigger* dqRisevRefTrigger;
        Trigger* dqRisevihDCTrigger;
        Trigger* dqRisevihACTrigger;

        // DQ_Reference triggers
        Trigger* dqRefFallvMeasTrigger;
        Trigger* dqRefRisevMeasTrigger;

        bool evalState;
        bool dqSlewRMode;
        bool dqFlightTimeSetupAvil;
        bool dqReadFlightTimeAvil;
        bool qPop;

        // variables to save trigger times
        double lastdqRefFallvMeas;
        double lastdqRefRisevMeas;
        double firstdqFallvRef;
        double lastdqFallvRef;
        double lastdqFallvilDC;
        double firstdqFallvilAC;
        double lastdqFallvilAC;
        double firstdqRisevilAC;
        double firstdqRisevilDC;
        double lastdqRisevilDC;
        double firstdqRisevRef;
        double lastdqRisevRef;
        double lastdqRisevihDC;
        double firstdqRisevihAC;
        double lastdqRisevihAC;
        double firstdqFallvihAC;
        double firstdqFallvihDC;
        double lastdqFallvihDC;

        double dqFlightTimeSetupTemp;
        double dqSlewRSetupTemp;
        double dqReadFlightTimeMinTemp;
        double dqReadFlightTimeMaxTemp;
        double UI;
};
