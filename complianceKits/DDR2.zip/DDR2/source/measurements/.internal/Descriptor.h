#ifndef __DDR2__DESCRIPTOR__INCLUDE_FILE__
#define __DDR2__DESCRIPTOR__INCLUDE_FILE__
#include "TDCM.h"

class DDR2_PD:public TDCM::PackageDescriptor{
public:
	DDR2_PD();
	virtual ~DDR2_PD();
	virtual TDCM::Package* createInstance();
};


class DDR2_DataTimingDQ_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_DataTimingDQ_MD();
	 virtual ~DDR2_DataTimingDQ_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_DataTimingDQS_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_DataTimingDQS_MD();
	 virtual ~DDR2_DataTimingDQS_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_CmdAddTimingCmdAdd_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_CmdAddTimingCmdAdd_MD();
	 virtual ~DDR2_CmdAddTimingCmdAdd_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_CmdAddTimingClk_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_CmdAddTimingClk_MD();
	 virtual ~DDR2_CmdAddTimingClk_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_ElectricalDQ_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_ElectricalDQ_MD();
	 virtual ~DDR2_ElectricalDQ_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_ElectricalDQS_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_ElectricalDQS_MD();
	 virtual ~DDR2_ElectricalDQS_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_ElectricalCmdAdd_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_ElectricalCmdAdd_MD();
	 virtual ~DDR2_ElectricalCmdAdd_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_ElectricalClock_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_ElectricalClock_MD();
	 virtual ~DDR2_ElectricalClock_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_DQ_DQS_Skew_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_DQ_DQS_Skew_MD();
	 virtual ~DDR2_DQ_DQS_Skew_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_CmdAdd_Clock_Skew_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_CmdAdd_Clock_Skew_MD();
	 virtual ~DDR2_CmdAdd_Clock_Skew_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_DQS_Clock_Skew_MD:public TDCM::MeasurementDescriptor{
public:
	DDR2_DQS_Clock_Skew_MD();
	 virtual ~DDR2_DQS_Clock_Skew_MD();
	 virtual TDCM::Measurement* createInstance();
};


class DDR2_Package:public TDCM::Package{
public:
	DDR2_Package();
	 virtual ~DDR2_Package();
#include "__TDCM__Package__DDR2"

	virtual char* getConstraintsFileName();

	virtual void check(TDCM::Measurement* measurement,
		const char* name,
		TDCM::DoubleVector& value,const char* outputName){
			if(value.size() == 0){

				return;}

			Package::check(measurement,name,value,outputName);
}
			virtual void finalize(){

			Package::finalize();

TDCM::Container<TDCM::Measurement*>* link = measurements.head();
while(link){
TDCM::Measurement* m = link->data();
m->initialize();link = link->next();}}
virtual void initialize(){
char buffer[1024];
if(!this->measurementsCreated){
Package::initialize();
}
}

};


#endif
