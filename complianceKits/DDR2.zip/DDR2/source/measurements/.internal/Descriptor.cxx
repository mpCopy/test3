#include "Descriptor.h"
#include "DataTimingDQ.h"
#include "DataTimingDQS.h"
#include "CmdAddTimingCmdAdd.h"
#include "CmdAddTimingClk.h"
#include "ElectricalDQ.h"
#include "ElectricalDQS.h"
#include "ElectricalCmdAdd.h"
#include "ElectricalClock.h"
#include "DQ_DQS_Skew.h"
#include "CmdAdd_Clock_Skew.h"
#include "DQS_Clock_Skew.h"
using namespace TDCM;
DDR2_DataTimingDQ_MD::DDR2_DataTimingDQ_MD():
	MeasurementDescriptor("DataTimingDQ"){
	this->defineSignal("DQ");
	this->defineSignal("DQ_Reference");
}

DDR2_DataTimingDQ_MD::~DDR2_DataTimingDQ_MD(){}

Measurement* DDR2_DataTimingDQ_MD::createInstance(){
	return (new DataTimingDQ());
}


DDR2_DataTimingDQS_MD::DDR2_DataTimingDQS_MD():
	MeasurementDescriptor("DataTimingDQS"){
	this->defineSignal("DQS");
	this->defineSignal("DQS_Reference");
}

DDR2_DataTimingDQS_MD::~DDR2_DataTimingDQS_MD(){}

Measurement* DDR2_DataTimingDQS_MD::createInstance(){
	return (new DataTimingDQS());
}


DDR2_CmdAddTimingCmdAdd_MD::DDR2_CmdAddTimingCmdAdd_MD():
	MeasurementDescriptor("CmdAddTimingCmdAdd"){
	this->defineSignal("CmdAdd");
	this->defineSignal("CmdAdd_Reference");
}

DDR2_CmdAddTimingCmdAdd_MD::~DDR2_CmdAddTimingCmdAdd_MD(){}

Measurement* DDR2_CmdAddTimingCmdAdd_MD::createInstance(){
	return (new CmdAddTimingCmdAdd());
}


DDR2_CmdAddTimingClk_MD::DDR2_CmdAddTimingClk_MD():
	MeasurementDescriptor("CmdAddTimingClk"){
	this->defineSignal("Clock");
	this->defineSignal("Clock_Reference");
}

DDR2_CmdAddTimingClk_MD::~DDR2_CmdAddTimingClk_MD(){}

Measurement* DDR2_CmdAddTimingClk_MD::createInstance(){
	return (new CmdAddTimingClk());
}


DDR2_ElectricalDQ_MD::DDR2_ElectricalDQ_MD():
	MeasurementDescriptor("ElectricalDQ"){
	this->defineSignal("DQ");
}

DDR2_ElectricalDQ_MD::~DDR2_ElectricalDQ_MD(){}

Measurement* DDR2_ElectricalDQ_MD::createInstance(){
	return (new ElectricalDQ());
}


DDR2_ElectricalDQS_MD::DDR2_ElectricalDQS_MD():
	MeasurementDescriptor("ElectricalDQS"){
	this->defineSignal("DQS");
}

DDR2_ElectricalDQS_MD::~DDR2_ElectricalDQS_MD(){}

Measurement* DDR2_ElectricalDQS_MD::createInstance(){
	return (new ElectricalDQS());
}


DDR2_ElectricalCmdAdd_MD::DDR2_ElectricalCmdAdd_MD():
	MeasurementDescriptor("ElectricalCmdAdd"){
	this->defineSignal("CmdAdd");
}

DDR2_ElectricalCmdAdd_MD::~DDR2_ElectricalCmdAdd_MD(){}

Measurement* DDR2_ElectricalCmdAdd_MD::createInstance(){
	return (new ElectricalCmdAdd());
}


DDR2_ElectricalClock_MD::DDR2_ElectricalClock_MD():
	MeasurementDescriptor("ElectricalClock"){
	this->defineSignal("Clock");
}

DDR2_ElectricalClock_MD::~DDR2_ElectricalClock_MD(){}

Measurement* DDR2_ElectricalClock_MD::createInstance(){
	return (new ElectricalClock());
}


DDR2_DQ_DQS_Skew_MD::DDR2_DQ_DQS_Skew_MD():
	MeasurementDescriptor("DQ_DQS_Skew"){
	this->defineSignal("DQ");
	this->defineSignal("DQ_Reference");
	this->defineSignal("DQS");
	this->defineSignal("DQS_Reference");
}

DDR2_DQ_DQS_Skew_MD::~DDR2_DQ_DQS_Skew_MD(){}

Measurement* DDR2_DQ_DQS_Skew_MD::createInstance(){
	return (new DQ_DQS_Skew());
}


DDR2_CmdAdd_Clock_Skew_MD::DDR2_CmdAdd_Clock_Skew_MD():
	MeasurementDescriptor("CmdAdd_Clock_Skew"){
	this->defineSignal("CmdAdd");
	this->defineSignal("CmdAdd_Reference");
	this->defineSignal("Clock");
	this->defineSignal("Clock_Reference");
}

DDR2_CmdAdd_Clock_Skew_MD::~DDR2_CmdAdd_Clock_Skew_MD(){}

Measurement* DDR2_CmdAdd_Clock_Skew_MD::createInstance(){
	return (new CmdAdd_Clock_Skew());
}


DDR2_DQS_Clock_Skew_MD::DDR2_DQS_Clock_Skew_MD():
	MeasurementDescriptor("DQS_Clock_Skew"){
	this->defineSignal("DQS");
	this->defineSignal("DQS_Reference");
	this->defineSignal("Clock");
	this->defineSignal("Clock_Reference");
}

DDR2_DQS_Clock_Skew_MD::~DDR2_DQS_Clock_Skew_MD(){}

Measurement* DDR2_DQS_Clock_Skew_MD::createInstance(){
	return (new DQS_Clock_Skew());
}


DDR2_PD::DDR2_PD():
PackageDescriptor("DDR2"){
	this->setNumberOfParameters(9);
	init();
	Range* range = NULL;
	range = new Range(RangeUtility::GTE(0.0),RangeUtility::LTE(P_INF));
	defineParameter(0,ParameterUtility::RealParameter("SpeedGrade",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(1,ParameterUtility::RealParameter("vihAC",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(2,ParameterUtility::RealParameter("vihDC",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(3,ParameterUtility::RealParameter("vRef",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(4,ParameterUtility::RealParameter("vilDC",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(5,ParameterUtility::RealParameter("vilAC",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(6,ParameterUtility::RealParameter("vDD",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(7,ParameterUtility::RealParameter("vSS",range));
	range = new Range(RangeUtility::GTE(N_INF),RangeUtility::LTE(P_INF));
	defineParameter(8,ParameterUtility::RealParameter("vMeas",range));

	defineMeasurement(new DDR2_DataTimingDQ_MD);
	defineMeasurement(new DDR2_DataTimingDQS_MD);
	defineMeasurement(new DDR2_CmdAddTimingCmdAdd_MD);
	defineMeasurement(new DDR2_CmdAddTimingClk_MD);
	defineMeasurement(new DDR2_ElectricalDQ_MD);
	defineMeasurement(new DDR2_ElectricalDQS_MD);
	defineMeasurement(new DDR2_ElectricalCmdAdd_MD);
	defineMeasurement(new DDR2_ElectricalClock_MD);
	defineMeasurement(new DDR2_DQ_DQS_Skew_MD);
	defineMeasurement(new DDR2_CmdAdd_Clock_Skew_MD);
	defineMeasurement(new DDR2_DQS_Clock_Skew_MD);

	defineSignalType("DQ");
	defineSignalType("DQ_Reference");
	defineSignalType("DQS");
	defineSignalType("DQS_Reference");
	defineSignalType("CmdAdd");
	defineSignalType("CmdAdd_Reference");
	defineSignalType("Clock");
	defineSignalType("Clock_Reference");
}
DDR2_PD::~DDR2_PD(){}

Package* DDR2_PD::createInstance(){
	Package* package = new DDR2_Package;
	package->setDescriptor(this);
	return package;
}


