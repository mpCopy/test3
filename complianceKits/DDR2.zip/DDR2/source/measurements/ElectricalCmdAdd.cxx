// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "ElectricalCmdAdd.h"
#include <math.h>

ElectricalCmdAdd::ElectricalCmdAdd(){}

ElectricalCmdAdd::~ElectricalCmdAdd(){}

/// Define functions of class ElectricalCmdAdd
/// These functions are for electrical measurements on Command/Address signals.

void ElectricalCmdAdd::initialize(){
    //package->status("DDR2 ElectricalCmdAdd Initialize");
    setEnableEvaluation(true); //evaluation is enabled.
    evalState = true;
    caShootMode = false;
    caNoiseMarginHighMode = false;
    caNoiseMarginLowMode = false;
    lastcaSlope = 0;
    caSlope = 0;

    // initial clearup of vectors
    caOvershootPeak.clear();
    caUndershootPeak.clear();
    caOvershootArea.clear();
    caUndershootArea.clear();
    caNoiseMarginHigh.clear();
    caNoiseMarginLow.clear();

    caShootWaveform.clear();
    caShootTime.clear();

    // set up triggers with specific threshold voltages    
    caFallvDDTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vDD);
    caFallvihDCTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vihDC);
    caFallvRefTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vRef);
    caFallvilDCTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vilDC);
    caFallvSSTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vSS);

    caRisevSSTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vSS);
    caRisevilDCTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vilDC);
    caRisevRefTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vRef);
    caRisevihDCTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vihDC);
    caRisevDDTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vDD);

    // initialize the saved trigger times
    firstcaFallvRef = -1;
    lastcaFallvRef = -1;
    firstcaFallvilDC = -1;
    lastcaFallvilDC = -1;
    firstcaRisevilDC = -1;
    firstcaRisevRef = -1;
    lastcaRisevRef = -1;
    firstcaRisevihDC = -1;
    lastcaRisevihDC = -1;
    firstcaFallvihDC = -1;

    caShootPeakTemp = 0;
    caShootAreaTemp = 0;
    caNoiseMarginHighTemp = 0;
    caNoiseMarginLowTemp = 0;
    lastca = 0;
    ca = 0;
    UI = 1e-6/package->parameter.SpeedGrade; // one UI
}

void ElectricalCmdAdd::event(Trigger* trigger){
    if(trigger == caFallvRefTrigger){
        if(((firstcaFallvRef < 0) || ((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) >= 0.5*UI))) && // the very first falling edge or not the noise at current edge
           ((firstcaRisevRef < 0) || ((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) >= 0.5*UI)))) { // not the noise at any rising edge
            firstcaFallvRef = trigger->time();
        }
        if((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) < 0.5*UI)) { // close to or is the first crossing 
            lastcaFallvRef = trigger->time();
        }
    }
    if((trigger == caFallvilDCTrigger) && (firstcaFallvRef > 0)){
        //entering logic low
        if((trigger->time()-firstcaFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastcaFallvilDC = trigger->time();
            //prepare for NoiseMarginLow after the last one
            caNoiseMarginLowMode = true;
            caNoiseMarginLowTemp = -1e3; //initialized to a large number
            lastcaSlope = -1; //falling edge
            lastca = package->parameter.vilDC;
            if((firstcaFallvilDC < 0) || ((firstcaFallvilDC > 0) && ((trigger->time()-firstcaFallvilDC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstcaFallvilDC > 0) && ((trigger->time()-firstcaFallvilDC) < 0.5*UI) && (firstcaFallvilDC < lastcaFallvRef))){ // noise but there is caFallvRef after firstcaFallvilDC (noise > vRef-vilDC) -> reset firstcaFallvilDC 
                firstcaFallvilDC = trigger->time(); //only use for first one checking.
                //prepare for undershoot after the first one since undershoot can happend before the last one
                caShootWaveform.clear();
                caShootTime.clear();
            }
        }
    }
    if((trigger == caFallvSSTrigger) && (firstcaFallvRef > 0)){
        caShootMode = true;
        caShootWaveform.append(package->parameter.vSS);
        caShootTime.append(trigger->time());
    }
    if((trigger == caRisevSSTrigger) && (firstcaFallvRef > 0)){
        caShootMode = false;
        caShootWaveform.append(package->parameter.vSS);
        caShootTime.append(trigger->time());
    }
    if((trigger == caRisevilDCTrigger) && (firstcaFallvRef > 0)){
        //leaving logic low
        if(((trigger->time()-firstcaFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstcaRisevRef < 0) || ((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) > 0.5*UI)))){ // not the noise after firstcaRiseRef (in a logic high cycle)
            if((firstcaRisevilDC < 0) || ((firstcaRisevilDC > 0) && ((trigger->time()-firstcaRisevilDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstcaRisevilDC = trigger->time();
                //calculate and save caUndershootPeak and Area
                if(caShootWaveform.size() > 0){
                    Container<double>* waveformLink = caShootWaveform.head();
                    Container<double>* timeLink = caShootTime.head();
                    double temp0=0.0, tempt0=0.0; //previous values
                    double temp1=0.0, tempt1=0.0; //current values
                    bool firstPoint=true;
                    while(waveformLink){
                        if(firstPoint){
                            temp1 = package->parameter.vSS - waveformLink->data();
                            tempt1 = timeLink->data();
                            caShootPeakTemp = temp1;
                            caShootAreaTemp = 0.0;
                            firstPoint = false;
                        }
                        else{
                            temp0 = temp1;
                            tempt0 = tempt1;
                            temp1 = package->parameter.vSS - waveformLink->data();
                            tempt1 = timeLink->data();
                            if(temp1 > caShootPeakTemp) caShootPeakTemp = temp1;
                            caShootAreaTemp += (temp0+temp1)*(tempt1-tempt0);
                        }
                        waveformLink = waveformLink->next();
                        timeLink = timeLink->next();
                    }
                }
                else{
                    caShootPeakTemp = 0.0;
                    caShootAreaTemp = 0.0;
                }
                caUndershootPeak.append(caShootPeakTemp);
                caUndershootArea.append(caShootAreaTemp/2*1e9);
                //save caNoiseMarginLow
                caNoiseMarginLowMode = false;
                if((lastcaSlope != 1) && (caNoiseMarginLowTemp < lastca))
                    caNoiseMarginLowTemp = lastca;
                caNoiseMarginLow.append(package->parameter.vilDC - caNoiseMarginLowTemp);
            }
        }
    }
    if(trigger == caRisevRefTrigger){
        if(((firstcaRisevRef < 0) || ((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) >= 0.5*UI))) && // the very first Rising edge or not the noise at current edge
           ((firstcaFallvRef < 0) || ((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) >= 0.5*UI)))) { // not the noise at any falling edge
            firstcaRisevRef = trigger->time();
        }
        if((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) < 0.5*UI)) { // close to or is the first crossing 
            lastcaRisevRef = trigger->time();
        }
    }
    if((trigger == caRisevihDCTrigger) && (firstcaRisevRef > 0)){
        //entering logic high
        if((trigger->time()-firstcaRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastcaRisevihDC = trigger->time();
            //prepare for caNoiseMarginHigh after the last one
            caNoiseMarginHighMode = true;
            caNoiseMarginHighTemp = 1e3; //initialized to a large number
            lastcaSlope = 1; //rising edge
            lastca = package->parameter.vihDC;
            if((firstcaRisevihDC < 0) || ((firstcaRisevihDC > 0) && ((trigger->time()-firstcaRisevihDC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstcaRisevihDC > 0) && ((trigger->time()-firstcaRisevihDC) < 0.5*UI) && (firstcaRisevihDC < lastcaRisevRef))){ // noise but there is caRisevRef after firstcaRisevihDC (noise > vihDC-vRef) -> reset firstcaRisevihDC
                firstcaRisevihDC = trigger->time();
                //prepare for overshoot after the first one since overshoot can happend before the last one
                caShootWaveform.clear();
                caShootTime.clear();
            }
        }
    }
    if((trigger == caRisevDDTrigger) && (firstcaRisevRef > 0)){
        caShootMode = true;
        caShootWaveform.append(package->parameter.vDD);
        caShootTime.append(trigger->time());
    }
    if((trigger == caFallvDDTrigger) && (firstcaRisevRef > 0)){
        caShootMode = false;
        caShootWaveform.append(package->parameter.vDD);
        caShootTime.append(trigger->time());
    }
    if((trigger == caFallvihDCTrigger) && (firstcaRisevRef > 0)){
        //leaving logic high
        if(((trigger->time()-firstcaRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstcaFallvRef < 0) || ((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) > 0.5*UI)))){ // not the noise after firstcaFallRef (in a logic low cycle)
            if((firstcaFallvihDC < 0) || ((firstcaFallvihDC > 0) && ((trigger->time()-firstcaFallvihDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstcaFallvihDC = trigger->time();
                //calculate and save caOvershootPeak and Area
                if(caShootWaveform.size() > 0){
                    Container<double>* waveformLink = caShootWaveform.head();
                    Container<double>* timeLink = caShootTime.head();
                    double temp0=0.0, tempt0=0.0; //previous values
                    double temp1=0.0, tempt1=0.0; //current values
                    bool firstPoint=true;
                    while(waveformLink){
                        if(firstPoint){
                            temp1  = waveformLink->data() - package->parameter.vDD;
                            tempt1 = timeLink->data();
                            caShootPeakTemp = temp1;
                            caShootAreaTemp = 0.0;
                            firstPoint = false;
                        }
                        else{
                            temp0 = temp1;
                            tempt0 = tempt1;
                            temp1  = waveformLink->data() - package->parameter.vDD;
                            tempt1 = timeLink->data();
                            if(temp1 > caShootPeakTemp) 
                                caShootPeakTemp = temp1;
                            caShootAreaTemp += (temp0+temp1)*(tempt1-tempt0);
                        }
                        waveformLink = waveformLink->next();
                        timeLink = timeLink->next();
                    }
                }
                else{
                    caShootPeakTemp = 0.0;
                    caShootAreaTemp = 0.0;
                }
                caOvershootPeak.append(caShootPeakTemp);
                caOvershootArea.append(caShootAreaTemp/2*1e9);
                //save caNoiseMarginHigh
                caNoiseMarginHighMode = false;
                if((lastcaSlope != -1) && (caNoiseMarginHighTemp > lastca))
                    caNoiseMarginLowTemp = lastca;
                caNoiseMarginHigh.append(caNoiseMarginHighTemp - package->parameter.vihDC);
            }
        }
    }   
}

void ElectricalCmdAdd::evaluate(double time){
    if(caShootMode){
        caShootWaveform.append(signal.CmdAdd.p-signal.CmdAdd.n);
        caShootTime.append(time);
    }
    if(caNoiseMarginHighMode){
        ca = signal.CmdAdd.p-signal.CmdAdd.n;
        if(time == lastcaRisevihDC){ //the same time point as caRisevihDC trigger
            caSlope = lastcaSlope;
            ca = lastca;
        }
        else if( ca > lastca)
            caSlope = 1;
        else if(ca < lastca)
            caSlope = -1;        
        else // ca == lastca
            caSlope = 0;
        if((caSlope != lastcaSlope) && (caNoiseMarginHighTemp > lastca))
            caNoiseMarginHighTemp = lastca;
        lastca = ca;
        lastcaSlope = caSlope;
    }
    if(caNoiseMarginLowMode){
        ca = signal.CmdAdd.p-signal.CmdAdd.n;
        if(time == lastcaFallvilDC){ //the same time point as caFallvilDC trigger
            caSlope = lastcaSlope;
            ca = lastca;
        }
        else if( ca > lastca)
            caSlope = 1;
        else if(ca < lastca)
            caSlope = -1;        
        else // ca == lastca
            caSlope = 0;
        if((caSlope != lastcaSlope) && (caNoiseMarginLowTemp < lastca))
            caNoiseMarginLowTemp = lastca;
        lastca = ca;
        lastcaSlope = caSlope;
    }
}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void ElectricalCmdAdd::finalize(){
    PackageSignal* packageSignal = (PackageSignal*)signal.CmdAdd.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("CmdAddOvershootPeak", "Index", generateName(buffer,"CmdAddOvershootPeak",nodeName), caOvershootPeak);
    save("CmdAddUndershootPeak", "Index", generateName(buffer,"CmdAddUndershootPeak",nodeName), caUndershootPeak);
    save("CmdAddOvershootArea", "Index", generateName(buffer,"CmdAddOvershootArea",nodeName), caOvershootArea);
    save("CmdAddUndershootArea", "Index", generateName(buffer,"CmdAddUndershootArea",nodeName), caUndershootArea);
    save("CmdAddNoiseMarginLow", "Index", generateName(buffer,"CmdAddNoiseMarginLow",nodeName), caNoiseMarginLow);
    save("CmdAddNoiseMarginHigh", "Index", generateName(buffer,"CmdAddNoiseMarginHigh",nodeName), caNoiseMarginHigh);
}

void ElectricalCmdAdd::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.CmdAdd.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    package->check(this,"CmdAddOvershootPeak", caOvershootPeak, generateName(buffer,"CmdAddOvershootPeak",nodeName));
    package->check(this,"CmdAddUndershootPeak", caUndershootPeak, generateName(buffer,"CmdAddUndershootPeak",nodeName));
    package->check(this,"CmdAddOvershootArea", caOvershootArea, generateName(buffer,"CmdAddOvershootArea",nodeName));
    package->check(this,"CmdAddUndershootArea", caUndershootArea, generateName(buffer,"CmdAddUndershootArea",nodeName));
    package->check(this,"CmdAddNoiseMarginLow", caNoiseMarginLow, generateName(buffer,"CmdAddNoiseMarginLow",nodeName));
    package->check(this,"CmdAddNoiseMarginHigh", caNoiseMarginHigh, generateName(buffer,"CmdAddNoiseMarginHigh",nodeName));
}
