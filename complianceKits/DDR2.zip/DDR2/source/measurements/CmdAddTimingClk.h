// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class CmdAddTimingClk.
/// This class is for Command/Address timing measurements on Clock singal.

class CmdAddTimingClk:public Measurement{
public:
	CmdAddTimingClk();
	virtual ~CmdAddTimingClk();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__CmdAddTimingClk"

        // vectors to save measurement results
        DoubleVector clkFlightTimeFall;
        DoubleVector clkFlightTimeRise;
        DoubleVector clkSlewRFall;
        DoubleVector clkSlewRRise;

protected:
        // queues to save Clock_Reference trigger times
        Queue<double> clkRefFallZeroTime;
        Queue<double> clkRefRiseZeroTime;

        // Clock triggers at threshold voltages
        Trigger* clkFallVihTrigger;
        Trigger* clkFallZeroTrigger;
        Trigger* clkFallVilTrigger;
        Trigger* clkRiseVilTrigger;
        Trigger* clkRiseZeroTrigger;
        Trigger* clkRiseVihTrigger;

        // Clock_Reference triggers
        Trigger* clkRefFallZeroTrigger;
        Trigger* clkRefRiseZeroTrigger;

        bool evalState;
        bool qPop;

        // variables to save trigger times
        double lastclkRefFallZero;
        double lastclkRefRiseZero;
        double lastclkFallVih;
        double lastclkRiseVil;
        double fallVih;
        double fallVil;
        double riseVil;
        double riseVih;
};
