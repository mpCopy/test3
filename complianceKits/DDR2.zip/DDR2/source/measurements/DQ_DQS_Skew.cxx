// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "DQ_DQS_Skew.h"
#include "DataTimingDQ.h"
#include "DataTimingDQS.h"
#include <math.h>

DQ_DQS_Skew::DQ_DQS_Skew(){}

DQ_DQS_Skew::~DQ_DQS_Skew(){}

/// Define functions of class DQ_DQS_Skew
/// These functions are for skews calculation between DQ and DQS singals.

void DQ_DQS_Skew::initialize(){
    // check if single ended.
    singleEnded = false;
    PackageSignal* packageSignal = (PackageSignal*)signal.DQS.packageSignal;
    const char* nodeNameDQSn =  this->package->getNodeName(packageSignal->negative);
    if(strcmp( nodeNameDQSn, "0" ) == 0)
        singleEnded = true;

    // initial clearup of vectors
    dqSkewSetupFall.clear();
    dqSkewSetupRise.clear();
    dqSkewHoldFall.clear();
    dqSkewHoldRise.clear();
    dqSkewSetupFallVref.clear();
    dqSkewSetupRiseVref.clear();
    dqSkewHoldFallVref.clear();
    dqSkewHoldRiseVref.clear();
    dqReadSkewSetupFall.clear();
    dqReadSkewSetupRise.clear();
    dqReadSkewHoldFall.clear();
    dqReadSkewHoldRise.clear();
}
void DQ_DQS_Skew::event(Trigger* trigger){}

void DQ_DQS_Skew::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void DQ_DQS_Skew::finalize(){
    DataTimingDQ*  dqDataTiming  = (DataTimingDQ*)this->package->getMeasurement("DataTimingDQ",signal.DQ);
    DataTimingDQS* dqsDataTiming = (DataTimingDQS*)this->package->getMeasurement("DataTimingDQS",signal.DQS);
    if(!(dqDataTiming) || !(dqsDataTiming)){
        package->error("DQ_DQS_Skew requires both DataTimingDQ and DataTimingDQS selected.");
        return;
    }

    double tempValue, dqsFlightTimeMax, dqsFlightTimeMin, dqsSlewRMax;
    int index, numSkip=3;

    // Get max dqsSlewR from dqsSlewRFall and dqsSkewRRise
    Container<double>* dqsSlewRFall = dqsDataTiming->dqsSlewRFall.head();
    Container<double>* dqsSlewRRise = dqsDataTiming->dqsSlewRRise.head();
    if(!(dqsSlewRFall) || !(dqsSlewRRise)){
        package->error("No slew rate data from DataTimingDQS. Check DQS probe connection.");
        return;
    }
    for(index=0; index < numSkip; index++) {
        if(dqsSlewRFall->next())
            dqsSlewRFall = dqsSlewRFall->next();
        if(dqsSlewRRise->next())
            dqsSlewRRise = dqsSlewRRise->next();
    }
    dqsSlewRMax = dqsSlewRFall->data();
    while(dqsSlewRFall->next()){
        dqsSlewRFall = dqsSlewRFall->next();
        tempValue = dqsSlewRFall->data();
        if(dqsSlewRMax < tempValue)
            dqsSlewRMax = tempValue;
    }
    while(dqsSlewRRise->next()){
        dqsSlewRRise = dqsSlewRRise->next();
        tempValue = dqsSlewRRise->data();
        if(dqsSlewRMax < tempValue)
            dqsSlewRMax = tempValue;
    }

    // Get max and min dqsFlightTime from dqsFlightTimeFallVref0 and dqsFlightTimeRiseVref0
    Container<double>* dqsFlightTimeFallVref0 = dqsDataTiming->dqsFlightTimeFallVref0.head();
    Container<double>* dqsFlightTimeRiseVref0 = dqsDataTiming->dqsFlightTimeRiseVref0.head();
    if(!(dqsFlightTimeFallVref0) || !(dqsFlightTimeRiseVref0)){
        package->error("No flight time data from DataTimingDQS. Check DQS probe connection.");
        return;
    }
    for(index=0; index < numSkip; index++) {
        if(dqsFlightTimeFallVref0->next())
            dqsFlightTimeFallVref0 = dqsFlightTimeFallVref0->next();
        if(dqsFlightTimeRiseVref0->next())
            dqsFlightTimeRiseVref0 = dqsFlightTimeRiseVref0->next();
    }
    dqsFlightTimeMax = dqsFlightTimeFallVref0->data();
    dqsFlightTimeMin = dqsFlightTimeFallVref0->data();
    while(dqsFlightTimeFallVref0->next()){
        dqsFlightTimeFallVref0 = dqsFlightTimeFallVref0->next();
        tempValue = dqsFlightTimeFallVref0->data();
        if(dqsFlightTimeMax < tempValue)
            dqsFlightTimeMax = tempValue;
        if(dqsFlightTimeMin > tempValue)
            dqsFlightTimeMin = tempValue;
    }
    while(dqsFlightTimeRiseVref0->next()){
        dqsFlightTimeRiseVref0 = dqsFlightTimeRiseVref0->next();
        tempValue = dqsFlightTimeRiseVref0->data();
        if(dqsFlightTimeMax < tempValue)
            dqsFlightTimeMax = tempValue;
        if(dqsFlightTimeMin > tempValue)
            dqsFlightTimeMin = tempValue;
    }

    //read-mode skews
    Container<double>* dqReadFlightTimeFallMin = dqDataTiming->dqReadFlightTimeFallMin.head();
    Container<double>* dqReadFlightTimeFallMax = dqDataTiming->dqReadFlightTimeFallMax.head();
    Container<double>* dqReadFlightTimeRiseMin = dqDataTiming->dqReadFlightTimeRiseMin.head();
    Container<double>* dqReadFlightTimeRiseMax = dqDataTiming->dqReadFlightTimeRiseMax.head();
    while(dqReadFlightTimeFallMax){
        dqReadSkewSetupFall.append(dqReadFlightTimeFallMax->data() - dqsFlightTimeMin);
        dqReadFlightTimeFallMax = dqReadFlightTimeFallMax->next();
    }
    while(dqReadFlightTimeRiseMax){
        dqReadSkewSetupRise.append(dqReadFlightTimeRiseMax->data() - dqsFlightTimeMin);
        dqReadFlightTimeRiseMax = dqReadFlightTimeRiseMax->next();
    }
    while(dqReadFlightTimeFallMin){
        dqReadSkewHoldFall.append(dqsFlightTimeMax - dqReadFlightTimeFallMin->data());
        dqReadFlightTimeFallMin = dqReadFlightTimeFallMin->next();
    }
    while(dqReadFlightTimeRiseMin){
        dqReadSkewHoldRise.append(dqsFlightTimeMax - dqReadFlightTimeRiseMin->data());
        dqReadFlightTimeRiseMin = dqReadFlightTimeRiseMin->next();
    }

    // calculate derated skews
    CSVData* Data_Derating;
    CSVMatrix* Derating;
    bool derateAvil;
    Container<double>* dqFlightTimeSetupFall = dqDataTiming->dqFlightTimeSetupFall.head();
    Container<double>* dqFlightTimeSetupRise = dqDataTiming->dqFlightTimeSetupRise.head();
    Container<double>* dqFlightTimeHoldFall = dqDataTiming->dqFlightTimeHoldFall.head();
    Container<double>* dqFlightTimeHoldRise = dqDataTiming->dqFlightTimeHoldRise.head();
    Container<double>* dqSlewRSetupFall = dqDataTiming->dqSlewRSetupFall.head();
    Container<double>* dqSlewRSetupRise = dqDataTiming->dqSlewRSetupRise.head();
    Container<double>* dqSlewRHoldFall = dqDataTiming->dqSlewRHoldFall.head();
    Container<double>* dqSlewRHoldRise = dqDataTiming->dqSlewRHoldRise.head();

    if(!singleEnded){
        //setup skew with differential data strobe
        derateAvil = true;
        if((package->parameter.SpeedGrade == 400) || (package->parameter.SpeedGrade == 533))
            Data_Derating = CSVData::parse(this->package,"DDR2_derating_table_DQ_Setup_400_533_Diff.csv");
        else if((package->parameter.SpeedGrade == 677) || (package->parameter.SpeedGrade == 800) || (package->parameter.SpeedGrade == 1066))
            Data_Derating = CSVData::parse(this->package,"DDR2_derating_table_DQ_Setup_677_800_1066_Diff.csv");
        else
            derateAvil = false;
        if(CSVData::errorOccured()){
            package->error(CSVData::error());
            derateAvil = false;
        }
        if(derateAvil)
            Derating = static_cast<CSVMatrix*>(Data_Derating);
        while(dqFlightTimeSetupFall && dqSlewRSetupFall){
            tempValue = dqFlightTimeSetupFall->data() - dqsFlightTimeMin;
            if(derateAvil)
                tempValue +=  Derating->lookup(dqsSlewRMax, dqSlewRSetupFall->data());
            dqSkewSetupFall.append(tempValue);
            dqFlightTimeSetupFall = dqFlightTimeSetupFall->next();
            dqSlewRSetupFall = dqSlewRSetupFall->next();
        }
        while(dqFlightTimeSetupRise && dqSlewRSetupRise){
            tempValue = dqFlightTimeSetupRise->data() - dqsFlightTimeMin;
            if(derateAvil)
                tempValue += Derating->lookup(dqsSlewRMax, dqSlewRSetupRise->data());
            dqSkewSetupRise.append(tempValue);
            dqFlightTimeSetupRise = dqFlightTimeSetupRise->next();
            dqSlewRSetupRise = dqSlewRSetupRise->next();
        }

        //hold skew with differential data strobe
        derateAvil = true;
        if((package->parameter.SpeedGrade == 400) || (package->parameter.SpeedGrade == 533) || 
           (package->parameter.SpeedGrade == 677) || (package->parameter.SpeedGrade == 800) || (package->parameter.SpeedGrade == 1066))
            Data_Derating = CSVData::parse(this->package,"DDR2_derating_table_DQ_Hold_Diff.csv");
        else
            derateAvil = false;
        if(CSVData::errorOccured()){
            package->error(CSVData::error());
            derateAvil = false;
        }
        if(derateAvil)
            Derating = static_cast<CSVMatrix*>(Data_Derating);
        while(dqFlightTimeHoldFall && dqSlewRHoldFall){
            tempValue = dqsFlightTimeMax - dqFlightTimeHoldFall->data();
            if(derateAvil)
                tempValue += Derating->lookup(dqsSlewRMax, dqSlewRHoldFall->data());
            dqSkewHoldFall.append(tempValue);
            dqFlightTimeHoldFall = dqFlightTimeHoldFall->next();
            dqSlewRHoldFall = dqSlewRHoldFall->next();
        }
        while(dqFlightTimeHoldRise && dqSlewRHoldRise){
            tempValue = dqsFlightTimeMax - dqFlightTimeHoldRise->data();
            if(derateAvil)
                tempValue += Derating->lookup(dqsSlewRMax, dqSlewRHoldRise->data());
            dqSkewHoldRise.append(tempValue);
            dqFlightTimeHoldRise = dqFlightTimeHoldRise->next();
            dqSlewRHoldRise = dqSlewRHoldRise->next();
        }
    }
    else{ //single-ended DQS
        //prepare for the skews to dqs vref
        double dqsFlightTimeVrefMax=dqsFlightTimeMax , dqsFlightTimeVrefMin=dqsFlightTimeMin; //save Vref min and max
        bool derateVrefAvil;
        CSVMatrix* DeratingVref;

        // Get min dqsFlightTime from dqsFlightTimeFallVih and dqsFlightTimeRiseVil for setup skew
        Container<double>* dqsFlightTimeFallVih = dqsDataTiming->dqsFlightTimeFallVih.head();
        Container<double>* dqsFlightTimeRiseVil = dqsDataTiming->dqsFlightTimeRiseVil.head();
        if(!(dqsFlightTimeFallVih) || !(dqsFlightTimeRiseVil)){
            package->error("No flight time data from DataTimingDQS. Check DQS probe connection.");
            return;
        }
        for(index=0; index < numSkip; index++) {
            if(dqsFlightTimeFallVih->next())
                dqsFlightTimeFallVih = dqsFlightTimeFallVih->next();
            if(dqsFlightTimeRiseVil->next())
                dqsFlightTimeRiseVil = dqsFlightTimeRiseVil->next();
        }
        dqsFlightTimeMin = dqsFlightTimeFallVih->data();
        while(dqsFlightTimeFallVih->next()){
            dqsFlightTimeFallVih = dqsFlightTimeFallVih->next();
            tempValue = dqsFlightTimeFallVih->data();
            if(dqsFlightTimeMin > tempValue)
                dqsFlightTimeMin = tempValue;
        }
        while(dqsFlightTimeRiseVil->next()){
            dqsFlightTimeRiseVil = dqsFlightTimeRiseVil->next();
            tempValue = dqsFlightTimeRiseVil->data();
            if(dqsFlightTimeMin > tempValue)
                dqsFlightTimeMin = tempValue;
        }
        //load derating table for setup skew
        derateAvil = true;
        if((package->parameter.SpeedGrade == 400) || (package->parameter.SpeedGrade == 533))
            Data_Derating = CSVData::parse(this->package,"DDR2_derating_table_DQ_Setup_400_533_Single.csv");
        else
            derateAvil = false;
        if(CSVData::errorOccured()){
            package->error(CSVData::error());
            derateAvil = false;
        }
        if(derateAvil)
            Derating = static_cast<CSVMatrix*>(Data_Derating);
        //load derating table for setup skews to dqs vref
        derateVrefAvil = true;
        if((package->parameter.SpeedGrade == 400) || (package->parameter.SpeedGrade == 533) || 
            (package->parameter.SpeedGrade == 677) || (package->parameter.SpeedGrade == 800) || (package->parameter.SpeedGrade == 1066))
            Data_Derating = CSVData::parse(this->package,"DDR2_derating_table_DQ_Setup_Single_Vref.csv");
        else
            derateVrefAvil = false;
        if(CSVData::errorOccured()){
            package->error(CSVData::error());
            derateVrefAvil = false;
        }
        if(derateVrefAvil)
            DeratingVref = static_cast<CSVMatrix*>(Data_Derating);
        // calculate and save setup skews
        while(dqFlightTimeSetupFall && dqSlewRSetupFall){
            tempValue = dqFlightTimeSetupFall->data() - dqsFlightTimeMin;
            if(derateAvil)
                tempValue +=  Derating->lookup(dqsSlewRMax, dqSlewRSetupFall->data());
            dqSkewSetupFall.append(tempValue);
            tempValue = dqFlightTimeSetupFall->data() - dqsFlightTimeVrefMin;
            if(derateVrefAvil)
                tempValue +=  DeratingVref->lookup(dqsSlewRMax, dqSlewRSetupFall->data());
            dqSkewSetupFallVref.append(tempValue);
            dqFlightTimeSetupFall = dqFlightTimeSetupFall->next();
            dqSlewRSetupFall = dqSlewRSetupFall->next();
        }
        while(dqFlightTimeSetupRise && dqSlewRSetupRise){
            tempValue = dqFlightTimeSetupRise->data() - dqsFlightTimeMin;
            if(derateAvil)
                tempValue += Derating->lookup(dqsSlewRMax, dqSlewRSetupRise->data());
            dqSkewSetupRise.append(tempValue);
            tempValue = dqFlightTimeSetupRise->data() - dqsFlightTimeVrefMin;
            if(derateVrefAvil)
                tempValue += DeratingVref->lookup(dqsSlewRMax, dqSlewRSetupRise->data());
            dqSkewSetupRiseVref.append(tempValue);
            dqFlightTimeSetupRise = dqFlightTimeSetupRise->next();
            dqSlewRSetupRise = dqSlewRSetupRise->next();
        }

        // Get max dqsFlightTime from dqsFlightTimeFallVil and dqsFlightTimeRiseVih for hold skew
        Container<double>* dqsFlightTimeFallVil = dqsDataTiming->dqsFlightTimeFallVil.head();
        Container<double>* dqsFlightTimeRiseVih = dqsDataTiming->dqsFlightTimeRiseVih.head();
        if(!(dqsFlightTimeFallVil) || !(dqsFlightTimeRiseVih)){
            package->error("No flight time data from DataTimingDQS. Check DQS probe connection.");
            return;
        }
        for(index=0; index < numSkip; index++) {
            if(dqsFlightTimeFallVil->next())
                dqsFlightTimeFallVil = dqsFlightTimeFallVil->next();
            if(dqsFlightTimeRiseVih->next())
                dqsFlightTimeRiseVih = dqsFlightTimeRiseVih->next();
        }
        dqsFlightTimeMax = dqsFlightTimeFallVil->data();
        while(dqsFlightTimeFallVil->next()){
            dqsFlightTimeFallVil = dqsFlightTimeFallVil->next();
            tempValue = dqsFlightTimeFallVil->data();
            if(dqsFlightTimeMax < tempValue)
                dqsFlightTimeMax = tempValue;
        }
        while(dqsFlightTimeRiseVih->next()){
            dqsFlightTimeRiseVih = dqsFlightTimeRiseVih->next();
            tempValue = dqsFlightTimeRiseVih->data();
            if(dqsFlightTimeMax < tempValue)
                dqsFlightTimeMax = tempValue;
        }
        //load derating table for hold skew
        derateAvil = true;
        if((package->parameter.SpeedGrade == 400) || (package->parameter.SpeedGrade == 533))
            Data_Derating = CSVData::parse(this->package,"DDR2_derating_table_DQ_Hold_400_533_Single.csv");
        else
            derateAvil = false;
        if(CSVData::errorOccured()){
            package->error(CSVData::error());
            derateAvil = false;
        }
        if(derateAvil)
            Derating = static_cast<CSVMatrix*>(Data_Derating);
        //load derating table for hold skews to dqs vref
        derateVrefAvil = true;
        if((package->parameter.SpeedGrade == 400) || (package->parameter.SpeedGrade == 533) || 
            (package->parameter.SpeedGrade == 677) || (package->parameter.SpeedGrade == 800) || (package->parameter.SpeedGrade == 1066))
            Data_Derating = CSVData::parse(this->package,"DDR2_derating_table_DQ_Hold_Single_Vref.csv");
        else
            derateVrefAvil = false;
        if(CSVData::errorOccured()){
            package->error(CSVData::error());
            derateVrefAvil = false;
        }
        if(derateVrefAvil)
            DeratingVref = static_cast<CSVMatrix*>(Data_Derating);
        // calculate and save hold skews
        while(dqFlightTimeHoldFall && dqSlewRHoldFall){
            tempValue = dqsFlightTimeMax - dqFlightTimeHoldFall->data();
            if(derateAvil)
                tempValue +=  Derating->lookup(dqsSlewRMax, dqSlewRHoldFall->data());
            dqSkewHoldFall.append(tempValue);
            tempValue = dqsFlightTimeVrefMax - dqFlightTimeHoldFall->data();
            if(derateVrefAvil)
                tempValue +=  DeratingVref->lookup(dqsSlewRMax, dqSlewRHoldFall->data());
            dqSkewHoldFallVref.append(tempValue);
            dqFlightTimeHoldFall = dqFlightTimeHoldFall->next();
            dqSlewRHoldFall = dqSlewRHoldFall->next();
        }
        while(dqFlightTimeHoldRise && dqSlewRHoldRise){
            tempValue = dqsFlightTimeMax - dqFlightTimeHoldRise->data();
            if(derateAvil)
                tempValue += Derating->lookup(dqsSlewRMax, dqSlewRHoldRise->data());
            dqSkewHoldRise.append(tempValue);
            tempValue = dqsFlightTimeVrefMax - dqFlightTimeHoldRise->data();
            if(derateVrefAvil)
                tempValue += DeratingVref->lookup(dqsSlewRMax, dqSlewRHoldRise->data());
            dqSkewHoldRiseVref.append(tempValue);
            dqFlightTimeHoldRise = dqFlightTimeHoldRise->next();
            dqSlewRHoldRise = dqSlewRHoldRise->next();
        }
    }

    // save the results
    PackageSignal* packageSignal = (PackageSignal*)signal.DQ.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("DQ_DQSSkewSetupFall", "Index", generateName(buffer,"DQ_DQSSkewSetupFall",nodeName), dqSkewSetupFall);
    save("DQ_DQSSkewSetupRise", "Index", generateName(buffer,"DQ_DQSSkewSetupRise",nodeName), dqSkewSetupRise);
    save("DQ_DQSSkewHoldFall", "Index", generateName(buffer,"DQ_DQSSkewHoldFall",nodeName), dqSkewHoldFall);
    save("DQ_DQSSkewHoldRise", "Index", generateName(buffer,"DQ_DQSSkewHoldRise",nodeName), dqSkewHoldRise);
    if(singleEnded){
        save("DQ_DQSSkewSetupFallVref", "Index", generateName(buffer,"DQ_DQSSkewSetupFallVref",nodeName), dqSkewSetupFallVref);
        save("DQ_DQSSkewSetupRiseVref", "Index", generateName(buffer,"DQ_DQSSkewSetupRiseVref",nodeName), dqSkewSetupRiseVref);
        save("DQ_DQSSkewHoldFallVref", "Index", generateName(buffer,"DQ_DQSSkewHoldFallVref",nodeName), dqSkewHoldFallVref);
        save("DQ_DQSSkewHoldRiseVref", "Index", generateName(buffer,"DQ_DQSSkewHoldRiseVref",nodeName), dqSkewHoldRiseVref);
    }
    save("DQ_DQSSkewReadSetupFall", "Index", generateName(buffer,"DQ_DQSSkewReadSetupFall",nodeName), dqReadSkewSetupFall);
    save("DQ_DQSSkewReadSetupRise", "Index", generateName(buffer,"DQ_DQSSkewReadSetupRise",nodeName), dqReadSkewSetupRise);
    save("DQ_DQSSkewReadHoldFall", "Index", generateName(buffer,"DQ_DQSSkewReadHoldFall",nodeName), dqReadSkewHoldFall);
    save("DQ_DQSSkewReadHoldRise", "Index", generateName(buffer,"DQ_DQSSkewReadHoldRise",nodeName), dqReadSkewHoldRise);
}

void DQ_DQS_Skew::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQ.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    package->check(this,"DQ_DQSSkewSetupFall", dqSkewSetupFall, generateName(buffer,"DQ_DQSSkewSetupFall",nodeName));
    package->check(this,"DQ_DQSSkewSetupRise", dqSkewSetupRise, generateName(buffer,"DQ_DQSSkewSetupRise",nodeName));
    package->check(this,"DQ_DQSSkewHoldFall", dqSkewHoldFall, generateName(buffer,"DQ_DQSSkewHoldFall",nodeName));
    package->check(this,"DQ_DQSSkewHoldRise", dqSkewHoldRise, generateName(buffer,"DQ_DQSSkewHoldRise",nodeName));
    if(singleEnded){
        package->check(this,"DQ_DQSSkewSetupFallVref", dqSkewSetupFallVref, generateName(buffer,"DQ_DQSSkewSetupFallVref",nodeName));
        package->check(this,"DQ_DQSSkewSetupRiseVref", dqSkewSetupRiseVref, generateName(buffer,"DQ_DQSSkewSetupRiseVref",nodeName));
        package->check(this,"DQ_DQSSkewHoldFallVref", dqSkewHoldFallVref, generateName(buffer,"DQ_DQSSkewHoldFallVref",nodeName));
        package->check(this,"DQ_DQSSkewHoldRiseVref", dqSkewHoldRiseVref, generateName(buffer,"DQ_DQSSkewHoldRiseVref",nodeName));
    }
    package->check(this,"DQ_DQSSkewReadSetupFall", dqReadSkewSetupFall, generateName(buffer,"DQ_DQSSkewReadSetupFall",nodeName));
    package->check(this,"DQ_DQSSkewReadSetupRise", dqReadSkewSetupRise, generateName(buffer,"DQ_DQSSkewReadSetupRise",nodeName));
    package->check(this,"DQ_DQSSkewReadHoldFall", dqReadSkewHoldFall, generateName(buffer,"DQ_DQSSkewReadHoldFall",nodeName));
    package->check(this,"DQ_DQSSkewReadHoldRise", dqReadSkewHoldRise, generateName(buffer,"DQ_DQSSkewReadHoldRise",nodeName));
}
