// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class DataTimingDQS.
/// This class is for data timing measurements on DQS singal.

class DataTimingDQS:public Measurement{
public:
	DataTimingDQS();
	virtual ~DataTimingDQS();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__DataTimingDQS"

        // vectors to save measurement results
        DoubleVector dqsFlightTimeFallVih;
        DoubleVector dqsFlightTimeFallVref0;
        DoubleVector dqsFlightTimeFallVil;
        DoubleVector dqsFlightTimeRiseVil;
        DoubleVector dqsFlightTimeRiseVref0;
        DoubleVector dqsFlightTimeRiseVih;
        DoubleVector dqsSlewRFall;
        DoubleVector dqsSlewRRise;

protected:
        // queues to save DQS_Reference trigger times
        Queue<double> dqsRefFallVmeas0Time;
        Queue<double> dqsRefRiseVmeas0Time;

        // DQS triggers at threshold voltages
        Trigger* dqsFallVihTrigger;
        Trigger* dqsFallVref0Trigger;
        Trigger* dqsFallVilTrigger;
        Trigger* dqsRiseVilTrigger;
        Trigger* dqsRiseVref0Trigger;
        Trigger* dqsRiseVihTrigger;

        // DQS_Reference triggers
        Trigger* dqsRefFallVmeas0Trigger;
        Trigger* dqsRefRiseVmeas0Trigger;

        bool evalState;
        bool qPop;
        bool singleEnded;

        // variables to save trigger times
        double lastdqsRefFallVmeas0;
        double lastdqsRefRiseVmeas0;
        double lastdqsFallVih;
        double lastdqsRiseVil;
        double fallVih;
        double fallVil;
        double riseVil;
        double riseVih;
};
