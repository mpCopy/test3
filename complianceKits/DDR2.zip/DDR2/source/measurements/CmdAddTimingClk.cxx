// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "CmdAddTimingClk.h"
#include <math.h>

CmdAddTimingClk::CmdAddTimingClk(){}

CmdAddTimingClk::~CmdAddTimingClk(){}

/// Define functions of class CmdAddTimingClk
/// These functions are for Command/Address timing measurements on Clock signal.

void CmdAddTimingClk::initialize(){
    //package->status("DDR2 CmdAddTimingClk Initialize");
    setEnableEvaluation(false);
    evalState = false;
    qPop = false;

    // initial cleanup of vectors
    clkFlightTimeFall.clear();
    clkFlightTimeRise.clear();
    clkSlewRFall.clear();
    clkSlewRRise.clear();

    clkRefFallZeroTime.clear();
    clkRefRiseZeroTime.clear();

    // set up triggers with specific threshold voltages
    fallVih = 2*(package->parameter.vihDC-package->parameter.vRef);
    fallVil = 2*(package->parameter.vilAC-package->parameter.vRef);
    riseVil = 2*(package->parameter.vilDC-package->parameter.vRef);
    riseVih = 2*(package->parameter.vihAC-package->parameter.vRef);
    clkFallVihTrigger = addFallingEdgeTrigger(&signal.Clock, fallVih);
    clkFallZeroTrigger = addFallingEdgeTrigger(&signal.Clock, 0.0);
    clkFallVilTrigger = addFallingEdgeTrigger(&signal.Clock, fallVil);
    clkRiseVilTrigger = addRisingEdgeTrigger(&signal.Clock, riseVil);
    clkRiseZeroTrigger = addRisingEdgeTrigger(&signal.Clock, 0.0);
    clkRiseVihTrigger = addRisingEdgeTrigger(&signal.Clock, riseVih);

    clkRefFallZeroTrigger = addFallingEdgeTrigger(&signal.Clock_Reference, 0.0);
    clkRefRiseZeroTrigger = addRisingEdgeTrigger(&signal.Clock_Reference, 0.0);

    // initialize the saved trigger times
    lastclkRefFallZero = -1;
    lastclkRefRiseZero = -1;
    lastclkFallVih = -1;
    lastclkRiseVil = -1;
}

void CmdAddTimingClk::event(Trigger* trigger){
    if(trigger == clkRefFallZeroTrigger){
        clkRefFallZeroTime.push(trigger->time());
    }
    if(trigger == clkFallZeroTrigger){
        if(!clkRefFallZeroTime.empty()){
            qPop = clkRefFallZeroTime.pop(&lastclkRefFallZero);
            clkFlightTimeFall.append((trigger->time()-lastclkRefFallZero)*1e12);
        }
    }
    if(trigger == clkFallVilTrigger){
        if(lastclkFallVih > 0)
            clkSlewRFall.append((fallVih-fallVil)/(trigger->time()-lastclkFallVih)*1e-9);
    }
    if(trigger == clkRiseVilTrigger){
        lastclkRiseVil = trigger->time();
    }
    if(trigger == clkRefRiseZeroTrigger){
        clkRefRiseZeroTime.push(trigger->time());
    }
    if(trigger == clkRiseZeroTrigger){
        if(!clkRefRiseZeroTime.empty()){
            qPop = clkRefRiseZeroTime.pop(&lastclkRefRiseZero);
            clkFlightTimeRise.append((trigger->time()-lastclkRefRiseZero)*1e12);
        }
    }
    if(trigger == clkRiseVihTrigger){
        if(lastclkRiseVil > 0)
            clkSlewRRise.append((riseVih-riseVil)/(trigger->time()-lastclkRiseVil)*1e-9);
    }
    if(trigger == clkFallVihTrigger){
        lastclkFallVih = trigger->time();
    }
}

void CmdAddTimingClk::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void CmdAddTimingClk::finalize(){
    PackageSignal* packageSignal = (PackageSignal*)signal.Clock.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("ClockFlightTimeFall", "Index", generateName(buffer,"ClockFlightTimeFall",nodeName), clkFlightTimeFall);
    save("ClockFlightTimeRise", "Index", generateName(buffer,"ClockFlightTimeRise",nodeName), clkFlightTimeRise);
    save("ClockSlewRFall", "Index", generateName(buffer,"ClockSlewRFall",nodeName), clkSlewRFall);
    save("ClockSlewRRise", "Index", generateName(buffer,"ClockSlewRRise",nodeName), clkSlewRRise);
}

void CmdAddTimingClk::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.Clock.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    package->check(this,"ClockFlightTimeFall", clkFlightTimeFall, generateName(buffer,"ClockFlightTimeFall",nodeName));
    package->check(this,"ClockFlightTimeRise", clkFlightTimeRise, generateName(buffer,"ClockFlightTimeRise",nodeName));
    package->check(this,"ClockSlewRFall", clkSlewRFall, generateName(buffer,"ClockSlewRFall",nodeName));
    package->check(this,"ClockSlewRRise", clkSlewRRise, generateName(buffer,"ClockSlewRRise",nodeName));
}
