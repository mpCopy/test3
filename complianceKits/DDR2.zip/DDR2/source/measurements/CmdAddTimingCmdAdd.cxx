// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "CmdAddTimingCmdAdd.h"
#include <math.h>

CmdAddTimingCmdAdd::CmdAddTimingCmdAdd(){}

CmdAddTimingCmdAdd::~CmdAddTimingCmdAdd(){}

/// Define functions of class CmdAddTimingCmdAdd
/// These functions are for Command/Address timing measurements on Command/Address signals.

void CmdAddTimingCmdAdd::initialize(){
    //package->status("DDR2 CmdAddTimingCmdAdd Initialize");
    setEnableEvaluation(true); //evaluation is enabled.
    evalState = true;
    caSlewRMode = false;
    caFlightTimeSetupAvil = false;
    qPop = false;

    // initial clearup of vectors
    caFlightTimeSetupFall.clear();
    caFlightTimeSetupRise.clear();
    caFlightTimeHoldFall.clear();
    caFlightTimeHoldRise.clear();
    caSlewRSetupFall.clear();
    caSlewRSetupRise.clear();
    caSlewRHoldRise.clear();
    caSlewRHoldFall.clear();

    caSlewRWaveform.clear();
    caSlewRTime.clear();
    caRefFallvMeasTime.clear();
    caRefRisevMeasTime.clear();
    
    // set up triggers with specific threshold voltages
    caFallvihACTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vihAC);
    caFallvihDCTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vihDC);
    caFallvRefTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vRef);
    caFallvilDCTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vilDC);
    caFallvilACTrigger = addFallingEdgeTrigger(&signal.CmdAdd, package->parameter.vilAC);
    caRisevilACTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vilAC);
    caRisevilDCTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vilDC);
    caRisevRefTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vRef);
    caRisevihDCTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vihDC);
    caRisevihACTrigger = addRisingEdgeTrigger(&signal.CmdAdd, package->parameter.vihAC);

    caRefFallvMeasTrigger = addFallingEdgeTrigger(&signal.CmdAdd_Reference, package->parameter.vMeas);
    caRefRisevMeasTrigger = addRisingEdgeTrigger(&signal.CmdAdd_Reference, package->parameter.vMeas);

    // initialize the saved trigger times
    lastcaRefFallvMeas = -1;
    lastcaRefRisevMeas = -1;
    firstcaFallvRef = -1;
    lastcaFallvRef = -1;
    lastcaFallvilDC = -1;
    firstcaFallvilAC = -1;
    lastcaFallvilAC = -1;
    firstcaRisevilAC = -1;
    firstcaRisevilDC = -1;
    lastcaRisevilDC = -1;
    firstcaRisevRef = -1;
    lastcaRisevRef = -1;
    lastcaRisevihDC = -1;
    firstcaRisevihAC = -1;
    lastcaRisevihAC = -1;
    firstcaFallvihAC = -1;
    firstcaFallvihDC = -1;
    lastcaFallvihDC = -1;

    caFlightTimeSetupTemp = 0;
    caSlewRSetupTemp = 0;
    UI = 1e-6/package->parameter.SpeedGrade; // one UI
}

void CmdAddTimingCmdAdd::event(Trigger* trigger){
    if(trigger == caRefFallvMeasTrigger){
        caRefFallvMeasTime.push(trigger->time());
    }
    if(trigger == caFallvRefTrigger){
        if(((firstcaFallvRef < 0) || ((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) >= 0.5*UI))) && // the very first falling edge or not the noise at current edge
           ((firstcaRisevRef < 0) || ((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) >= 0.5*UI)))) { // not the noise at any rising edge
            firstcaFallvRef = trigger->time();
            if(!caRefFallvMeasTime.empty())
                qPop = caRefFallvMeasTime.pop(&lastcaRefFallvMeas);
            //calculate and save caFlightTimeHoldFall and caSlewRHoldFall (from lastcaFallvihDC to firstcaFallvRef)
            if ((lastcaRefFallvMeas > 0) && (firstcaFallvihDC > 0)){
                // Two conditions: caFlightTimeHoldFall will be valid.
                // last one: There was a full logic high already. Has enought data for caSlewRHoldFall.
                caSlewRMode = false; //finish data collection for caSlewRHoldFall
                caSlewRWaveform.append(package->parameter.vRef);
                caSlewRTime.append(firstcaFallvRef);
                caFlightTimeHoldFall.append((firstcaFallvihDC-lastcaRefFallvMeas)*1e12);
		Container<double>* waveformLink = caSlewRWaveform.head();
		Container<double>* timeLink = caSlewRTime.head();
		Container<double>* waveformLinkTail = caSlewRWaveform.tail();
		Container<double>* timeLinkTail = caSlewRTime.tail();
		double vfix = waveformLink->data(); //fix at the first point vihDC
                double tfix = timeLink->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLinkTail->data())/(tfix-timeLinkTail->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                caSlewRHoldFall.append(slewR*1e-9);
            }
        }
        if((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) < 0.5*UI)) { // close to or is the first crossing 
            lastcaFallvRef = trigger->time();
            //prepare for caSlewRSetupFall (from lastcaFallvRef to firstcaFallvilAC)
            //this has to be done for each lastcaFallvRef since we don't know which one is the last yet. 
            caSlewRMode = true;
            caSlewRWaveform.clear();
            caSlewRTime.clear();
            caSlewRWaveform.append(package->parameter.vRef);
            caSlewRTime.append(lastcaFallvRef);
        }
    }
    if((trigger == caFallvilDCTrigger) && (firstcaFallvRef > 0)){
        //entering logic low
        if((trigger->time()-firstcaFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastcaFallvilDC = trigger->time();
        }
    }
    if((trigger == caFallvilACTrigger) && (firstcaFallvRef > 0)){
        if((trigger->time()-firstcaFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastcaFallvilAC = trigger->time();
            //calculate and save caFlightTimeSetupFall (from caRefFallvMeas to lastcaFallvilAC) and caSlewRSetupFall (from lastcaFallVref to firstcaFallvilAC) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstcaRisevilAC.
            //calculate caFlightTimeSetupFall
            caFlightTimeSetupAvil = false;
            if(lastcaRefFallvMeas > 0){
                //condition: caFlightTimeSetupFall will be valid
                caFlightTimeSetupTemp = lastcaFallvilAC-lastcaRefFallvMeas;
                caFlightTimeSetupAvil = true;
            }
            if((firstcaFallvilAC < 0) || ((firstcaFallvilAC > 0) && ((trigger->time()-firstcaFallvilAC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstcaFallvilAC > 0) && ((trigger->time()-firstcaFallvilAC) < 0.5*UI) && (firstcaFallvilAC < lastcaFallvRef))){ // noise but there is caFallvRef after firstcaFallvilAC (noise > vRef-vilAC) -> reset firstcaFallvilAC 
                firstcaFallvilAC = trigger->time();
                //calculate caSlewRSetupFall (from lastcaFallVref to firstcaFallvilAC)
                caSlewRMode = false; //finish data collection for caSlewRSetupFall
                caSlewRWaveform.append(package->parameter.vilAC);
                caSlewRTime.append(firstcaFallvilAC);
                Container<double>* waveformLink = caSlewRWaveform.head();
                Container<double>* timeLink = caSlewRTime.head();
                Container<double>* waveformLinkTail = caSlewRWaveform.tail();
                Container<double>* timeLinkTail = caSlewRTime.tail();
                double vfix = waveformLinkTail->data();  //fix at the last point vilAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                caSlewRSetupTemp = slewR*1e-9;
            }
        }
    }
    if((trigger == caRisevilACTrigger) && (firstcaFallvRef > 0)){
        if(((trigger->time()-firstcaFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstcaRisevilAC < 0) || ((firstcaRisevilAC > 0) && ((trigger->time()-firstcaRisevilAC) > 0.5*UI)))){ // not the noise at current edge -> first one
            firstcaRisevilAC = trigger->time(); //no need for lastcaRisevilAC -> don't need to check for noise after firstcaRisevRef
            if(caFlightTimeSetupAvil){ 
                // save caFlightTimeSetupFall and caSlewRSetupFall
                caFlightTimeSetupFall.append(caFlightTimeSetupTemp*1e12);
                caSlewRSetupFall.append(caSlewRSetupTemp);
            }
        }
    }
    if((trigger == caRisevilDCTrigger) && (firstcaFallvRef > 0)){
        //leaving logic low
        if(((trigger->time()-firstcaFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstcaRisevRef < 0) || ((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) > 0.5*UI)))){ // not the noise after firstcaRiseRef (in a logic high cycle)
            lastcaRisevilDC = trigger->time();
            //prepare for caSlewRHoldRise from (lastcaRisevilDC to firstcaRisevRef)
            caSlewRMode = true;
            caSlewRWaveform.clear();
            caSlewRTime.clear();
            caSlewRWaveform.append(package->parameter.vilDC);
            caSlewRTime.append(lastcaRisevilDC);

            if((firstcaRisevilDC < 0) || ((firstcaRisevilDC > 0) && ((trigger->time()-firstcaRisevilDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstcaRisevilDC = trigger->time();
            }
        }
    }
    if(trigger == caRefRisevMeasTrigger){
        caRefRisevMeasTime.push(trigger->time());
    }
    if(trigger == caRisevRefTrigger){
        if(((firstcaRisevRef < 0) || ((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) >= 0.5*UI))) && // the very first Rising edge or not the noise at current edge
           ((firstcaFallvRef < 0) || ((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) >= 0.5*UI)))) { // not the noise at any falling edge
            firstcaRisevRef = trigger->time();
            if(!caRefRisevMeasTime.empty())
                qPop = caRefRisevMeasTime.pop(&lastcaRefRisevMeas);
            //calculate and save caFlightTimeHoldRise and caSlewRHoldRise (from lastcaRisevilDC to firstcaRisevRef)
            if((lastcaRefRisevMeas > 0) && (firstcaRisevilDC > 0)){
                caSlewRMode = false; //finish data collection for caSlewRHoldRise
                caSlewRWaveform.append(package->parameter.vRef);
                caSlewRTime.append(firstcaRisevRef);
                caFlightTimeHoldRise.append((firstcaRisevilDC-lastcaRefRisevMeas)*1e12);
                Container<double>* waveformLink = caSlewRWaveform.head();
                Container<double>* timeLink = caSlewRTime.head();
                Container<double>* waveformLinkTail = caSlewRWaveform.tail();
                Container<double>* timeLinkTail = caSlewRTime.tail();
                double vfix = waveformLink->data(); // fix at the first point vilDC 
                double tfix = timeLink->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLinkTail->data())/(tfix-timeLinkTail->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                caSlewRHoldRise.append(slewR*1e-9);
            }
        }
        if((firstcaRisevRef > 0) && ((trigger->time()-firstcaRisevRef) < 0.5*UI)) { // close to or is the first crossing 
            lastcaRisevRef = trigger->time();
            //prepare for caSlewRSetupRise (from lastcaRisevRef to firstcaRisevihAC)
            //this has to be done for each lastcaRisevRef since we don't know which one is the last yet.
            caSlewRMode = true;
            caSlewRWaveform.clear();
            caSlewRTime.clear();
            caSlewRWaveform.append(package->parameter.vRef);
            caSlewRTime.append(lastcaRisevRef);
        }
    }
    if((trigger == caRisevihDCTrigger) && (firstcaRisevRef > 0)){
        //entering logic high
        if((trigger->time()-firstcaRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastcaRisevihDC = trigger->time();
        }
    }
    if((trigger == caRisevihACTrigger) && (firstcaRisevRef > 0)){
        if((trigger->time()-firstcaRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastcaRisevihAC = trigger->time();
            //calculate and save caFlightTimeSetupRise (from caRefRisevMeas to lastcaRisevihAC) and caSlewRSetupRise (from lastcaRiseVref to firstcaRisevihAC) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstcaFallvihAC.
            //calculate caFlightTimeSetupRise
            caFlightTimeSetupAvil = false;
            if(lastcaRefRisevMeas > 0){
                //condition: caFlightTimeSetupRise will be valid
                caFlightTimeSetupTemp = lastcaRisevihAC-lastcaRefRisevMeas;
                caFlightTimeSetupAvil = true;
            }
            if((firstcaRisevihAC < 0) || ((firstcaRisevihAC > 0) && ((trigger->time()-firstcaRisevihAC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstcaRisevihAC > 0) && ((trigger->time()-firstcaRisevihAC) < 0.5*UI) && (firstcaRisevihAC < lastcaRisevRef))){ // noise but there is caRisevRef after firstcaRisevihAC (noise > vihAC-vRef) -> reset firstcaRisevihAC 
                firstcaRisevihAC = trigger->time();
                //calculate caSlewRSetupRise (from lastcaRiseVref to firstcaRisevihAC)
                caSlewRMode = false; //finish data collection for caSlewRSetupRise
                caSlewRWaveform.append(package->parameter.vihAC);
                caSlewRTime.append(firstcaRisevihAC);
                Container<double>* waveformLink = caSlewRWaveform.head();
                Container<double>* timeLink = caSlewRTime.head();
                Container<double>* waveformLinkTail = caSlewRWaveform.tail();
                Container<double>* timeLinkTail = caSlewRTime.tail();
                double vfix = waveformLinkTail->data(); //fix at the last point vihAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                caSlewRSetupTemp = slewR*1e-9;
            }
        }
    }
    if((trigger == caFallvihACTrigger) && (firstcaRisevRef > 0)){
        if(((trigger->time()-firstcaRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstcaFallvihAC < 0) || ((firstcaFallvihAC > 0) && ((trigger->time()-firstcaFallvihAC) > 0.5*UI)))){ // not the noise at current edge -> first one
               firstcaFallvihAC = trigger->time(); //no need for lastcaFallvihAC -> don't need to check for noise after firstcaFallvRef
               if(caFlightTimeSetupAvil){ 
                   // save caFlightTimeSetupRise and caSlewRSetupRise
                   caFlightTimeSetupRise.append(caFlightTimeSetupTemp*1e12);
                   caSlewRSetupRise.append(caSlewRSetupTemp);
               }
        }
    }
    if((trigger == caFallvihDCTrigger) && (firstcaRisevRef > 0)){
        //leaving logic high
        if(((trigger->time()-firstcaRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstcaFallvRef < 0) || ((firstcaFallvRef > 0) && ((trigger->time()-firstcaFallvRef) > 0.5*UI)))){ // not the noise after firstcaFallRef (in a logic low cycle)
            lastcaFallvihDC = trigger->time();
            //prepare for caSlewRHoldFall from (lastcaFallvihDC to firstcaFallvRef)
            caSlewRMode = true;
            caSlewRWaveform.clear();
            caSlewRTime.clear();
            caSlewRWaveform.append(package->parameter.vihDC);
            caSlewRTime.append(lastcaFallvihDC);        

            if((firstcaFallvihDC < 0) || ((firstcaFallvihDC > 0) && ((trigger->time()-firstcaFallvihDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstcaFallvihDC = trigger->time();
            }
        }
    }   
}

void CmdAddTimingCmdAdd::evaluate(double time){
    if(caSlewRMode){
        caSlewRWaveform.append(signal.CmdAdd.p-signal.CmdAdd.n);
        caSlewRTime.append(time);
    }
}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void CmdAddTimingCmdAdd::finalize(){
    PackageSignal* packageSignal = (PackageSignal*)signal.CmdAdd.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];

    save("CmdAddFlightTimeSetupFall", "Index", generateName(buffer,"CmdAddFlightTimeSetupFall",nodeName), caFlightTimeSetupFall);
    save("CmdAddFlightTimeSetupRise", "Index", generateName(buffer,"CmdAddFlightTimeSetupRise",nodeName), caFlightTimeSetupRise);
    save("CmdAddFlightTimeHoldFall", "Index", generateName(buffer,"CmdAddFlightTimeHoldFall",nodeName), caFlightTimeHoldFall);
    save("CmdAddFlightTimeHoldRise", "Index", generateName(buffer,"CmdAddFlightTimeHoldRise",nodeName), caFlightTimeHoldRise);
    save("CmdAddSlewRSetupFall", "Index", generateName(buffer,"CmdAddSlewRSetupFall",nodeName), caSlewRSetupFall);
    save("CmdAddSlewRSetupRise", "Index", generateName(buffer,"CmdAddSlewRSetupRise",nodeName), caSlewRSetupRise);
    save("CmdAddSlewRHoldFall", "Index", generateName(buffer,"CmdAddSlewRHoldFall",nodeName), caSlewRHoldFall);
    save("CmdAddSlewRHoldRise", "Index", generateName(buffer,"CmdAddSlewRHoldRise",nodeName), caSlewRHoldRise);
}

void CmdAddTimingCmdAdd::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.CmdAdd.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    package->check(this,"CmdAddFlightTimeSetupFall", caFlightTimeSetupFall, generateName(buffer,"CmdAddFlightTimeSetupFall",nodeName));
    package->check(this,"CmdAddFlightTimeSetupRise", caFlightTimeSetupRise, generateName(buffer,"CmdAddFlightTimeSetupRise",nodeName));
    package->check(this,"CmdAddFlightTimeHoldFall", caFlightTimeHoldFall, generateName(buffer,"CmdAddFlightTimeHoldFall",nodeName));
    package->check(this,"CmdAddFlightTimeHoldRise", caFlightTimeHoldRise, generateName(buffer,"CmdAddFlightTimeHoldRise",nodeName));
    package->check(this,"CmdAddSlewRSetupFall", caSlewRSetupFall, generateName(buffer,"CmdAddSlewRSetupFall",nodeName));
    package->check(this,"CmdAddSlewRSetupRise", caSlewRSetupRise, generateName(buffer,"CmdAddSlewRSetupRise",nodeName));
    package->check(this,"CmdAddSlewRHoldFall", caSlewRHoldFall, generateName(buffer,"CmdAddSlewRHoldFall",nodeName));
    package->check(this,"CmdAddSlewRHoldRise", caSlewRHoldRise, generateName(buffer,"CmdAddSlewRHoldRise",nodeName));
}
