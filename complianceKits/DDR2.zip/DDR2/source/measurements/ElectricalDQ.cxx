// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "ElectricalDQ.h"
#include <math.h>

ElectricalDQ::ElectricalDQ(){}

ElectricalDQ::~ElectricalDQ(){}

/// Define functions of class ElectricalDQ
/// These functions are for electrical measurements on DQ signals.

void ElectricalDQ::initialize(){
    //package->status("DDR2 ElectricalDQ Initialize");
    setEnableEvaluation(true); //evaluation is enabled.
    evalState = true;
    dqShootMode = false;
    dqNoiseMarginHighMode = false;
    dqNoiseMarginLowMode = false;
    lastdqSlope = 0;
    dqSlope = 0;

    // initial clearup of vectors
    dqOvershootPeak.clear();
    dqUndershootPeak.clear();
    dqOvershootArea.clear();
    dqUndershootArea.clear();
    dqNoiseMarginHigh.clear();
    dqNoiseMarginLow.clear();

    dqShootWaveform.clear();
    dqShootTime.clear();

    // set up triggers with specific threshold voltages    
    dqFallvDDTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vDD);
    dqFallvihDCTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vihDC);
    dqFallvRefTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vRef);
    dqFallvilDCTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vilDC);
    dqFallvSSTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vSS);

    dqRisevSSTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vSS);
    dqRisevilDCTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vilDC);
    dqRisevRefTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vRef);
    dqRisevihDCTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vihDC);
    dqRisevDDTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vDD);

    // initialize the saved trigger times
    firstdqFallvRef = -1;
    lastdqFallvRef = -1;
    firstdqFallvilDC = -1;
    lastdqFallvilDC = -1;
    firstdqRisevilDC = -1;
    firstdqRisevRef = -1;
    lastdqRisevRef = -1;
    firstdqRisevihDC = -1;
    lastdqRisevihDC = -1;
    firstdqFallvihDC = -1;

    dqShootPeakTemp = 0;
    dqShootAreaTemp = 0;
    dqNoiseMarginHighTemp = 0;
    dqNoiseMarginLowTemp = 0;
    lastdq = 0;
    dq = 0;
    UI = 1e-6/package->parameter.SpeedGrade; // one UI
}

void ElectricalDQ::event(Trigger* trigger){
    if(trigger == dqFallvRefTrigger){
        if(((firstdqFallvRef < 0) || ((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) >= 0.5*UI))) && // the very first falling edge or not the noise at current edge
           ((firstdqRisevRef < 0) || ((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) >= 0.5*UI)))) { // not the noise at any rising edge
            firstdqFallvRef = trigger->time();

        }
        if((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) < 0.5*UI)) { // close to or is the first crossing 
            lastdqFallvRef = trigger->time();
        }
    }
    if((trigger == dqFallvilDCTrigger) && (firstdqFallvRef > 0)){
        //entering logic low
        if((trigger->time()-firstdqFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastdqFallvilDC = trigger->time();
            //prepare for NoiseMarginLow after the last one
            dqNoiseMarginLowMode = true;
            dqNoiseMarginLowTemp = -1e3; //initialized to a large number
            lastdqSlope = -1; //falling edge
            lastdq = package->parameter.vilDC;
            if((firstdqFallvilDC < 0) || ((firstdqFallvilDC > 0) && ((trigger->time()-firstdqFallvilDC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstdqFallvilDC > 0) && ((trigger->time()-firstdqFallvilDC) < 0.5*UI) && (firstdqFallvilDC < lastdqFallvRef))){ // noise but there is dqFallvRef after firstdqFallvilDC (noise > vRef-vilDC) -> reset firstdqFallvilDC 
                firstdqFallvilDC = trigger->time(); //only use for first one checking.
                //prepare for undershoot after the first one since undershoot can happend before the last one
                dqShootWaveform.clear();
                dqShootTime.clear();
            }
        }
    }
    if((trigger == dqFallvSSTrigger) && (firstdqFallvRef > 0)){
        dqShootMode = true;
        dqShootWaveform.append(package->parameter.vSS);
        dqShootTime.append(trigger->time());
    }
    if((trigger == dqRisevSSTrigger) && (firstdqFallvRef > 0)){
        dqShootMode = false;
        dqShootWaveform.append(package->parameter.vSS);
        dqShootTime.append(trigger->time());
    }
    if((trigger == dqRisevilDCTrigger) && (firstdqFallvRef > 0)){
        //leaving logic low
        if(((trigger->time()-firstdqFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstdqRisevRef < 0) || ((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) > 0.5*UI)))){ // not the noise after firstdqRiseRef (in a logic high cycle)
            if((firstdqRisevilDC < 0) || ((firstdqRisevilDC > 0) && ((trigger->time()-firstdqRisevilDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstdqRisevilDC = trigger->time();
                //calculate and save dqUndershootPeak and Area
                if(dqShootWaveform.size() > 0){
                    Container<double>* waveformLink = dqShootWaveform.head();
                    Container<double>* timeLink = dqShootTime.head();
                    double temp0=0.0, tempt0=0.0; //previous values
                    double temp1=0.0, tempt1=0.0; //current values
                    bool firstPoint=true;
                    while(waveformLink){
                        if(firstPoint){
                            temp1 = package->parameter.vSS - waveformLink->data();
                            tempt1 = timeLink->data();
                            dqShootPeakTemp = temp1;
                            dqShootAreaTemp = 0.0;
                            firstPoint = false;
                        }
                        else{
                            temp0 = temp1;
                            tempt0 = tempt1;
                            temp1 = package->parameter.vSS - waveformLink->data();
                            tempt1 = timeLink->data();
                            if(temp1 > dqShootPeakTemp) dqShootPeakTemp = temp1;
                            dqShootAreaTemp += (temp0+temp1)*(tempt1-tempt0);
                        }
                        waveformLink = waveformLink->next();
                        timeLink = timeLink->next();
                    }
                }
                else{
                    dqShootPeakTemp = 0.0;
                    dqShootAreaTemp = 0.0;
                }
                dqUndershootPeak.append(dqShootPeakTemp);
                dqUndershootArea.append(dqShootAreaTemp/2*1e9);
                //save dqNoiseMarginLow
                dqNoiseMarginLowMode = false;
                if((lastdqSlope != 1) && (dqNoiseMarginLowTemp < lastdq))
                    dqNoiseMarginLowTemp = lastdq;
                dqNoiseMarginLow.append(package->parameter.vilDC - dqNoiseMarginLowTemp);
            }
        }
    }
    if(trigger == dqRisevRefTrigger){
        if(((firstdqRisevRef < 0) || ((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) >= 0.5*UI))) && // the very first Rising edge or not the noise at current edge
           ((firstdqFallvRef < 0) || ((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) >= 0.5*UI)))) { // not the noise at any falling edge
            firstdqRisevRef = trigger->time();
        }
        if((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) < 0.5*UI)) { // close to or is the first crossing 
            lastdqRisevRef = trigger->time();
        }
    }
    if((trigger == dqRisevihDCTrigger) && (firstdqRisevRef > 0)){
        //entering logic high
        if((trigger->time()-firstdqRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastdqRisevihDC = trigger->time();
            //prepare for dqNoiseMarginHigh after the last one
            dqNoiseMarginHighMode = true;
            dqNoiseMarginHighTemp = 1e3; //initialized to a large number
            lastdqSlope = 1; //rising edge
            lastdq = package->parameter.vihDC;
            if((firstdqRisevihDC < 0) || ((firstdqRisevihDC > 0) && ((trigger->time()-firstdqRisevihDC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstdqRisevihDC > 0) && ((trigger->time()-firstdqRisevihDC) < 0.5*UI) && (firstdqRisevihDC < lastdqRisevRef))){ // noise but there is dqRisevRef after firstdqRisevihDC (noise > vihDC-vRef) -> reset firstdqRisevihDC
                firstdqRisevihDC = trigger->time();
                //prepare for overshoot after the first one since overshoot can happend before the last one
                dqShootWaveform.clear();
                dqShootTime.clear();
            }
        }
    }
    if((trigger == dqRisevDDTrigger) && (firstdqRisevRef > 0)){
        dqShootMode = true;
        dqShootWaveform.append(package->parameter.vDD);
        dqShootTime.append(trigger->time());
    }
    if((trigger == dqFallvDDTrigger) && (firstdqRisevRef > 0)){
        dqShootMode = false;
        dqShootWaveform.append(package->parameter.vDD);
        dqShootTime.append(trigger->time());
    }
    if((trigger == dqFallvihDCTrigger) && (firstdqRisevRef > 0)){
        //leaving logic high
        if(((trigger->time()-firstdqRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstdqFallvRef < 0) || ((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) > 0.5*UI)))){ // not the noise after firstdqFallRef (in a logic low cycle)
            if((firstdqFallvihDC < 0) || ((firstdqFallvihDC > 0) && ((trigger->time()-firstdqFallvihDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstdqFallvihDC = trigger->time(); 
                //calculate and save dqOvershootPeak and Area
                if(dqShootWaveform.size() > 0){
                    Container<double>* waveformLink = dqShootWaveform.head();
                    Container<double>* timeLink = dqShootTime.head();
                    double temp0=0.0, tempt0=0.0; //previous values
                    double temp1=0.0, tempt1=0.0; //current values
                    bool firstPoint=true;
                    while(waveformLink){
                        if(firstPoint){
                            temp1  = waveformLink->data() - package->parameter.vDD;
                            tempt1 = timeLink->data();
                            dqShootPeakTemp = temp1;
                            dqShootAreaTemp = 0.0;
                            firstPoint = false;
                        }
                        else{
                            temp0 = temp1;
                            tempt0 = tempt1;
                            temp1  = waveformLink->data() - package->parameter.vDD;
                            tempt1 = timeLink->data();
                            if(temp1 > dqShootPeakTemp) 
                                dqShootPeakTemp = temp1;
                            dqShootAreaTemp += (temp0+temp1)*(tempt1-tempt0);
                        }
                        waveformLink = waveformLink->next();
                        timeLink = timeLink->next();
                    }
                }
                else{
                    dqShootPeakTemp = 0.0;
                    dqShootAreaTemp = 0.0;
                }
                dqOvershootPeak.append(dqShootPeakTemp);
                dqOvershootArea.append(dqShootAreaTemp/2*1e9);
                //save dqNoiseMarginHigh
                dqNoiseMarginHighMode = false;
                if((lastdqSlope != -1) && (dqNoiseMarginHighTemp > lastdq))
                    dqNoiseMarginLowTemp = lastdq;
                dqNoiseMarginHigh.append(dqNoiseMarginHighTemp - package->parameter.vihDC);
            }
        }
    }   
}

void ElectricalDQ::evaluate(double time){
    if(dqShootMode){
        dqShootWaveform.append(signal.DQ.p-signal.DQ.n);
        dqShootTime.append(time);
    }
    if(dqNoiseMarginHighMode){
        dq = signal.DQ.p-signal.DQ.n;
        if(time == lastdqRisevihDC){ //the same time point as dqRisevihDC trigger
            dqSlope = lastdqSlope;
            dq = lastdq;
        }
        else if( dq > lastdq)
            dqSlope = 1;
        else if(dq < lastdq)
            dqSlope = -1;        
        else // dq == lastdq
           dqSlope = 0;
        if((dqSlope != lastdqSlope) && (dqNoiseMarginHighTemp > lastdq))
            dqNoiseMarginHighTemp = lastdq;
        lastdq = dq;
        lastdqSlope = dqSlope;
    }
    if(dqNoiseMarginLowMode){
        dq = signal.DQ.p-signal.DQ.n;
        if(time == lastdqFallvilDC){ //the same time point as dqFallvilDC trigger
            dqSlope = lastdqSlope;
            dq = lastdq;
        }
        else if( dq > lastdq)
            dqSlope = 1;
        else if(dq < lastdq)
            dqSlope = -1;        
        else // dq == lastdq
            dqSlope = 0;
        if((dqSlope != lastdqSlope) && (dqNoiseMarginLowTemp < lastdq))
            dqNoiseMarginLowTemp = lastdq;
        lastdq = dq;
        lastdqSlope = dqSlope;
    }
}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void ElectricalDQ::finalize(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQ.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("DQOvershootPeak", "Index", generateName(buffer,"DQOvershootPeak",nodeName), dqOvershootPeak);
    save("DQUndershootPeak", "Index", generateName(buffer,"DQUndershootPeak",nodeName), dqUndershootPeak);
    save("DQOvershootArea", "Index", generateName(buffer,"DQOvershootArea",nodeName), dqOvershootArea);
    save("DQUndershootArea", "Index", generateName(buffer,"DQUndershootArea",nodeName), dqUndershootArea);
    save("DQNoiseMarginLow", "Index", generateName(buffer,"DQNoiseMarginLow",nodeName), dqNoiseMarginLow);
    save("DQNoiseMarginHigh", "Index", generateName(buffer,"DQNoiseMarginHigh",nodeName), dqNoiseMarginHigh);
}

void ElectricalDQ::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQ.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    package->check(this,"DQOvershootPeak", dqOvershootPeak, generateName(buffer,"DQOvershootPeak",nodeName));
    package->check(this,"DQUndershootPeak", dqUndershootPeak, generateName(buffer,"DQUndershootPeak",nodeName));
    package->check(this,"DQOvershootArea", dqOvershootArea, generateName(buffer,"DQOvershootArea",nodeName));
    package->check(this,"DQUndershootArea", dqUndershootArea, generateName(buffer,"DQUndershootArea",nodeName));
    package->check(this,"DQNoiseMarginLow", dqNoiseMarginLow, generateName(buffer,"DQNoiseMarginLow",nodeName));
    package->check(this,"DQNoiseMarginHigh", dqNoiseMarginHigh, generateName(buffer,"DQNoiseMarginHigh",nodeName));
}
