// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class CmdAdd_Clock_Skew.
/// This class is for skews calculation between Cmd/Add and Clock singals.

class CmdAdd_Clock_Skew:public Measurement{
public:
        CmdAdd_Clock_Skew();
        virtual ~CmdAdd_Clock_Skew();

        virtual void initialize();
        virtual void event(Trigger* trigger);
        virtual void evaluate(double time);
        virtual void finalize();
        virtual void checkCompliance();
#include "__TDCM__Measurement__CmdAdd_Clock_Skew"

        //vectors to save measurement results
        DoubleVector caSkewSetupFall;
        DoubleVector caSkewSetupRise;
        DoubleVector caSkewHoldFall;
        DoubleVector caSkewHoldRise;
};
