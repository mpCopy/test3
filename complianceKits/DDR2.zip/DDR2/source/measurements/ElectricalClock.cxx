// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "ElectricalClock.h"
#include <math.h>

ElectricalClock::ElectricalClock(){}

ElectricalClock::~ElectricalClock(){}

/// Define functions of class ElectricalClock
/// These functions are for electrical measurement on Clock signal.

void ElectricalClock::initialize(){
    //package->status("DDR2 ElectricalClock Initialize");
    setEnableEvaluation(false);
    evalState = false;

    // initial clearup of vectors
    clkVix.clear();

    // set up triggers with specific threshold voltages
    clkFallZeroTrigger = addFallingEdgeTrigger(&signal.Clock, 0.0);
    clkRiseZeroTrigger = addRisingEdgeTrigger(&signal.Clock, 0.0);
}

void ElectricalClock::event(Trigger* trigger){
    if(trigger == clkFallZeroTrigger){
        clkVix.append((trigger->getPositiveSignalValue()-package->parameter.vDD/2)*1e3);
    }
    if(trigger == clkRiseZeroTrigger){
        clkVix.append((trigger->getPositiveSignalValue()-package->parameter.vDD/2)*1e3);
    }
}

void ElectricalClock::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void ElectricalClock::finalize(){
    PackageSignal* packageSignal = (PackageSignal*)signal.Clock.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    save("ClockVIX", "Index", generateName(buffer,"ClockVIX",nodeName), clkVix);
}

void ElectricalClock::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.Clock.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    package->check(this,"ClockVIX", clkVix, generateName(buffer,"ClockVIX",nodeName));
}
