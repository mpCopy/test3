// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "DataTimingDQ.h"
#include <math.h>

DataTimingDQ::DataTimingDQ(){}

DataTimingDQ::~DataTimingDQ(){}

/// Define functions of class DataTimingDQ
/// These functions are for data timing measurements on DQ signals.

void DataTimingDQ::initialize(){
    //package->status("DDR2 DataTimingDQ Initialize");
    setEnableEvaluation(true); //evaluation is enabled.
    evalState = true;
    dqSlewRMode = false;
    dqFlightTimeSetupAvil = false;
    dqReadFlightTimeAvil = false;
    qPop = false;

    // initial clearup of vectors
    dqFlightTimeSetupFall.clear();
    dqFlightTimeSetupRise.clear();
    dqFlightTimeHoldFall.clear();
    dqFlightTimeHoldRise.clear();
    dqReadFlightTimeFallMin.clear();
    dqReadFlightTimeFallMax.clear();
    dqReadFlightTimeRiseMin.clear();
    dqReadFlightTimeRiseMax.clear();
    dqSlewRSetupFall.clear();
    dqSlewRSetupRise.clear();
    dqSlewRHoldRise.clear();
    dqSlewRHoldFall.clear();

    dqSlewRWaveform.clear();
    dqSlewRTime.clear();
    dqRefFallvMeasTime.clear();
    dqRefRisevMeasTime.clear();
    
    // set up triggers with specific threshold voltages
    dqFallvihACTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vihAC);
    dqFallvihDCTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vihDC);
    dqFallvRefTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vRef);
    dqFallvilDCTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vilDC);
    dqFallvilACTrigger = addFallingEdgeTrigger(&signal.DQ, package->parameter.vilAC);
    dqRisevilACTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vilAC);
    dqRisevilDCTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vilDC);
    dqRisevRefTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vRef);
    dqRisevihDCTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vihDC);
    dqRisevihACTrigger = addRisingEdgeTrigger(&signal.DQ, package->parameter.vihAC);

    dqRefFallvMeasTrigger = addFallingEdgeTrigger(&signal.DQ_Reference, package->parameter.vMeas);
    dqRefRisevMeasTrigger = addRisingEdgeTrigger(&signal.DQ_Reference, package->parameter.vMeas);

    // initialize the saved trigger times
    lastdqRefFallvMeas = -1;
    lastdqRefRisevMeas = -1;
    firstdqFallvRef = -1;
    lastdqFallvRef = -1;
    lastdqFallvilDC = -1;
    firstdqFallvilAC = -1;
    lastdqFallvilAC = -1;
    firstdqRisevilAC = -1;
    firstdqRisevilDC = -1;
    lastdqRisevilDC = -1;
    firstdqRisevRef = -1;
    lastdqRisevRef = -1;
    lastdqRisevihDC = -1;
    firstdqRisevihAC = -1;
    lastdqRisevihAC = -1;
    firstdqFallvihAC = -1;
    firstdqFallvihDC = -1;
    lastdqFallvihDC = -1;

    dqFlightTimeSetupTemp = 0;
    dqSlewRSetupTemp = 0;
    dqReadFlightTimeMinTemp = 0;
    dqReadFlightTimeMaxTemp = 0;
    UI = 1e-6/package->parameter.SpeedGrade; // one UI
}

void DataTimingDQ::event(Trigger* trigger){
    if(trigger == dqRefFallvMeasTrigger){
        dqRefFallvMeasTime.push(trigger->time());
    }
    if(trigger == dqFallvRefTrigger){
        if(((firstdqFallvRef < 0) || ((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) >= 0.5*UI))) && // the very first falling edge or not the noise at current edge
           ((firstdqRisevRef < 0) || ((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) >= 0.5*UI)))) { // not the noise at any rising edge
            firstdqFallvRef = trigger->time();
            if(!dqRefFallvMeasTime.empty())
                qPop = dqRefFallvMeasTime.pop(&lastdqRefFallvMeas);
            dqReadFlightTimeAvil = false;
            if(lastdqRefFallvMeas > 0){
                dqReadFlightTimeMinTemp = firstdqFallvRef-lastdqRefFallvMeas;
                dqReadFlightTimeAvil = true;
            }
            //calculate and save dqFlightTimeHoldFall and dqSlewRHoldFall (from lastdqFallvihDC to firstdqFallvRef)
            if ((lastdqRefFallvMeas > 0) && (firstdqFallvihDC > 0)){
                // Two conditions: dqFlightTimeHoldFall will be valid.
                // last one: There was a full logic high already. Has enought data for dqSlewRHoldFall.
                dqSlewRMode = false; //finish data collection for dqSlewRHoldFall
                dqSlewRWaveform.append(package->parameter.vRef);
                dqSlewRTime.append(firstdqFallvRef);
                dqFlightTimeHoldFall.append((firstdqFallvihDC-lastdqRefFallvMeas)*1e12);
		Container<double>* waveformLink = dqSlewRWaveform.head();
		Container<double>* timeLink = dqSlewRTime.head();
		Container<double>* waveformLinkTail = dqSlewRWaveform.tail();
		Container<double>* timeLinkTail = dqSlewRTime.tail();
		double vfix = waveformLink->data(); //fix at the first point vihDC
                double tfix = timeLink->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLinkTail->data())/(tfix-timeLinkTail->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                dqSlewRHoldFall.append(slewR*1e-9);
            }
        }
        if((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) < 0.5*UI)) { // close to or is the first crossing 
            lastdqFallvRef = trigger->time();
            //prepare for dqSlewRSetupFall (from lastdqFallvRef to firstdqFallvilAC)
            //this has to be done for each lastdqFallvRef since we don't know which one is the last yet. 
            dqSlewRMode = true;
            dqSlewRWaveform.clear();
            dqSlewRTime.clear();
            dqSlewRWaveform.append(package->parameter.vRef);
            dqSlewRTime.append(lastdqFallvRef);
            if(lastdqRefFallvMeas > 0)
                dqReadFlightTimeMaxTemp = lastdqFallvRef-lastdqRefFallvMeas; //To be saved later to make sure the max (last).
        }
    }
    if((trigger == dqFallvilDCTrigger) && (firstdqFallvRef > 0)){
        //entering logic low
        if((trigger->time()-firstdqFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastdqFallvilDC = trigger->time();
        }
    }
    if((trigger == dqFallvilACTrigger) && (firstdqFallvRef > 0)){
        if((trigger->time()-firstdqFallvRef) <= 0.5*UI){ // within a falling edge. could be the first or last one.
            lastdqFallvilAC = trigger->time();
            //calculate and save dqFlightTimeSetupFall (from dqRefFallvMeas to lastdqFallvilAC) and dqSlewRSetupFall (from lastdqFallVref to firstdqFallvilAC) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstdqRisevilAC.
            //calculate dqFlightTimeSetupFall
            dqFlightTimeSetupAvil = false;
            if(lastdqRefFallvMeas > 0){
                //condition: dqFlightTimeSetupFall will be valid
                dqFlightTimeSetupTemp = lastdqFallvilAC-lastdqRefFallvMeas;
                dqFlightTimeSetupAvil = true;
            }
            if((firstdqFallvilAC < 0) || ((firstdqFallvilAC > 0) && ((trigger->time()-firstdqFallvilAC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstdqFallvilAC > 0) && ((trigger->time()-firstdqFallvilAC) < 0.5*UI) && (firstdqFallvilAC < lastdqFallvRef))){ // noise but there is dqFallvRef after firstdqFallvilAC (noise > vRef-vilAC) -> reset firstdqFallvilAC 
                firstdqFallvilAC = trigger->time();
                //calculate dqSlewRSetupFall (from lastdqFallVref to firstdqFallvilAC)
                dqSlewRMode = false; //finish data collection for dqSlewRSetupFall
                dqSlewRWaveform.append(package->parameter.vilAC);
                dqSlewRTime.append(firstdqFallvilAC);
                Container<double>* waveformLink = dqSlewRWaveform.head();
                Container<double>* timeLink = dqSlewRTime.head();
                Container<double>* waveformLinkTail = dqSlewRWaveform.tail();
                Container<double>* timeLinkTail = dqSlewRTime.tail();
                double vfix = waveformLinkTail->data();  //fix at the last point vilAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                dqSlewRSetupTemp = slewR*1e-9;
            }
        }
    }
    if((trigger == dqRisevilACTrigger) && (firstdqFallvRef > 0)){
        if(((trigger->time()-firstdqFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstdqRisevilAC < 0) || ((firstdqRisevilAC > 0) && ((trigger->time()-firstdqRisevilAC) > 0.5*UI)))){ // not the noise at current edge -> first one
            firstdqRisevilAC = trigger->time(); //no need for lastdqRisevilAC -> don't need to check for noise after firstdqRisevRef
            if(dqFlightTimeSetupAvil){ 
                // save dqFlightTimeSetupFall and dqSlewRSetupFall
                dqFlightTimeSetupFall.append(dqFlightTimeSetupTemp*1e12);
                dqSlewRSetupFall.append(dqSlewRSetupTemp);
            }
        }
    }
    if((trigger == dqRisevilDCTrigger) && (firstdqFallvRef > 0)){
        //leaving logic low
        if(((trigger->time()-firstdqFallvRef) > 0.5*UI) && // within a rising edge. could be the first or last one.
           ((firstdqRisevRef < 0) || ((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) > 0.5*UI)))){ // not the noise after firstdqRiseRef (in a logic high cycle)
            lastdqRisevilDC = trigger->time();
            //prepare for dqSlewRHoldRise from (lastdqRisevilDC to firstdqRisevRef)
            dqSlewRMode = true;
            dqSlewRWaveform.clear();
            dqSlewRTime.clear();
            dqSlewRWaveform.append(package->parameter.vilDC);
            dqSlewRTime.append(lastdqRisevilDC);

            if((firstdqRisevilDC < 0) || ((firstdqRisevilDC > 0) && ((trigger->time()-firstdqRisevilDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstdqRisevilDC = trigger->time();
                //save dqReadFlightTimeMin and dqReadFlightTimeMax together.
                if(dqReadFlightTimeAvil){
                    dqReadFlightTimeFallMin.append(dqReadFlightTimeMinTemp*1e12);
                    dqReadFlightTimeFallMax.append(dqReadFlightTimeMaxTemp*1e12);
                }
            }
        }
    }
    if(trigger == dqRefRisevMeasTrigger){
        dqRefRisevMeasTime.push(trigger->time());
    }
    if(trigger == dqRisevRefTrigger){
        if(((firstdqRisevRef < 0) || ((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) >= 0.5*UI))) && // the very first Rising edge or not the noise at current edge
           ((firstdqFallvRef < 0) || ((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) >= 0.5*UI)))) { // not the noise at any falling edge
            firstdqRisevRef = trigger->time();
            if(!dqRefRisevMeasTime.empty())
                qPop = dqRefRisevMeasTime.pop(&lastdqRefRisevMeas);
            dqReadFlightTimeAvil = false;
            if(lastdqRefRisevMeas > 0){
                dqReadFlightTimeMinTemp = firstdqRisevRef-lastdqRefRisevMeas;
                dqReadFlightTimeAvil = true;
            }
            //calculate and save dqFlightTimeHoldRise and dqSlewRHoldRise (from lastdqRisevilDC to firstdqRisevRef)
            if((lastdqRefRisevMeas > 0) && (firstdqRisevilDC > 0)){
                dqSlewRMode = false; //finish data collection for dqSlewRHoldRise
                dqSlewRWaveform.append(package->parameter.vRef);
                dqSlewRTime.append(firstdqRisevRef);
                dqFlightTimeHoldRise.append((firstdqRisevilDC-lastdqRefRisevMeas)*1e12);
                Container<double>* waveformLink = dqSlewRWaveform.head();
                Container<double>* timeLink = dqSlewRTime.head();
                Container<double>* waveformLinkTail = dqSlewRWaveform.tail();
                Container<double>* timeLinkTail = dqSlewRTime.tail();
                double vfix = waveformLink->data(); // fix at the first point vilDC 
                double tfix = timeLink->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLinkTail->data())/(tfix-timeLinkTail->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                dqSlewRHoldRise.append(slewR*1e-9);
            }
        }
        if((firstdqRisevRef > 0) && ((trigger->time()-firstdqRisevRef) < 0.5*UI)) { // close to or is the first crossing 
            lastdqRisevRef = trigger->time();
            //prepare for dqSlewRSetupRise (from lastdqRisevRef to firstdqRisevihAC)
            //this has to be done for each lastdqRisevRef since we don't know which one is the last yet.
            dqSlewRMode = true;
            dqSlewRWaveform.clear();
            dqSlewRTime.clear();
            dqSlewRWaveform.append(package->parameter.vRef);
            dqSlewRTime.append(lastdqRisevRef);
            if(lastdqRefRisevMeas > 0)
                dqReadFlightTimeMaxTemp = lastdqRisevRef-lastdqRefRisevMeas; //To be saved later to make sure the max (last).
        }
    }
    if((trigger == dqRisevihDCTrigger) && (firstdqRisevRef > 0)){
        //entering logic high
        if((trigger->time()-firstdqRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastdqRisevihDC = trigger->time();
        }
    }
    if((trigger == dqRisevihACTrigger) && (firstdqRisevRef > 0)){
        if((trigger->time()-firstdqRisevRef) <= 0.5*UI){ // within a rising edge. could be the first or last one.
            lastdqRisevihAC = trigger->time();
            //calculate and save dqFlightTimeSetupRise (from dqRefRisevMeas to lastdqRisevihAC) and dqSlewRSetupRise (from lastdqRiseVref to firstdqRisevihAC) 
            //in Temp since we are not sure if this is the last one for flight time. Will save them in pair to final vectors after firstdqFallvihAC.
            //calculate dqFlightTimeSetupRise
            dqFlightTimeSetupAvil = false;
            if(lastdqRefRisevMeas > 0){
                //condition: dqFlightTimeSetupRise will be valid
                dqFlightTimeSetupTemp = lastdqRisevihAC-lastdqRefRisevMeas;
                dqFlightTimeSetupAvil = true;
            }
            if((firstdqRisevihAC < 0) || ((firstdqRisevihAC > 0) && ((trigger->time()-firstdqRisevihAC) > 0.5*UI)) || // not the noise at current edge -> first one
               ((firstdqRisevihAC > 0) && ((trigger->time()-firstdqRisevihAC) < 0.5*UI) && (firstdqRisevihAC < lastdqRisevRef))){ // noise but there is dqRisevRef after firstdqRisevihAC (noise > vihAC-vRef) -> reset firstdqRisevihAC 
                firstdqRisevihAC = trigger->time();
                //calculate dqSlewRSetupRise (from lastdqRiseVref to firstdqRisevihAC)
                dqSlewRMode = false; //finish data collection for dqSlewRSetupRise
                dqSlewRWaveform.append(package->parameter.vihAC);
                dqSlewRTime.append(firstdqRisevihAC);
                Container<double>* waveformLink = dqSlewRWaveform.head();
                Container<double>* timeLink = dqSlewRTime.head();
                Container<double>* waveformLinkTail = dqSlewRWaveform.tail();
                Container<double>* timeLinkTail = dqSlewRTime.tail();
                double vfix = waveformLinkTail->data(); //fix at the last point vihAC
                double tfix = timeLinkTail->data();
                double slewRTemp = 0;
                double slewR = 0;
                slewR = fabs((vfix-waveformLink->data())/(tfix-timeLink->data())); //nominal slew rate
                waveformLink = waveformLink->next();
                timeLink = timeLink->next();
                while(waveformLink && (waveformLink != waveformLinkTail)){
                    if(tfix != timeLink->data()){
                        slewRTemp = fabs((vfix-waveformLink->data())/(tfix-timeLink->data()));
                        if(slewRTemp > slewR)
                            slewR = slewRTemp;
                    }
                    waveformLink = waveformLink->next();
                    timeLink = timeLink->next();
                }
                dqSlewRSetupTemp = slewR*1e-9;
            }
        }
    }
    if((trigger == dqFallvihACTrigger) && (firstdqRisevRef > 0)){
        if(((trigger->time()-firstdqRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstdqFallvihAC < 0) || ((firstdqFallvihAC > 0) && ((trigger->time()-firstdqFallvihAC) > 0.5*UI)))){ // not the noise at current edge -> first one
               firstdqFallvihAC = trigger->time(); //no need for lastdqFallvihAC -> don't need to check for noise after firstdqFallvRef
               if(dqFlightTimeSetupAvil){ 
                   // save dqFlightTimeSetupRise and dqSlewRSetupRise
                   dqFlightTimeSetupRise.append(dqFlightTimeSetupTemp*1e12);
                   dqSlewRSetupRise.append(dqSlewRSetupTemp);
               }    
        }
    }
    if((trigger == dqFallvihDCTrigger) && (firstdqRisevRef > 0)){
        //leaving logic high
        if(((trigger->time()-firstdqRisevRef) > 0.5*UI) && // within a falling edge. could be the first or last one.
           ((firstdqFallvRef < 0) || ((firstdqFallvRef > 0) && ((trigger->time()-firstdqFallvRef) > 0.5*UI)))){ // not the noise after firstdqFallRef (in a logic low cycle)
            lastdqFallvihDC = trigger->time();
            //prepare for dqSlewRHoldFall from (lastdqFallvihDC to firstdqFallvRef)
            dqSlewRMode = true;
            dqSlewRWaveform.clear();
            dqSlewRTime.clear();
            dqSlewRWaveform.append(package->parameter.vihDC);
            dqSlewRTime.append(lastdqFallvihDC);        

            if((firstdqFallvihDC < 0) || ((firstdqFallvihDC > 0) && ((trigger->time()-firstdqFallvihDC) > 0.5*UI))){ // not the noise at current edge -> first one
                firstdqFallvihDC = trigger->time();
                // save dqReadFlightTimeMin and dqReadFlightTimeMax together.
                if(dqReadFlightTimeAvil){
                    dqReadFlightTimeRiseMin.append(dqReadFlightTimeMinTemp*1e12);
                    dqReadFlightTimeRiseMax.append(dqReadFlightTimeMaxTemp*1e12);
                }
            }
        }
    }   
}

void DataTimingDQ::evaluate(double time){
    if(dqSlewRMode){
        dqSlewRWaveform.append(signal.DQ.p-signal.DQ.n);
        dqSlewRTime.append(time);
    }
}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void DataTimingDQ::finalize(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQ.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];

    save("DQFlightTimeSetupFall", "Index", generateName(buffer,"DQFlightTimeSetupFall",nodeName), dqFlightTimeSetupFall);
    save("DQFlightTimeSetupRise", "Index", generateName(buffer,"DQFlightTimeSetupRise",nodeName), dqFlightTimeSetupRise);
    save("DQFlightTimeHoldFall", "Index", generateName(buffer,"DQFlightTimeHoldFall",nodeName), dqFlightTimeHoldFall);
    save("DQFlightTimeHoldRise", "Index", generateName(buffer,"DQFlightTimeHoldRise",nodeName), dqFlightTimeHoldRise);
    save("DQFlightTimeReadFallMin", "Index", generateName(buffer,"DQFlightTimeReadFallMin",nodeName), dqReadFlightTimeFallMin);
    save("DQFlightTimeReadFallMax", "Index", generateName(buffer,"DQFlightTimeReadFallMax",nodeName), dqReadFlightTimeFallMax);
    save("DQFlightTimeReadRiseMin", "Index", generateName(buffer,"DQFlightTimeReadRiseMin",nodeName), dqReadFlightTimeRiseMin);
    save("DQFlightTimeReadRiseMax", "Index", generateName(buffer,"DQFlightTimeReadRiseMax",nodeName), dqReadFlightTimeRiseMax);
    save("DQSlewRSetupFall", "Index", generateName(buffer,"DQSlewRSetupFall",nodeName), dqSlewRSetupFall);
    save("DQSlewRSetupRise", "Index", generateName(buffer,"DQSlewRSetupRise",nodeName), dqSlewRSetupRise);
    save("DQSlewRHoldFall", "Index", generateName(buffer,"DQSlewRHoldFall",nodeName), dqSlewRHoldFall);
    save("DQSlewRHoldRise", "Index", generateName(buffer,"DQSlewRHoldRise",nodeName), dqSlewRHoldRise);
}

void DataTimingDQ::checkCompliance(){
    PackageSignal* packageSignal = (PackageSignal*)signal.DQ.packageSignal;
    const char* nodeName =  this->package->getNodeName(packageSignal->positive);
    char buffer[4096];
    package->check(this,"DQFlightTimeSetupFall", dqFlightTimeSetupFall, generateName(buffer,"DQFlightTimeSetupFall",nodeName));
    package->check(this,"DQFlightTimeSetupRise", dqFlightTimeSetupRise, generateName(buffer,"DQFlightTimeSetupRise",nodeName));
    package->check(this,"DQFlightTimeHoldFall", dqFlightTimeHoldFall, generateName(buffer,"DQFlightTimeHoldFall",nodeName));
    package->check(this,"DQFlightTimeHoldRise", dqFlightTimeHoldRise, generateName(buffer,"DQFlightTimeHoldRise",nodeName));
    package->check(this,"DQFlightTimeReadFallMin", dqReadFlightTimeFallMin, generateName(buffer,"DQFlightTimeReadFallMin",nodeName));
    package->check(this,"DQFlightTimeReadFallMax", dqReadFlightTimeFallMax, generateName(buffer,"DQFlightTimeReadFallMax",nodeName));
    package->check(this,"DQFlightTimeReadRiseMin", dqReadFlightTimeRiseMin, generateName(buffer,"DQFlightTimeReadRiseMin",nodeName));
    package->check(this,"DQFlightTimeReadRiseMax", dqReadFlightTimeRiseMax, generateName(buffer,"DQFlightTimeReadRiseMax",nodeName));
    package->check(this,"DQSlewRSetupFall", dqSlewRSetupFall, generateName(buffer,"DQSlewRSetupFall",nodeName));
    package->check(this,"DQSlewRSetupRise", dqSlewRSetupRise, generateName(buffer,"DQSlewRSetupRise",nodeName));
    package->check(this,"DQSlewRHoldFall", dqSlewRHoldFall, generateName(buffer,"DQSlewRHoldFall",nodeName));
    package->check(this,"DQSlewRHoldRise", dqSlewRHoldRise, generateName(buffer,"DQSlewRHoldRise",nodeName));
}
