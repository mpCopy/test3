// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class ElectricalClock.
/// This class is for electrical measurement on Clock singal.

class ElectricalClock:public Measurement{
public:
	ElectricalClock();
	virtual ~ElectricalClock();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__ElectricalClock"

        // vector to save measurement result
        DoubleVector clkVix;

protected:
        // Clock triggers at threshold voltages
        Trigger* clkFallZeroTrigger;
        Trigger* clkRiseZeroTrigger;

        bool evalState;
};
