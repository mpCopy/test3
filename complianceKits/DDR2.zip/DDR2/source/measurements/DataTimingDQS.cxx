// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "DataTimingDQS.h"
#include <math.h>

DataTimingDQS::DataTimingDQS(){}

DataTimingDQS::~DataTimingDQS(){}

/// Define functions of class DataTimingDQS
/// These functions are for data timing measurements on DQS signal.

void DataTimingDQS::initialize(){
    //package->status("DDR2 DataTimingDQS Initialize");
    setEnableEvaluation(false);
    evalState = false;
    qPop = false;
    singleEnded = false;

    // check if single ended.
    PackageSignal* packageSignal = (PackageSignal*)signal.DQS.packageSignal;
    const char* nodeNameDQSn =  this->package->getNodeName(packageSignal->negative);
    if(strcmp( nodeNameDQSn, "0" ) == 0)
        singleEnded = true;
    packageSignal = (PackageSignal*)signal.DQS_Reference.packageSignal;
    const char* nodeNameDQSRefn =  this->package->getNodeName(packageSignal->negative);
    if(singleEnded != (strcmp( nodeNameDQSRefn, "0" ) == 0)){
        package->fatalError("DQS or DQS_Reference is not single-ended. Check probes connection.");
        return;
    }

    // initial cleanup of vectors
    dqsFlightTimeFallVih.clear();
    dqsFlightTimeFallVref0.clear();
    dqsFlightTimeFallVil.clear();
    dqsFlightTimeRiseVil.clear();
    dqsFlightTimeRiseVref0.clear();
    dqsFlightTimeRiseVih.clear();
    dqsSlewRFall.clear();
    dqsSlewRRise.clear();

    dqsRefFallVmeas0Time.clear();
    dqsRefRiseVmeas0Time.clear();
   
    // set up triggers with specific threshold voltages
    if(singleEnded){
        fallVih = package->parameter.vihDC;
        fallVil = package->parameter.vilAC;
        riseVil = package->parameter.vilDC;
        riseVih = package->parameter.vihAC;
        dqsFallVihTrigger = addFallingEdgeTrigger(&signal.DQS, fallVih);
        dqsFallVref0Trigger = addFallingEdgeTrigger(&signal.DQS, package->parameter.vRef);
        dqsFallVilTrigger = addFallingEdgeTrigger(&signal.DQS, fallVil);
        dqsRiseVilTrigger = addRisingEdgeTrigger(&signal.DQS, riseVil);
        dqsRiseVref0Trigger = addRisingEdgeTrigger(&signal.DQS, package->parameter.vRef);
        dqsRiseVihTrigger = addRisingEdgeTrigger(&signal.DQS, riseVih);
        dqsRefFallVmeas0Trigger = addFallingEdgeTrigger(&signal.DQS_Reference, package->parameter.vMeas);
        dqsRefRiseVmeas0Trigger = addRisingEdgeTrigger(&signal.DQS_Reference, package->parameter.vMeas);
    }
    else{ // differentail
        fallVih = 2*(package->parameter.vihDC-package->parameter.vRef);
        fallVil = 2*(package->parameter.vilAC-package->parameter.vRef);
        riseVil = 2*(package->parameter.vilDC-package->parameter.vRef);
        riseVih = 2*(package->parameter.vihAC-package->parameter.vRef);
        dqsFallVihTrigger = addFallingEdgeTrigger(&signal.DQS, fallVih);
        dqsFallVref0Trigger = addFallingEdgeTrigger(&signal.DQS, 0.0);
        dqsFallVilTrigger = addFallingEdgeTrigger(&signal.DQS, fallVil);
        dqsRiseVilTrigger = addRisingEdgeTrigger(&signal.DQS, riseVil);
        dqsRiseVref0Trigger = addRisingEdgeTrigger(&signal.DQS, 0.0);
        dqsRiseVihTrigger = addRisingEdgeTrigger(&signal.DQS, riseVih);
        dqsRefFallVmeas0Trigger = addFallingEdgeTrigger(&signal.DQS_Reference, 0.0);
        dqsRefRiseVmeas0Trigger = addRisingEdgeTrigger(&signal.DQS_Reference, 0.0);
    }

    // initialize the saved trigger times
    lastdqsRefFallVmeas0 = -1;
    lastdqsRefRiseVmeas0 = -1;
    lastdqsFallVih = -1;
    lastdqsRiseVil = -1;
}

void DataTimingDQS::event(Trigger* trigger){
    if(trigger == dqsRefFallVmeas0Trigger){
        dqsRefFallVmeas0Time.push(trigger->time());
    }
    if(trigger == dqsFallVref0Trigger){
        if(!dqsRefFallVmeas0Time.empty())
            qPop = dqsRefFallVmeas0Time.pop(&lastdqsRefFallVmeas0);
        if(lastdqsRefFallVmeas0 > 0)
            dqsFlightTimeFallVref0.append((trigger->time()-lastdqsRefFallVmeas0)*1e12);
        //calculate FlightTimeFallVih here to avoid using the previous dqsRefFallVmeas0
        if(singleEnded && (lastdqsRefFallVmeas0 > 0) && (lastdqsFallVih > 0))
            dqsFlightTimeFallVih.append((lastdqsFallVih - lastdqsRefFallVmeas0)*1e12);
    }
    if(trigger == dqsFallVilTrigger){
        if(singleEnded && (lastdqsRefFallVmeas0 > 0))
            dqsFlightTimeFallVil.append((trigger->time()-lastdqsRefFallVmeas0)*1e12);
        if(lastdqsFallVih > 0)
            dqsSlewRFall.append((fallVih-fallVil)/(trigger->time()-lastdqsFallVih)*1e-9);
    }
    if(trigger == dqsRiseVilTrigger){
        lastdqsRiseVil = trigger->time();
    }
    if(trigger == dqsRefRiseVmeas0Trigger){
        dqsRefRiseVmeas0Time.push(trigger->time());
    }
    if(trigger == dqsRiseVref0Trigger){
        if(!dqsRefRiseVmeas0Time.empty())
            qPop = dqsRefRiseVmeas0Time.pop(&lastdqsRefRiseVmeas0);
        if(lastdqsRefRiseVmeas0 > 0)
            dqsFlightTimeRiseVref0.append((trigger->time()-lastdqsRefRiseVmeas0)*1e12);
        //calculate FlightTimeRiseVil here to avoid using the previous dqsRefRiseVmeas0
        if(singleEnded && (lastdqsRefRiseVmeas0 > 0) && (lastdqsRiseVil > 0))
            dqsFlightTimeRiseVil.append((lastdqsRiseVil - lastdqsRefRiseVmeas0)*1e12);
    }
    if(trigger == dqsRiseVihTrigger){
        if(singleEnded && (lastdqsRefRiseVmeas0 > 0))
            dqsFlightTimeRiseVih.append((trigger->time()-lastdqsRefRiseVmeas0)*1e12);
        if(lastdqsRiseVil > 0)
            dqsSlewRRise.append((riseVih-riseVil)/(trigger->time()-lastdqsRiseVil)*1e-9);
    }
    if(trigger == dqsFallVihTrigger){
        lastdqsFallVih = trigger->time();
    }   
}

void DataTimingDQS::evaluate(double time){}

static char* generateName(char* buffer,const char* name,const char* nodeName){
    sprintf(buffer,"%s.%s",name,nodeName);
    return buffer;
}

void DataTimingDQS::finalize(){
  PackageSignal* packageSignal = (PackageSignal*)signal.DQS.packageSignal;
  const char* nodeName =  this->package->getNodeName(packageSignal->positive);
  char buffer[4096];
  save("DQSFlightTimeFallVref0", "Index", generateName(buffer,"DQSFlightTimeFallVref0",nodeName), dqsFlightTimeFallVref0);
  save("DQSFlightTimeRiseVref0", "Index", generateName(buffer,"DQSFlightTimeRiseVref0",nodeName), dqsFlightTimeRiseVref0);
  if(singleEnded){
      save("DQSFlightTimeFallVih", "Index", generateName(buffer,"DQSFlightTimeFallVih",nodeName), dqsFlightTimeFallVih);
      save("DQSFlightTimeFallVil", "Index", generateName(buffer,"DQSFlightTimeFallVil",nodeName), dqsFlightTimeFallVil);
      save("DQSFlightTimeRiseVil", "Index", generateName(buffer,"DQSFlightTimeRiseVil",nodeName), dqsFlightTimeRiseVil);
      save("DQSFlightTimeRiseVih", "Index", generateName(buffer,"DQSFlightTimeRiseVih",nodeName), dqsFlightTimeRiseVih);
  }
  save("DQSSlewRFall", "Index", generateName(buffer,"DQSSlewRFall",nodeName), dqsSlewRFall);
  save("DQSSlewRRise", "Index", generateName(buffer,"DQSSlewRRise",nodeName), dqsSlewRRise);
}

void DataTimingDQS::checkCompliance(){
  PackageSignal* packageSignal = (PackageSignal*)signal.DQS.packageSignal;
  const char* nodeName =  this->package->getNodeName(packageSignal->positive);
  char buffer[4096];
  package->check(this,"DQSFlightTimeFallVref0", dqsFlightTimeFallVref0, generateName(buffer,"DQSFlightTimeFallVref0",nodeName));
  package->check(this,"DQSFlightTimeRiseVref0", dqsFlightTimeRiseVref0, generateName(buffer,"DQSFlightTimeRiseVref0",nodeName));
  if(singleEnded){
      package->check(this,"DQSFlightTimeFallVih", dqsFlightTimeFallVih, generateName(buffer,"DQSFlightTimeFallVih",nodeName));
      package->check(this,"DQSFlightTimeFallVil", dqsFlightTimeFallVil, generateName(buffer,"DQSFlightTimeFallVil",nodeName));
      package->check(this,"DQSFlightTimeRiseVil", dqsFlightTimeRiseVil, generateName(buffer,"DQSFlightTimeRiseVil",nodeName));
      package->check(this,"DQSFlightTimeRiseVih", dqsFlightTimeRiseVih, generateName(buffer,"DQSFlightTimeRiseVih",nodeName));
  }
  package->check(this,"DQSSlewRFall", dqsSlewRFall, generateName(buffer,"DQSSlewRFall",nodeName));
  package->check(this,"DQSSlewRRise", dqsSlewRRise, generateName(buffer,"DQSSlewRRise",nodeName));
}
