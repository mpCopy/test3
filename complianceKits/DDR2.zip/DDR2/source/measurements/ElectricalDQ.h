// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential
#include "TDCM.h"
#include "Descriptor.h"

using namespace TDCM;

/// Define class ElectricalDQ.
/// This class is for electrical measurements on DQ singals.

class ElectricalDQ:public Measurement{
public:
	ElectricalDQ();
	virtual ~ElectricalDQ();

	virtual void initialize();
	virtual void event(Trigger* trigger);
	virtual void evaluate(double time);
	virtual void finalize();
	virtual void checkCompliance();
#include "__TDCM__Measurement__ElectricalDQ"

        // vectors to save measurement results
        DoubleVector dqOvershootPeak;
        DoubleVector dqUndershootPeak;
        DoubleVector dqOvershootArea;
        DoubleVector dqUndershootArea;
        DoubleVector dqNoiseMarginHigh;
        DoubleVector dqNoiseMarginLow;

protected:
        // vectors to save waveform for overshoot/undershoot calculation.
        DoubleVector dqShootWaveform;
        DoubleVector dqShootTime;

        // DQ triggers at threshold voltages.
        Trigger* dqFallvDDTrigger;
        Trigger* dqFallvihDCTrigger;
        Trigger* dqFallvRefTrigger;
        Trigger* dqFallvilDCTrigger;
        Trigger* dqFallvSSTrigger;
        Trigger* dqRisevSSTrigger;
        Trigger* dqRisevilDCTrigger;
        Trigger* dqRisevRefTrigger;
        Trigger* dqRisevihDCTrigger;
        Trigger* dqRisevDDTrigger;

        bool evalState;
        bool dqShootMode;
        bool dqNoiseMarginHighMode;
        bool dqNoiseMarginLowMode;
        int lastdqSlope;
        int dqSlope;

        // variables to save trigger times.
        double firstdqFallvRef;
        double lastdqFallvRef;
        double firstdqFallvilDC;
        double lastdqFallvilDC;
        double firstdqRisevilDC;
        double firstdqRisevRef;
        double lastdqRisevRef;
        double firstdqRisevihDC;
        double lastdqRisevihDC;
        double firstdqFallvihDC;

        double dqShootPeakTemp;
        double dqShootAreaTemp;
        double dqNoiseMarginHighTemp;
        double dqNoiseMarginLowTemp;
        double lastdq;
        double dq;
        double UI;
};
