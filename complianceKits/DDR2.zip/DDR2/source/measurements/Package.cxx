// Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
#include "Descriptor.h"
using namespace TDCM;
#include <string>

DDR2_Package::DDR2_Package():Package(){}

DDR2_Package::~DDR2_Package(){}

char* DDR2_Package::getConstraintsFileName()
{
    static char buffer[2048];
    buffer[0] = '\0';
    sprintf(buffer,"constraints_%d.xml",(int)parameter.SpeedGrade);
    return buffer;
}