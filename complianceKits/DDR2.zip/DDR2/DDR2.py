# Copyright 1983 Keysight Technologies, Inc , Keysight Confidential 
from ADSSim_Modules import *
from Design import *
from Component import *
from DDR2_Descriptor import *

class  DDR2(TDCM_Loader):
    descriptor = DDR2_Descriptor
    def __init__(self,instance):
        TDCM_Loader.__init__( self, instance )
        self.package = "DDR2"
        self.constraintsFile = None
        self.testNames = {}

    def checkSignalCount(self,map,signalName):
        if not map.has_key(signalName):
            self.simulation.printFatalError(self.instance.getInstanceName(True),
                                            "Unknown signal type '" + signalName + "'.")
            return False
        if map[signalName] > 1:
            self.simulation.printFatalError(self.instance.getInstanceName(True),
                                            "You can only have a single '" + signalName + "' signal in a probe.\n")
            return False
        return True
    
    def setup(self,network):
         nodeType = self.data[TDCM_Descriptor.NodeTypeID]
         nodeTypeMap = {}
         nodeTypeMap["DQ"] = 0
         nodeTypeMap["DQ_Reference"] = 0
         nodeTypeMap["DQS"] = 0
         nodeTypeMap["DQS_Reference"] = 0
         nodeTypeMap["CmdAdd"] = 0
         nodeTypeMap["CmdAdd_Reference"] = 0
         nodeTypeMap["Clock"] = 0
         nodeTypeMap["Clock_Reference"] = 0

         for i in nodeType:
             n = nodeType[i]
             if not nodeTypeMap.has_key(n):
                 self.simulation.printFatalError(self.instance.getInstanceName(True),
                                                 "Unknown signal type '" + i + "'.")
                 return False
             k = nodeTypeMap[n]
             nodeTypeMap[n] = k + 1
             
         
         
         status = (self.checkSignalCount(nodeTypeMap,"DQ_Reference") and
                   self.checkSignalCount(nodeTypeMap,"DQS") and
                   self.checkSignalCount(nodeTypeMap,"DQS_Reference") and
                   self.checkSignalCount(nodeTypeMap,"CmdAdd_Reference") and
                   self.checkSignalCount(nodeTypeMap,"Clock") and
                   self.checkSignalCount(nodeTypeMap,"Clock_Reference"))
         if status:         
             return TDCM_Loader.setup(self,network)
         return status



    def readConstaintsFile(self):
        cFile = Design.Simulation.TDCM_getConstraintsFileName(self.object)
        if cFile == self.constraintsFile:
            return
        self.constraintsFile = cFile
        rootPackage = self.data[TDCM_Descriptor.PackageRootID]
        fileName = os.path.join(rootPackage,"source","constraints",self.constraintsFile)
        #RESET TO +/- INF
        for i in self.testNames:
            Design.Simulation.TDCM_setTestLimits(self.object,i,-1e400,1e400)
    
            
        if fileName:
            try:
                builder = ADSSim_TestLimits.Builder(fileName)
                builder.setup()
                for i in builder.testSet.testLimits:
                    testLimit = builder.testSet.testLimits[i]
                    Design.Simulation.TDCM_setTestLimits(self.object,i,
                                                         testLimit.min,
                                                         testLimit.max)
                    self.testNames[i] = 1
            except exceptions.StandardError,m:
                self.simulation.printWarning("TDCM_Loader",
                                             "Unable to build constraints '" + fileName + "'")
                self.simulation.printWarning("TDCM_Loader",
                                             m.message)
        return
    
    def modifyParameter(self,parameterID,value,index):
        if not self.data.has_key(parameterID):
            return UnknownParameter
        parameter = self.descriptor[parameterID]
        if not parameter.isModifiable():
            return UnmodifiableParameter
        if not parameter.checkType(value):
            return InvalidParameterType
        self.data[parameterID] = value
        if self.object:
            Design.Simulation.TDCM_set(self.object,parameterID,value)
            self.readConstaintsFile()
        return 1

    
    def load(self,signalSize):
      	rootPackage = self.data[TDCM_Descriptor.PackageRootID]
        if (not self.package):
            self.simulation.printFatalError("TDCM_Loader","Package name not given")
            return False
        target = None
        if TDCM_Loader.loadMap.has_key(rootPackage):
            target = TDCM_Loader.loadMap[rootPackage]
        if target == None:
            SIMARCH = None
            HPEESOF_DIR = None
            if os.environ.has_key('SIMARCH'):
		SIMARCH = os.environ['SIMARCH']
            if os.environ.has_key('HPEESOF_DIR'):
		HPEESOF_DIR = os.environ['HPEESOF_DIR']
            if HPEESOF_DIR == None:
		self.simulation.printFatalError(self.instance.getInstanceName(True),
                                                "HPEESOF_DIR variable is not set properly.")
		return False

            if SIMARCH == None:
		self.simulation.printFatalError(self.instance.getInstanceName(True),
                                                "SIMARCH variable is not set properly.")
		return False

            python = None 
	    HPEESOF_DIR = os.environ['HPEESOF_DIR']
            TDA_ROOT = os.path.join(HPEESOF_DIR,"tiburonda","tools")
            tdcmRoot = os.path.join(HPEESOF_DIR,"circuit")
            
            if SIMARCH.find("linux_x86") == 0:
                gcc     = os.path.join(HPEESOF_DIR,"tiburonda","tools",SIMARCH,"bin","g++")
                version = Design.Simulation.version()
                isDebug = Design.Simulation.isDebug()
                is32bit = not Design.Simulation.is64b()
                python = os.path.join(os.environ["PYTHONHOME"],"bin","python")
            elif SIMARCH.find("win32") == 0:
                gcc     = os.path.join(HPEESOF_DIR,"tiburonda","tools","mingw32","bin","g++.exe")
                version = Design.Simulation.version()
                isDebug = Design.Simulation.isDebug()
                is32bit = not Design.Simulation.is64b()
                python = os.path.join(os.environ["PYTHONHOME"],"bin","python.exe")
		if not is32bit:
                    gcc = os.path.join(HPEESOF_DIR,"tiburonda","tools","mingw64","bin","g++.exe")
                    
            if SIMARCH.find("win") == 0:
                rootPackage = rootPackage.replace("/","\\")

            if isDebug:
                isDebug = "1"
            else:
                isDebug = "0"
            if is32bit:
                is32bit = "1"
            else:
                is32bit = "0"
            checkDependency = "1"
        
           
            sourceFile = os.path.join(rootPackage,"DDR_TDCMCompile.py")

            arguments  = rootPackage+" "+tdcmRoot+" "+gcc+" "
            arguments += " \""+version+"\" "+isDebug+" "+is32bit+" "+checkDependency+" "
            arguments += HPEESOF_DIR+" "+SIMARCH+ " "+TDA_ROOT 
            command = python + " " + sourceFile + " " + arguments
            useSingleProcess = False
            import DDR_TDCMCompile
            
            target = DDR_TDCMCompile.compilePackage(rootPackage,tdcmRoot,gcc,
                                                    version,isDebug,is32bit,True,
                                                    HPEESOF_DIR,SIMARCH,TDA_ROOT,True)
            try:
                os.remove("__target__.tag")
            except:
                pass
            if useSingleProcess:
                target = DDR_TDCMCompile.compilePackage(rootPackage,tdcmRoot,gcc,
                                                        version,isDebug,is32bit,True,
                                                        HPEESOF_DIR,SIMARCH,TDA_ROOT)
            elif target == None:
                try:
                    os.system(command)
                    f = file("__target__.tag","r")
                    target = f.readline()
                    f.close()
                    os.remove("__target__.tag")
                except:
                    pass
            if target:
                target = target.strip()
            if target == "None":
                target = None
            self.target = None
                         
        if target:
            self.object = Design.Simulation.TDCM_load(target,
                                                      self.instance.getInstanceName(True),
                                                      signalSize)
        else:
            log =  os.path.join(rootPackage,"lib","Compiler.log")
            self.simulation.printFatalError(self.instance.getInstanceName(True),
                                            "Error creating package library.\n"+"Check compiler log "+log)
            
            
        if not self.object:
            return False
        else:
            rootPackage = self.data[TDCM_Descriptor.PackageRootID]
            TDCM_Loader.loadMap[rootPackage] = target
        return True
